// ProApp Vault - public client configuration.
// Everything in this file is PUBLIC (it ships to every browser). Never put secrets here.
// The Firebase web API key is not a secret: access is enforced by Firebase Auth + Firestore rules + the Worker.
window.PROAPP_CONFIG = {
  firebase: {
    apiKey: 'REPLACE_WITH_FIREBASE_WEB_API_KEY',
    projectId: 'REPLACE_WITH_FIREBASE_PROJECT_ID',
  },
  // Base URL of the deployed Cloudflare Worker, no trailing slash. Example: https://proapp-vault-api.your-subdomain.workers.dev
  apiBase: 'https://REPLACE-WITH-YOUR-WORKER-URL',
  // Optional overrides used only for local testing against emulators / mocks. Leave empty in production.
  overrides: { authBase: '', tokenBase: '', firestoreBase: '' },
};
