import { h, icon, toast, confirmDialog, timeAgo, debounce } from '../lib/dom.js';
import { api } from '../lib/api.js';
import { state } from '../state.js';
import { adminPage, loading } from './layout.js';
import { emptyState, errorState } from '../components.js';

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Users', '/admin/users');
  const search = h('input', { class: 'input', type: 'search', placeholder: 'Search by email (starts with)', 'aria-label': 'Search users by email' });
  const list = h('ul', { class: 'rows' });
  const more = h('div', { class: 'more' });
  body.append(h('div', { class: 'toolbar' }, search), list, more);
  let offset = 0;
  let q = '';
  const PAGE = 25;

  async function load(reset) {
    if (reset) {
      offset = 0;
      list.replaceChildren(h('li', null, loading()));
      more.replaceChildren();
    }
    try {
      const res = await api.get(`/api/admin/users?limit=${PAGE}&offset=${offset}&q=${encodeURIComponent(q)}`);
      if (!isCurrent()) return;
      if (reset) list.replaceChildren();
      if (reset && !res.users.length) {
        list.replaceChildren(h('li', null, emptyState({ title: q ? 'No users match' : 'No users yet', text: q ? 'Try the beginning of their email address.' : undefined })));
        return;
      }
      res.users.forEach((u) => list.append(userRow(u)));
      offset += PAGE;
      more.replaceChildren(res.hasMore ? h('button', { class: 'btn', type: 'button', onclick: () => load(false) }, 'Load more') : '');
    } catch (e) {
      list.replaceChildren(h('li', null, errorState(e.message, () => load(true))));
    }
  }

  function userRow(u) {
    const me = u.uid === state.user.uid;
    const li = h('li', { class: 'row-item wrap', dataset: { uid: u.uid } });
    const paint = (user) => {
      li.replaceChildren(
        h('div', { class: 'avatar', 'aria-hidden': 'true' }, Array.from(user.displayName || '?')[0].toUpperCase()),
        h('div', { class: 'grow' },
          h('p', { class: 'strong' }, user.displayName, user.role === 'admin' ? h('span', { class: 'chip' }, 'admin') : null, user.status === 'suspended' ? h('span', { class: 'chip warn' }, 'suspended') : null, me ? h('span', { class: 'chip mute' }, 'you') : null),
          h('p', { class: 'muted' }, user.email),
          h('p', { class: 'muted small-print' }, `Joined ${timeAgo(user.createdAt)} · active ${timeAgo(user.lastActiveAt)}`)),
        me ? null : h('div', { class: 'row-actions' },
          h('button', { class: 'btn small', type: 'button', onclick: () => change(user, { role: user.role === 'admin' ? 'user' : 'admin' }, paint) }, user.role === 'admin' ? 'Remove admin' : 'Make admin'),
          h('button', { class: `btn small ${user.status === 'active' ? 'danger' : ''}`, type: 'button', onclick: () => change(user, { status: user.status === 'active' ? 'suspended' : 'active' }, paint) }, user.status === 'active' ? 'Suspend' : 'Restore')));
    };
    paint(u);
    return li;
  }

  async function change(user, patch, paint) {
    const label = patch.role ? (patch.role === 'admin' ? `Give ${user.email} full administrator access?` : `Remove administrator access from ${user.email}?`) : patch.status === 'suspended' ? `Suspend ${user.email}? They will be signed out of API access and unable to log in.` : `Restore ${user.email}?`;
    if (!(await confirmDialog({ title: 'Confirm change', message: label, confirmLabel: 'Confirm', danger: patch.status === 'suspended' || patch.role === 'admin' }))) return;
    try {
      const res = await api.patch(`/api/admin/users/${user.uid}`, patch);
      Object.assign(user, res.user);
      paint(user);
      toast(res.authSync === false ? 'Saved. Sign-in could not be disabled automatically; check the Worker logs.' : 'User updated', res.authSync === false ? 'info' : 'success');
    } catch (e) {
      toast(e.message, 'error');
    }
  }

  search.addEventListener('input', debounce(() => {
    q = search.value.trim().toLowerCase();
    load(true);
  }, 350));
  await load(true);
}
