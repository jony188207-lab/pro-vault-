import { h, icon, toast, confirmDialog, bytes, timeAgo } from '../lib/dom.js';
import { api, thumbUrl } from '../lib/api.js';
import { adminPage, loading } from './layout.js';
import { emptyState, errorState } from '../components.js';

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Media', '/admin/media', h('a', { class: 'btn primary', href: '#/admin/videos/new' }, icon('upload', 18), 'Upload with a new video'));
  let prefix = 'videos/';
  const tabs = h('div', { class: 'seg', role: 'tablist' });
  const list = h('ul', { class: 'rows' });
  const more = h('div', { class: 'more' });
  body.append(tabs, h('p', { class: 'muted' }, 'Files in your R2 bucket. A file used by a video can not be deleted until it is removed from that video.'), list, more);

  const paintTabs = () => {
    tabs.replaceChildren(...[['videos/', 'Videos'], ['thumbs/', 'Thumbnails']].map(([p, label]) => h('button', { type: 'button', role: 'tab', class: p === prefix ? 'on' : '', 'aria-selected': String(p === prefix), onclick: () => { prefix = p; paintTabs(); load(true); } }, label)));
  };
  let cursor = null;

  async function load(reset) {
    if (reset) {
      cursor = null;
      list.replaceChildren(h('li', null, loading()));
      more.replaceChildren();
    }
    try {
      const res = await api.get(`/api/admin/media?prefix=${encodeURIComponent(prefix)}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
      if (!isCurrent()) return;
      if (reset) list.replaceChildren();
      if (reset && !res.objects.length) {
        list.append(h('li', null, emptyState({ title: 'No files here', text: 'Uploaded files appear in this list.' })));
        return;
      }
      res.objects.forEach((o) => list.append(row(o)));
      cursor = res.cursor;
      more.replaceChildren(cursor ? h('button', { class: 'btn', type: 'button', onclick: () => load(false) }, 'Load more') : '');
    } catch (e) {
      list.replaceChildren(h('li', null, errorState(e.message, () => load(true))));
    }
  }

  function row(o) {
    const li = h('li', { class: 'row-item wrap' },
      prefix === 'thumbs/' ? h('img', { class: 'row-img', src: thumbUrl(o.key), alt: '', loading: 'lazy' }) : h('div', { class: 'row-img icon-tile' }, icon('film', 22)),
      h('div', { class: 'grow' },
        h('p', { class: 'strong mono' }, o.key.split('/')[1]),
        h('p', { class: 'muted' }, `${bytes(o.size)} · ${o.contentType || 'unknown type'} · ${timeAgo(new Date(o.uploaded))}`),
        o.usedBy ? h('p', { class: 'muted' }, 'Used by ', h('a', { href: `#/admin/videos/${o.usedBy.id}` }, o.usedBy.title)) : h('p', { class: 'muted warn-text' }, 'Not used by any video')),
      h('div', { class: 'row-actions' }, h('button', { class: 'btn small danger', type: 'button', disabled: !!o.usedBy, title: o.usedBy ? 'In use' : 'Delete file', onclick: async () => {
        if (!(await confirmDialog({ title: 'Delete this file?', message: 'It will be permanently removed from storage.', confirmLabel: 'Delete file', danger: true }))) return;
        try {
          await api.del('/api/admin/media', { key: o.key });
          li.remove();
          toast('File deleted', 'success');
        } catch (e) {
          toast(e.message, 'error');
        }
      } }, icon('trash', 16), 'Delete')));
    return li;
  }
  paintTabs();
  await load(true);
}
