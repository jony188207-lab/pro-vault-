// Browser side of secure uploads. Files go to the Worker (never directly to R2), which authenticates the admin,
// validates type/size/content and writes to the bucket through its binding.
import { api, putWithProgress, ApiError } from '../lib/api.js';

const VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export function describeFile(file, kind) {
  const allowed = kind === 'video' ? VIDEO_TYPES : IMAGE_TYPES;
  if (!allowed.includes(file.type)) return `Unsupported file type. Use ${allowed.map((t) => t.split('/')[1].toUpperCase()).join(', ')}.`;
  return null;
}

export async function uploadThumbnail(file, onProgress) {
  const problem = describeFile(file, 'image');
  if (problem) throw new ApiError(400, 'unsupported_type', problem);
  const init = await api.post('/api/admin/uploads/init', { kind: 'thumbnail', contentType: file.type, size: file.size });
  await putWithProgress(`/api/admin/uploads/object?key=${encodeURIComponent(init.key)}`, file, (l, t) => onProgress?.(l / t));
  return init.key;
}

export async function uploadVideo(file, onProgress, signal) {
  const problem = describeFile(file, 'video');
  if (problem) throw new ApiError(400, 'unsupported_type', problem);
  const init = await api.post('/api/admin/uploads/init', { kind: 'video', contentType: file.type, size: file.size });
  const { key, uploadId, partSize } = init;
  const parts = [];
  const total = file.size;
  let done = 0;
  try {
    for (let n = 1, offset = 0; offset < total; n++, offset += partSize) {
      if (signal?.aborted) throw new ApiError(0, 'aborted', 'Upload cancelled.');
      const blob = file.slice(offset, Math.min(offset + partSize, total));
      let attempt = 0;
      for (;;) {
        try {
          const part = await putWithProgress(
            `/api/admin/uploads/part?key=${encodeURIComponent(key)}&uploadId=${encodeURIComponent(uploadId)}&partNumber=${n}`,
            blob,
            (loaded) => onProgress?.((done + loaded) / total),
          );
          parts.push(part);
          done += blob.size;
          break;
        } catch (e) {
          if (++attempt >= 3 || (e.status >= 400 && e.status < 500 && e.status !== 408 && e.status !== 429)) throw e;
          await new Promise((r) => setTimeout(r, 800 * attempt));
        }
      }
    }
    await api.post('/api/admin/uploads/complete', { key, uploadId, parts });
    onProgress?.(1);
    return key;
  } catch (e) {
    api.post('/api/admin/uploads/abort', { key, uploadId }).catch(() => {});
    throw e;
  }
}

/** Read duration (seconds) from a local video file without uploading it. */
export function readDuration(file) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    const url = URL.createObjectURL(file);
    const done = (val) => {
      URL.revokeObjectURL(url);
      resolve(val);
    };
    v.preload = 'metadata';
    v.onloadedmetadata = () => done(Number.isFinite(v.duration) ? Math.round(v.duration) : 0);
    v.onerror = () => done(0);
    v.src = url;
  });
}
