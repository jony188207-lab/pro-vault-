import { h, icon, toast, busy, bytes, clear } from '../lib/dom.js';
import { api, ApiError, thumbUrl } from '../lib/api.js';
import { getDoc } from '../lib/firebase.js';
import { navigate } from '../router.js';
import { adminPage, loading } from './layout.js';
import { errorState, emptyState } from '../components.js';
import { uploadVideo, uploadThumbnail, readDuration, describeFile } from './upload.js';

export async function render({ root, params, isCurrent }) {
  const editing = !!params.id;
  const body = adminPage(root, editing ? 'Edit video' : 'Add video', '/admin/videos', h('a', { class: 'btn', href: '#/admin/videos' }, icon('back', 18), 'All videos'));
  body.append(loading());
  let video = null;
  if (editing) {
    try {
      video = await getDoc(`videos/${params.id}`);
    } catch (e) {
      return body.replaceChildren(errorState(e.message, () => location.reload()));
    }
    if (!isCurrent()) return;
    if (!video) return body.replaceChildren(emptyState({ title: 'Video not found', action: h('a', { class: 'btn primary', href: '#/admin/videos' }, 'Back to videos') }));
  }
  const v = video || { title: '', description: '', tags: [], status: 'draft', ad: { enabled: false, url: '', verification: 'sponsor_opened', minAwaySeconds: 0, label: '' } };
  const ad = { enabled: false, url: '', verification: 'sponsor_opened', minAwaySeconds: 0, label: '', ...(v.ad || {}) };

  const f = {
    title: h('input', { class: 'input', id: 'f-title', value: v.title, maxlength: 120, required: true }),
    description: h('textarea', { class: 'input', id: 'f-desc', rows: 5, maxlength: 2000 }, v.description || ''),
    tags: h('input', { class: 'input', id: 'f-tags', value: (v.tags || []).join(', '), placeholder: 'comma, separated, tags' }),
    status: h('select', { class: 'input', id: 'f-status' }, ['draft', 'published'].map((s) => h('option', { value: s, selected: v.status === s }, s === 'draft' ? 'Draft (hidden)' : 'Published'))),
    adEnabled: h('input', { type: 'checkbox', id: 'f-ad-on', checked: ad.enabled }),
    adUrl: h('input', { class: 'input', id: 'f-ad-url', type: 'url', value: ad.url, placeholder: 'https://… (use {sid} to receive the session id)', maxlength: 1000 }),
    adVerif: h('select', { class: 'input', id: 'f-ad-verif' }, [['sponsor_opened', 'Sponsor link opened + time away (default)'], ['postback', 'Also wait for the ad provider’s server confirmation']].map(([val, l]) => h('option', { value: val, selected: ad.verification === val }, l))),
    adAway: h('input', { class: 'input', id: 'f-ad-away', type: 'number', min: 0, max: 120, value: ad.minAwaySeconds || '', placeholder: 'Use global default' }),
    adLabel: h('input', { class: 'input', id: 'f-ad-label', value: ad.label || '', maxlength: 60, placeholder: 'Internal note, e.g. “Offer A”' }),
  };

  // ---- media pickers
  let videoFile = null;
  let thumbFile = null;
  let durationSec = v.durationSec || 0;
  const videoInfo = h('p', { class: 'hint' }, editing && v.videoKey ? `Current file: ${v.contentType || 'video'} · ${bytes(v.sizeBytes)}. Choose a file to replace it.` : 'MP4, WebM or MOV.');
  const videoInput = h('input', { class: 'input', id: 'f-video', type: 'file', accept: 'video/mp4,video/webm,video/quicktime' });
  videoInput.addEventListener('change', async () => {
    videoFile = videoInput.files[0] || null;
    if (!videoFile) return;
    const problem = describeFile(videoFile, 'video');
    if (problem) {
      videoFile = null;
      videoInput.value = '';
      return toast(problem, 'error');
    }
    durationSec = await readDuration(videoFile);
    videoInfo.textContent = `${videoFile.name} · ${bytes(videoFile.size)}${durationSec ? ` · ${Math.floor(durationSec / 60)}:${String(durationSec % 60).padStart(2, '0')}` : ''}`;
    if (!f.title.value.trim()) f.title.value = videoFile.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ');
  });
  const thumbPreview = h('img', { class: 'thumb-preview', alt: 'Thumbnail preview', hidden: !(v.thumbnailKey) });
  if (v.thumbnailKey) thumbPreview.src = thumbUrl(v.thumbnailKey);
  const thumbInput = h('input', { class: 'input', id: 'f-thumb', type: 'file', accept: 'image/jpeg,image/png,image/webp' });
  thumbInput.addEventListener('change', () => {
    thumbFile = thumbInput.files[0] || null;
    if (!thumbFile) return;
    const problem = describeFile(thumbFile, 'image');
    if (problem) {
      thumbFile = null;
      thumbInput.value = '';
      return toast(problem, 'error');
    }
    thumbPreview.src = URL.createObjectURL(thumbFile);
    thumbPreview.hidden = false;
  });

  const progress = h('progress', { max: 1, value: 0, hidden: true, 'aria-label': 'Upload progress' });
  const progressText = h('p', { class: 'hint', role: 'status', 'aria-live': 'polite' });
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const save = h('button', { class: 'btn primary', type: 'submit' }, editing ? 'Save changes' : 'Create video');
  const cancel = new AbortController();

  const field = (label, id, input, hint) => h('div', { class: 'field' }, h('label', { for: id }, label), input, hint ? h('p', { class: 'hint' }, hint) : null);

  const form = h('form', { class: 'form admin-form', novalidate: true },
    h('section', { class: 'card' },
      h('h2', null, 'Details'),
      field('Title', 'f-title', f.title),
      field('Description', 'f-desc', f.description),
      field('Tags', 'f-tags', f.tags, 'Up to 10. Tags are searchable.'),
      field('Visibility', 'f-status', f.status)),
    h('section', { class: 'card' },
      h('h2', null, 'Media'),
      field('Video file', 'f-video', videoInput),
      videoInfo,
      field('Thumbnail', 'f-thumb', thumbInput, 'JPG, PNG or WebP, up to 5 MB. 16:9 looks best.'),
      thumbPreview,
      progress, progressText),
    h('section', { class: 'card' },
      h('h2', null, 'Advertisement for this video'),
      h('p', { class: 'muted' }, 'Used when the ad gate is switched on in Ads. Each video can have its own sponsor link.'),
      h('label', { class: 'check', for: 'f-ad-on' }, f.adEnabled, 'Assign an ad to this video'),
      field('Sponsor URL', 'f-ad-url', f.adUrl, 'Must start with https://. If your provider can pass a click id, put {sid} where it belongs.'),
      field('Verification', 'f-ad-verif', f.adVerif, 'Only choose the provider confirmation if your ad provider sends server-to-server postbacks to your Worker.'),
      field('Seconds away (optional)', 'f-ad-away', f.adAway),
      field('Internal label (optional)', 'f-ad-label', f.adLabel)),
    err,
    h('div', { class: 'sticky-actions' }, h('a', { class: 'btn', href: '#/admin/videos' }, 'Cancel'), save));

  body.replaceChildren(form);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.hidden = true;
    const show = (m) => ((err.textContent = m), (err.hidden = false), err.scrollIntoView?.({ block: 'center' }));
    const title = f.title.value.trim();
    if (!title) return show('Enter a title.');
    if (!editing && !videoFile) return show('Choose a video file to upload.');
    if (f.adEnabled.checked && !/^https:\/\//i.test(f.adUrl.value.trim())) return show('The ad URL must start with https://');
    const tags = f.tags.value.split(',').map((t) => t.trim()).filter(Boolean);

    await busy(save, async () => {
      try {
        const payload = {
          title,
          description: f.description.value,
          tags,
          status: f.status.value,
          ad: { enabled: f.adEnabled.checked, url: f.adUrl.value.trim(), verification: f.adVerif.value, minAwaySeconds: Number(f.adAway.value) || 0, label: f.adLabel.value },
        };
        progress.hidden = false;
        if (videoFile) {
          progressText.textContent = 'Uploading video…';
          payload.videoKey = await uploadVideo(videoFile, (p) => ((progress.value = p), (progressText.textContent = `Uploading video… ${Math.round(p * 100)}%`)), cancel.signal);
          payload.durationSec = durationSec;
        }
        if (thumbFile) {
          progressText.textContent = 'Uploading thumbnail…';
          progress.value = 0;
          payload.thumbnailKey = await uploadThumbnail(thumbFile, (p) => (progress.value = p));
        }
        progressText.textContent = 'Saving…';
        if (editing) await api.patch(`/api/admin/videos/${params.id}`, payload);
        else await api.post('/api/admin/videos', payload);
        toast(editing ? 'Video updated' : 'Video created', 'success');
        navigate('#/admin/videos');
      } catch (ex) {
        progress.hidden = true;
        progressText.textContent = '';
        show(ex instanceof ApiError || ex.message ? ex.message : 'Could not save. Try again.');
      }
    }, 'Saving…');
  });
  window.addEventListener('hashchange', () => cancel.abort(), { once: true });
}
