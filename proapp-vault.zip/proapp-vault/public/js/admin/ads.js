import { h, icon, toast, busy } from '../lib/dom.js';
import { api, apiBase } from '../lib/api.js';
import { loadSettings, DEFAULT_SETTINGS } from '../state.js';
import { adminPage, loading } from './layout.js';
import { errorState } from '../components.js';
import { field, check } from './settings-shared.js';

const TEXT_FIELDS = [
  ['watchInstruction', 'Instruction before watching', 'Shown above the sponsor button.', 300, true],
  ['openAdButton', 'Sponsor button label', '', 60],
  ['waitingText', 'Text while the sponsor page is open', '', 200],
  ['verifyButton', 'Unlock button label', '', 80],
  ['unlockedText', 'Text after unlocking', '', 200],
  ['watchButton', 'Watch button label', 'Appears only after the unlock succeeds.', 40],
  ['saveInstruction', 'Instruction before saving', '', 300, true],
  ['saveOpenAdButton', 'Sponsor button label (save)', '', 60],
  ['saveUnlockedText', 'Text after save is unlocked', '', 200],
  ['saveButton', 'Save button label', '', 40],
];

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Ads and unlock flow', '/admin/ads');
  body.append(loading());
  const load = async () => {
    try {
      const { settings: s, adScriptHostsConfigured } = await api.get('/api/admin/settings');
      if (!isCurrent()) return;
      body.replaceChildren(bannerCard(s, adScriptHostsConfigured), gateCard(s), textsCard(s));
    } catch (e) {
      body.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}

async function saveSettings(patch, btn, label) {
  try {
    const res = await busy(btn, () => api.put('/api/admin/settings', patch), 'Saving…');
    await loadSettings();
    res.warnings?.forEach((w) => toast(w, 'info', 7000));
    toast(label, 'success');
    return res.settings;
  } catch (e) {
    toast(e.message, 'error', 9000);
    return null;
  }
}

function bannerCard(s, hostsConfigured) {
  const b = s.banner;
  const enabled = h('input', { type: 'checkbox', id: 'b-on', checked: b.enabled });
  const html = h('textarea', { class: 'input mono', id: 'b-html', rows: 8, spellcheck: 'false', placeholder: '<script>atOptions = {…};</script>\n<script src="https://…/invoke.js"></script>' }, b.html || '');
  const width = h('input', { class: 'input', id: 'b-w', type: 'number', min: 50, max: 970, value: b.width });
  const height = h('input', { class: 'input', id: 'b-h', type: 'number', min: 30, max: 600, value: b.height });
  const previewHost = h('div', { class: 'banner-preview' });
  const btn = h('button', { class: 'btn primary', type: 'button' }, 'Save banner');
  const paintPreview = (cfg) => {
    previewHost.replaceChildren();
    if (!cfg.html) return previewHost.append(h('p', { class: 'muted' }, 'No banner saved yet.'));
    previewHost.append(h('p', { class: 'hint' }, `Saved banner as visitors see it${cfg.enabled ? '' : ' (currently switched off, so it is hidden on the site)'}:`), h('iframe', { class: 'banner-frame', title: 'Banner preview', src: `${apiBase()}/api/ads/banner-frame?v=${Date.now()}`, width: cfg.width, height: cfg.height, sandbox: 'allow-scripts allow-popups allow-popups-to-escape-sandbox', referrerpolicy: 'no-referrer', scrolling: 'no' }));
  };
  paintPreview(b);
  btn.addEventListener('click', async () => {
    const saved = await saveSettings({ banner: { enabled: enabled.checked, html: html.value, width: Number(width.value), height: Number(height.value) } }, btn, 'Banner saved');
    if (saved) {
      html.value = saved.banner.html;
      paintPreview(saved.banner);
    }
  });
  return h('section', { class: 'card form' },
    h('h2', null, 'Banner below the popular videos'),
    h('p', { class: 'muted' }, 'Paste the banner code from your ad network (for example the Adsterra banner snippet). It is checked on the server, then shown in an isolated sandbox so it can not touch visitors’ accounts.'),
    !hostsConfigured ? h('div', { class: 'notice' }, icon('alert', 18), h('p', null, 'External banner scripts are blocked until you list their host in the Worker variable AD_SCRIPT_HOSTS (see README, step “Allow your ad network”). Image and link banners work without it.')) : null,
    check('b-on', enabled, 'Show the banner on the home screen'),
    field('Banner HTML', 'b-html', html, 'Allowed: script tags from approved hosts, plus div, a, img, ins, span, p and center.'),
    h('div', { class: 'two' }, field('Width (px)', 'b-w', width), field('Height (px)', 'b-h', height)),
    h('div', { class: 'row' }, btn),
    previewHost);
}

function gateCard(s) {
  const g = s.gate;
  const ack = h('input', { type: 'checkbox', id: 'g-ack', checked: g.policyAcknowledged });
  const watch = h('input', { type: 'checkbox', id: 'g-watch', checked: g.requireForWatch });
  const save = h('input', { type: 'checkbox', id: 'g-save', checked: g.requireForSave });
  const away = h('input', { class: 'input', id: 'g-away', type: 'number', min: 1, max: 120, value: g.minAwaySeconds });
  const ttl = h('input', { class: 'input', id: 'g-ttl', type: 'number', min: 1, max: 10080, value: g.unlockTtlMinutes });
  const sess = h('input', { class: 'input', id: 'g-sess', type: 'number', min: 1, max: 240, value: g.sessionTtlMinutes });
  const btn = h('button', { class: 'btn primary', type: 'button' }, 'Save unlock settings');
  btn.addEventListener('click', () => saveSettings({ gate: { policyAcknowledged: ack.checked, requireForWatch: watch.checked, requireForSave: save.checked, minAwaySeconds: Number(away.value), unlockTtlMinutes: Number(ttl.value), sessionTtlMinutes: Number(sess.value) } }, btn, 'Unlock settings saved'));
  return h('section', { class: 'card form' },
    h('h2', null, 'Sponsor step before watching or saving'),
    h('div', { class: 'notice warn' }, icon('alert', 18), h('div', null,
      h('p', null, h('strong', null, 'Check your ad network’s rules first.')),
      h('p', { class: 'muted' }, 'Many networks, including Adsterra, prohibit rewarding or pressuring visitors to click or view ads. What this step can honestly prove is limited: that the sponsor link was opened and that time passed, and, only if your provider sends server-to-server postbacks, that the provider confirmed. It can not prove an ad was seen. Word your instructions accordingly.'))),
    check('g-ack', ack, 'I checked that my ad network allows this flow', 'Required before the switches below can be turned on.'),
    check('g-watch', watch, 'Require the sponsor step before a video can be watched', 'Only videos that have an ad assigned are locked.'),
    check('g-save', save, 'Require the sponsor step before a video can be saved'),
    h('div', { class: 'two' }, field('Minimum seconds away', 'g-away', away, 'Measured by the server. Can be overridden per video.'), field('Unlock lasts (minutes)', 'g-ttl', ttl, '60 = one hour. 1440 = one day.')),
    field('Sponsor step times out after (minutes)', 'g-sess', sess),
    h('div', { class: 'row' }, btn));
}

function textsCard(s) {
  const inputs = {};
  const fields = TEXT_FIELDS.map(([key, label, hint, max, long]) => {
    const input = long ? h('textarea', { class: 'input', id: `t-${key}`, rows: 2, maxlength: max }, s.texts[key]) : h('input', { class: 'input', id: `t-${key}`, value: s.texts[key], maxlength: max });
    inputs[key] = input;
    return field(label, `t-${key}`, input, hint);
  });
  const preview = h('div', { class: 'gate gate-preview', 'aria-label': 'Preview' });
  const paint = () => {
    preview.replaceChildren(h('div', { class: 'gate-icon' }, icon('lock', 22)), h('div', { class: 'gate-body' }, h('p', { class: 'gate-text' }, inputs.watchInstruction.value), h('span', { class: 'btn primary' }, icon('external', 18), inputs.openAdButton.value), h('p', { class: 'hint' }, `After returning: “${inputs.verifyButton.value}” → “${inputs.watchButton.value}”`)));
  };
  Object.values(inputs).forEach((i) => i.addEventListener('input', paint));
  paint();
  const btn = h('button', { class: 'btn primary', type: 'button' }, 'Save texts');
  const reset = h('button', { class: 'btn ghost', type: 'button' }, 'Restore defaults');
  reset.addEventListener('click', () => {
    for (const [k, i] of Object.entries(inputs)) i.value = DEFAULT_SETTINGS.texts[k];
    paint();
  });
  btn.addEventListener('click', () => saveSettings({ texts: Object.fromEntries(Object.entries(inputs).map(([k, i]) => [k, i.value])) }, btn, 'Texts saved'));
  return h('section', { class: 'card form' }, h('h2', null, 'Instructions and button labels'), h('p', { class: 'muted' }, 'Any language works. Visitors see these exactly as written.'), preview, ...fields, h('div', { class: 'row' }, btn, reset));
}
