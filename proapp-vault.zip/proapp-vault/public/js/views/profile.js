import { h, icon, busy, toast, confirmDialog, dialog, fullDate } from '../lib/dom.js';
import * as fb from '../lib/firebase.js';
import { api } from '../lib/api.js';
import { state, setUser, logout, isAdmin } from '../state.js';
import { navigate } from '../router.js';

export async function render({ root }) {
  const u = state.user;
  const s = fb.currentSession();
  const page = h('div', { class: 'page narrow' });
  root.append(page);

  page.append(
    h('div', { class: 'profile-head' },
      h('div', { class: 'avatar xl', 'aria-hidden': 'true' }, Array.from(u.displayName || '?')[0].toUpperCase()),
      h('div', null, h('h1', { class: 'h2' }, u.displayName), h('p', { class: 'muted' }, u.email), isAdmin() ? h('a', { class: 'chip', href: '#/admin' }, icon('shield', 14), 'Administrator') : null)),
  );

  // verification
  if (!s?.emailVerified) {
    const resend = h('button', { class: 'btn small', type: 'button' }, 'Send verification email');
    resend.addEventListener('click', () => busy(resend, async () => {
      try {
        await fb.sendVerificationEmail();
        toast('Verification email sent. Check your inbox.', 'success');
      } catch (e) {
        toast(e.message, 'error');
      }
    }, 'Sending…'));
    const check = h('button', { class: 'btn small ghost', type: 'button' }, 'I verified it');
    check.addEventListener('click', () => busy(check, async () => {
      try {
        const ok = await fb.refreshEmailVerified();
        if (ok) {
          await api.post('/api/session', {}).then((r) => setUser(r.user));
          toast('Email verified. Thank you!', 'success');
          navigate('#/profile');
          location.reload();
        } else toast('Not verified yet. Open the link in the email first.', 'info');
      } catch (e) {
        toast(e.message, 'error');
      }
    }, 'Checking…'));
    page.append(h('div', { class: 'notice' }, icon('alert', 18), h('div', null, h('p', null, h('strong', null, 'Verify your email')), h('p', { class: 'muted' }, 'Verified emails make password recovery reliable.'), h('div', { class: 'row' }, resend, check))));
  }

  // display name
  const nameInput = h('input', { class: 'input', id: 'dn', value: u.displayName, maxlength: 40, minlength: 2, required: true, autocomplete: 'nickname' });
  const nameBtn = h('button', { class: 'btn primary', type: 'submit' }, 'Save name');
  const nameForm = h('form', { class: 'card form' }, h('h2', null, 'Display name'), h('div', { class: 'field' }, h('label', { for: 'dn' }, 'Shown next to your comments'), nameInput), nameBtn);
  nameForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const displayName = nameInput.value.trim();
    if (displayName.length < 2) return toast('Name must be at least 2 characters.', 'error');
    await busy(nameBtn, async () => {
      try {
        const res = await api.patch('/api/me', { displayName });
        setUser(res.user);
        fb.setDisplayName(displayName).catch(() => {});
        toast('Name updated', 'success');
        document.querySelector('.profile-head h1').textContent = res.user.displayName;
      } catch (ex) {
        toast(ex.message, 'error');
      }
    }, 'Saving…');
  });

  // password
  const cur = h('input', { class: 'input', id: 'cp', type: 'password', autocomplete: 'current-password', required: true });
  const nw = h('input', { class: 'input', id: 'np', type: 'password', autocomplete: 'new-password', minlength: 6, required: true });
  const pwBtn = h('button', { class: 'btn primary', type: 'submit' }, 'Change password');
  const pwForm = h('form', { class: 'card form' }, h('h2', null, 'Password'), h('div', { class: 'field' }, h('label', { for: 'cp' }, 'Current password'), cur), h('div', { class: 'field' }, h('label', { for: 'np' }, 'New password'), nw, h('p', { class: 'hint' }, 'At least 6 characters.')), pwBtn);
  pwForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (nw.value.length < 6) return toast('New password must be at least 6 characters.', 'error');
    await busy(pwBtn, async () => {
      try {
        await fb.changePassword(cur.value, nw.value);
        cur.value = nw.value = '';
        toast('Password changed', 'success');
      } catch (ex) {
        toast(ex.message, 'error');
      }
    }, 'Changing…');
  });

  // danger zone
  const del = h('button', { class: 'btn danger', type: 'button' }, 'Delete my account');
  del.addEventListener('click', () => deleteAccountDialog());
  const out = h('button', { class: 'btn', type: 'button' }, icon('logout', 18), 'Log out');
  out.addEventListener('click', async () => {
    await logout();
    toast('Logged out', 'success');
    navigate('#/');
  });

  page.append(
    h('div', { class: 'row link-row' }, h('a', { class: 'btn', href: '#/saved' }, icon('bookmark', 18), 'Saved videos'), out),
    nameForm,
    pwForm,
    h('section', { class: 'card danger-zone' }, h('h2', null, 'Delete account'), h('p', { class: 'muted' }, 'Permanently removes your account, likes, saved videos and comments. This can not be undone.'), isAdmin() ? h('p', { class: 'hint' }, 'Administrators must have the admin role removed by another admin first.') : null, del),
    h('p', { class: 'muted small-print' }, `Member since ${fullDate(u.createdAt) || 'recently'}`),
  );
}

function deleteAccountDialog() {
  const pw = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', 'aria-label': 'Password', required: true });
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  dialog({
    title: 'Delete your account?',
    body: h('div', { class: 'form' }, h('p', null, 'Enter your password to confirm. Your account and data will be permanently deleted.'), pw, err),
    actions: [
      { label: 'Cancel', onClick: (close) => close() },
      {
        label: 'Delete forever',
        kind: 'danger',
        onClick: async (close) => {
          err.hidden = true;
          if (!pw.value) return ((err.textContent = 'Enter your password.'), (err.hidden = false));
          try {
            await fb.reauthenticate(pw.value);
            let res;
            do {
              res = await api.del('/api/me', { confirm: true });
            } while (!res.done);
            close();
            await logout();
            toast('Your account was deleted.', 'success');
            navigate('#/');
          } catch (e) {
            err.textContent = e.message;
            err.hidden = false;
          }
        },
      },
    ],
  });
}
