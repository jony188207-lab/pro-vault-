// Shared application state: signed-in profile and public settings.
import { api, ApiError } from './lib/api.js';
import * as fb from './lib/firebase.js';
import { getDoc } from './lib/firebase.js';

export const DEFAULT_SETTINGS = {
  siteName: 'ProApp Vault',
  tagline: 'Premium videos, one tap away',
  popularCount: 8,
  homeListLimit: 12,
  allowSignups: true,
  commentsEnabled: true,
  banner: { enabled: false, html: '', width: 320, height: 100 },
  gate: { requireForWatch: false, requireForSave: false, minAwaySeconds: 5 },
  texts: {
    watchInstruction: 'আগে 5 সেকেন্ড অ্যাড দেখুন তারপর ফিরে আসুন',
    openAdButton: 'স্পনসর পেজ খুলুন',
    verifyButton: 'আমি ফিরে এসেছি — আনলক করুন',
    waitingText: 'অ্যাড পেজ দেখে এই পেজে ফিরে আসুন',
    unlockedText: 'আনলক হয়েছে! এখন ভিডিও দেখতে পারেন।',
    watchButton: 'এখনই দেখুন',
    saveInstruction: 'ভিডিও সেভ করতে আগে একবার স্পনসর পেজ খুলে ফিরে আসুন',
    saveOpenAdButton: 'স্পনসর পেজ খুলুন',
    saveUnlockedText: 'সেভ আনলক হয়েছে।',
    saveButton: 'সেভ করুন',
  },
};

export const state = {
  user: null, // profile from the Worker (role/status come from the server, never from the browser)
  settings: DEFAULT_SETTINGS,
  ready: false,
};

const subs = new Set();
export const subscribe = (fn) => (subs.add(fn), () => subs.delete(fn));
const notify = () => subs.forEach((fn) => fn(state));

function merge(base, patch) {
  const out = { ...base };
  for (const [k, v] of Object.entries(patch || {})) out[k] = v && typeof v === 'object' && !Array.isArray(v) && !(v instanceof Date) && typeof base[k] === 'object' ? merge(base[k], v) : v;
  return out;
}

export async function loadSettings() {
  try {
    const doc = await getDoc('settings/public');
    state.settings = merge(DEFAULT_SETTINGS, doc || {});
  } catch {
    state.settings = state.settings || DEFAULT_SETTINGS;
  }
  document.title = state.settings.siteName;
  notify();
  return state.settings;
}

/** Create/refresh the server-side profile after Firebase sign-in. Signs out again if the server refuses. */
export async function establishSession() {
  try {
    const { user } = await api.post('/api/session', {});
    state.user = user;
    notify();
    return user;
  } catch (e) {
    if (e instanceof ApiError && e.status === 0) {
      notify();
      throw e; // network problem: keep the Firebase session, tell the user
    }
    state.user = null;
    await fb.signOut();
    notify();
    throw e;
  }
}

export async function logout() {
  // Clear the profile first: signOut() fires the auth-change listener, which must not see a signed-in user (it would call logout() again).
  state.user = null;
  await fb.signOut();
  notify();
}

export function setUser(user) {
  state.user = user;
  notify();
}

export const isAdmin = () => state.user?.role === 'admin';

// where to go after login
const RETURN = 'proapp.returnTo';
export const rememberReturn = (hash) => {
  try {
    sessionStorage.setItem(RETURN, hash);
  } catch {
    /* ignore */
  }
};
export const takeReturn = () => {
  try {
    const v = sessionStorage.getItem(RETURN);
    sessionStorage.removeItem(RETURN);
    return v && v.startsWith('#/') && !v.startsWith('#/login') ? v : '#/';
  } catch {
    return '#/';
  }
};
