// Local test rig: static frontend (with the production CSP from public/_headers) + Worker + mock Google services.
// Usage: import { startRig } from './e2e-server.js'
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createMock, MemoryBucket, PROJECT } from './mock-backend.js';
import { handle } from '../worker/src/index.js';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };

function listen(server) {
  return new Promise((r) => server.listen(0, '127.0.0.1', () => r(server.address().port)));
}

export async function startRig() {
  const mock = await createMock().start();
  const bucket = new MemoryBucket();
  const csp = fs.readFileSync(path.join(ROOT, '_headers'), 'utf8').match(/Content-Security-Policy:\s*(.+)/)[1];

  let apiOrigin = '';
  let siteOrigin = '';
  const env = () => ({
    FIREBASE_PROJECT_ID: PROJECT,
    FIREBASE_SERVICE_ACCOUNT_JSON: mock.serviceAccountJson(),
    FIREBASE_JWKS_URL: `${mock.url}/jwks`,
    FIRESTORE_API_BASE: `${mock.url}/v1`,
    IDENTITY_API_BASE: `${mock.url}/v1`,
    ALLOWED_ORIGINS: siteOrigin,
    PUBLIC_API_URL: apiOrigin,
    BOOTSTRAP_ADMIN_EMAILS: 'boss@site.test',
    AD_SCRIPT_HOSTS: 'ads.example.com',
    MEDIA_SIGNING_SECRET: 'x'.repeat(40),
    MEDIA_BUCKET: bucket,
    MAX_VIDEO_BYTES: String(50 * 1024 * 1024),
  });

  const api = http.createServer(async (req, res) => {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const body = chunks.length ? Buffer.concat(chunks) : undefined;
    const headers = new Headers();
    for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers.set(k, v);
    const request = new Request(`${apiOrigin}${req.url}`, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body });
    const r = await handle(request, env(), {});
    res.writeHead(r.status, Object.fromEntries(r.headers));
    res.end(Buffer.from(await r.arrayBuffer()));
  });
  const apiPort = await listen(api);
  apiOrigin = `http://127.0.0.1:${apiPort}`;

  const site = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    let file = url.pathname === '/' ? '/index.html' : url.pathname;
    if (file === '/js/config.js') {
      res.writeHead(200, { 'Content-Type': 'text/javascript' });
      return res.end(
        `window.PROAPP_CONFIG=${JSON.stringify({ firebase: { apiKey: 'test-key', projectId: PROJECT }, apiBase: apiOrigin, overrides: { authBase: `${mock.url}/v1`, tokenBase: `${mock.url}/v1`, firestoreBase: `${mock.url}/v1` } })};`,
      );
    }
    const full = path.join(ROOT, path.normalize(file));
    if (!full.startsWith(ROOT) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) {
      res.writeHead(404);
      return res.end('not found');
    }
    // same policy as production, with the placeholder hosts replaced by the local rig
    const policy = csp
      .replaceAll('https://YOUR-WORKER-URL', apiOrigin)
      .replace("connect-src 'self'", `connect-src 'self' ${mock.url}`);
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(full)] || 'application/octet-stream', 'Content-Security-Policy': policy });
    res.end(fs.readFileSync(full));
  });
  const sitePort = await listen(site);
  siteOrigin = `http://127.0.0.1:${sitePort}`;

  return {
    mock,
    bucket,
    siteOrigin,
    apiOrigin,
    csp,
    async stop() {
      await Promise.all([mock.stop(), new Promise((r) => api.close(r)), new Promise((r) => site.close(r))]);
    },
  };
}
