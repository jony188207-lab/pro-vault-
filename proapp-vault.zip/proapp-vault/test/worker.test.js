import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createMock, MemoryBucket, PROJECT } from './mock-backend.js';
import { handle } from '../worker/src/index.js';
import { sanitizeBannerHtml } from '../worker/src/lib/sanitize.js';
import { searchTokens } from '../worker/src/lib/ids.js';
import { searchTokens as clientTokens } from '../public/js/lib/search.js';
import { parseRange } from '../worker/src/routes/media.js';

const ORIGIN = 'https://site.test';
let mock;
let env;
const bucket = new MemoryBucket();

const call = async (method, path, { token, body, raw, headers = {} } = {}) => {
  const h = { Origin: ORIGIN, ...headers };
  if (token) h.Authorization = `Bearer ${token}`;
  let payload = raw;
  if (body !== undefined && method !== 'GET') {
    payload = JSON.stringify(body);
    h['Content-Type'] = 'application/json';
  }
  const res = await handle(new Request(`https://api.test${path}`, { method, headers: h, body: payload }), env, {});
  const text = await res.clone().text();
  let data = null;
  try {
    data = JSON.parse(text);
  } catch {
    /* not json */
  }
  return { status: res.status, data, res, text };
};

const person = (email, { verified = true } = {}) => {
  const u = mock.newAuthUser(email, 'secret123');
  u.verified = verified;
  return { u, token: () => mock.signIdToken(u) };
};
const signin = async (p) => (await call('POST', '/api/session', { token: p.token() })).data?.user;

const MP4 = new Uint8Array([0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d, 0, 0, 2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3, 4]);

let admin;
let alice;
let bob;
let videoId;

before(async () => {
  mock = await createMock().start();
  env = {
    FIREBASE_PROJECT_ID: PROJECT,
    FIREBASE_SERVICE_ACCOUNT_JSON: mock.serviceAccountJson(),
    FIREBASE_JWKS_URL: `${mock.url}/jwks`,
    FIRESTORE_API_BASE: `${mock.url}/v1`,
    IDENTITY_API_BASE: `${mock.url}/v1`,
    ALLOWED_ORIGINS: ORIGIN,
    BOOTSTRAP_ADMIN_EMAILS: 'boss@site.test',
    AD_SCRIPT_HOSTS: 'ads.example.com,*.adnet.test',
    MEDIA_SIGNING_SECRET: 'x'.repeat(40),
    AD_POSTBACK_SECRET: 'p'.repeat(24),
    MEDIA_BUCKET: bucket,
    MAX_VIDEO_BYTES: String(1024 * 1024),
  };
  admin = person('boss@site.test');
  alice = person('alice@site.test');
  bob = person('bob@site.test');
});
after(() => mock.stop());

// ------------------------------------------------------------------------------------------------ auth
test('health + CORS only for the configured origin', async () => {
  const ok = await call('GET', '/api/health');
  assert.equal(ok.status, 200);
  assert.equal(ok.res.headers.get('Access-Control-Allow-Origin'), ORIGIN);
  const bad = await call('GET', '/api/health', { headers: { Origin: 'https://evil.test' } });
  assert.equal(bad.res.headers.get('Access-Control-Allow-Origin'), null);
  const pre = await call('OPTIONS', '/api/session');
  assert.equal(pre.status, 204);
});

test('requests without a valid token are rejected', async () => {
  assert.equal((await call('POST', '/api/session')).status, 401);
  assert.equal((await call('POST', '/api/session', { token: 'garbage' })).status, 401);
  // token signed by another key
  const forged = mock.signIdToken(alice.u).split('.');
  forged[2] = forged[2].slice(0, -4) + 'AAAA';
  assert.equal((await call('POST', '/api/session', { token: forged.join('.') })).status, 401);
  // wrong audience
  const wrongAud = mock.signIdToken(alice.u, { aud: 'other-project' });
  assert.equal((await call('POST', '/api/session', { token: wrongAud })).status, 401);
  // expired
  const expired = mock.signIdToken(alice.u, { exp: Math.floor(Date.now() / 1000) - 10 });
  const r = await call('POST', '/api/session', { token: expired });
  assert.equal(r.status, 401);
  assert.equal(r.data.error.code, 'token_expired');
});

test('first sign-in creates a profile; client cannot claim admin; bootstrap admin needs verified email', async () => {
  const a = await signin(alice);
  assert.equal(a.role, 'user');
  assert.equal(mock.read(`users/${alice.u.uid}`).status, 'active');
  // an unverified account using the admin e-mail does NOT get admin
  const fake = person('boss@site.test', { verified: false });
  fake.u.uid = 'faker000000000001';
  const f = await call('POST', '/api/session', { token: mock.signIdToken(fake.u) });
  assert.equal(f.data.user.role, 'user');
  const b = await signin(admin);
  assert.equal(b.role, 'admin');
  await signin(bob);
  // second call is idempotent
  assert.equal((await signin(alice)).uid, alice.u.uid);
});

test('admin endpoints reject normal users and anonymous callers', async () => {
  for (const [m, p] of [['GET', '/api/admin/dashboard'], ['GET', '/api/admin/users'], ['PUT', '/api/admin/settings'], ['POST', '/api/admin/videos'], ['POST', '/api/admin/uploads/init'], ['DELETE', '/api/admin/media']]) {
    assert.equal((await call(m, p, { token: alice.token(), body: {} })).status, 403, `${m} ${p} as user`);
    assert.equal((await call(m, p, { body: {} })).status, 401, `${m} ${p} anonymous`);
  }
});

test('profile: update name, reject bad input', async () => {
  const ok = await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: '  Alice  Wonder ' } });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.user.displayName, 'Alice Wonder');
  assert.equal((await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'x' } })).status, 400);
  assert.equal((await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'a'.repeat(41) } })).status, 400);
  // role cannot be smuggled in
  await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'Alice W', role: 'admin' } });
  assert.equal(mock.read(`users/${alice.u.uid}`).role, 'user');
});

// ------------------------------------------------------------------------------------------------ settings & banner
test('settings: validation, banner sanitising, policy acknowledgement', async () => {
  const t = admin.token();
  const get = await call('GET', '/api/admin/settings', { token: t });
  assert.equal(get.status, 200);
  assert.equal(get.data.settings.homeListLimit, 12);

  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { homeListLimit: 0 } })).status, 400);
  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { homeListLimit: 999 } })).status, 400);

  const bad = await call('PUT', '/api/admin/settings', { token: t, body: { banner: { html: '<iframe src="https://x.test"></iframe>' } } });
  assert.equal(bad.status, 400);
  const badHost = await call('PUT', '/api/admin/settings', { token: t, body: { banner: { html: '<script src="https://evil.test/a.js"></script>' } } });
  assert.equal(badHost.data.error.code, 'script_host_not_allowed');

  const gate = await call('PUT', '/api/admin/settings', { token: t, body: { gate: { requireForWatch: true } } });
  assert.equal(gate.data.error.code, 'policy_ack_required');

  const html = '<script>atOptions = {"key":"abc123","format":"iframe","height":60,"width":468,"params":{}};</script><script src="https://ads.example.com/abc123/invoke.js"></script>';
  const ok = await call('PUT', '/api/admin/settings', {
    token: t,
    body: {
      homeListLimit: 5,
      popularCount: 4,
      banner: { enabled: true, html, width: 468, height: 60 },
      gate: { requireForWatch: true, requireForSave: true, policyAcknowledged: true, minAwaySeconds: 1, unlockTtlMinutes: 30 },
      texts: { watchInstruction: 'Open the sponsor page, then come back', watchButton: 'Watch now' },
    },
  });
  assert.equal(ok.status, 200, ok.text);
  assert.equal(ok.data.settings.homeListLimit, 5);
  assert.equal(ok.data.settings.gate.policyAcknowledgedBy, admin.u.uid);
  assert.equal(mock.read('settings/public').texts.watchButton, 'Watch now');
  assert.equal(mock.read('settings/public').texts.openAdButton, 'স্পনসর পেজ খুলুন', 'unchanged texts keep defaults');

  const frame = await call('GET', '/api/ads/banner-frame');
  assert.match(frame.text, /ads\.example\.com\/abc123\/invoke\.js/);
  assert.match(frame.res.headers.get('Content-Security-Policy'), /sandbox allow-scripts/);
  assert.doesNotMatch(frame.res.headers.get('Content-Security-Policy'), /allow-same-origin/);
  assert.match(frame.res.headers.get('Content-Security-Policy'), /frame-ancestors 'self' https:\/\/site\.test/);
});

test('banner sanitiser blocks script injection vectors', () => {
  const opt = { allowedHosts: ['ads.example.com', '*.adnet.test'] };
  const reject = (html) => assert.throws(() => sanitizeBannerHtml(html, opt), undefined, html);
  reject('<script>alert(1)</script>');
  reject('<script>atOptions = {}; fetch("https://evil.test")</script>');
  reject('<script>location = {"a":1};</script>');
  reject('<script src="https://evil.test/x.js"></script>');
  reject('<script src="https://ads.example.com.evil.test/x.js"></script>');
  reject('<script src="https://ads.example.com/x.js">alert(1)</script>');
  reject('<script src="javascript:alert(1)"></script>');
  reject('<iframe src="https://a.test"></iframe>');
  reject('<object data="x"></object>');
  reject('<svg onload=alert(1)>');
  reject('<style>*{}</style>');
  reject('<form action="x"></form>');
  reject('<link rel="stylesheet" href="x">');
  reject('<!DOCTYPE html>');
  reject('<div');
  const okHost = sanitizeBannerHtml('<script src="//cdn.adnet.test/a.js" async></script>', opt);
  assert.match(okHost.html, /https:\/\/cdn\.adnet\.test\/a\.js/);
  const clean = sanitizeBannerHtml('<a href="javascript:alert(1)" onclick="x()" target="_top"><img src="https://i.test/a.png" onerror="x()" width="10"></a><!-- c -->', opt);
  assert.doesNotMatch(clean.html, /javascript:|onclick|onerror|_top|<!--/);
  assert.match(clean.html, /<img src="https:\/\/i\.test\/a\.png" width="10" \/>/);
  assert.ok(clean.warnings.length >= 2);
  const attr = sanitizeBannerHtml('<div title="&quot;><script>x">hi</div>', opt);
  assert.doesNotMatch(attr.html, /<script>x/);
});

test('search tokens are identical on server and client', () => {
  for (const s of ['Hello World 2024', 'বাংলা ভিডিও', 'Ünïcode  café', '']) assert.deepEqual(searchTokens(s, 'tag'), clientTokens(s, 'tag'));
});

// ------------------------------------------------------------------------------------------------ uploads & videos
test('uploads: validation, multipart, content sniffing, size limit', async () => {
  const t = admin.token();
  assert.equal((await call('POST', '/api/admin/uploads/init', { token: t, body: { kind: 'video', contentType: 'application/x-msdownload', size: 10 } })).status, 400);
  assert.equal((await call('POST', '/api/admin/uploads/init', { token: t, body: { kind: 'video', contentType: 'video/mp4', size: 5 * 1024 * 1024 } })).status, 413);
  assert.equal((await call('POST', '/api/admin/uploads/init', { token: t, body: { kind: 'thumbnail', contentType: 'image/svg+xml', size: 10 } })).status, 400);

  // thumbnail
  const ti = await call('POST', '/api/admin/uploads/init', { token: t, body: { kind: 'thumbnail', contentType: 'image/png', size: PNG.length } });
  assert.match(ti.data.key, /^thumbs\/[0-9a-f-]{36}\.png$/);
  const fake = await call('PUT', `/api/admin/uploads/object?key=${ti.data.key}`, { token: t, raw: new Uint8Array([1, 2, 3, 4]) });
  assert.equal(fake.data.error.code, 'bad_content');
  assert.equal((await call('PUT', '/api/admin/uploads/object?key=thumbs/../../etc.png', { token: t, raw: PNG })).status, 400);
  const up = await call('PUT', `/api/admin/uploads/object?key=${ti.data.key}`, { token: t, raw: PNG });
  assert.equal(up.status, 200, up.text);
  globalThis.thumbKey = ti.data.key;

  // video (two parts)
  const vi = await call('POST', '/api/admin/uploads/init', { token: t, body: { kind: 'video', contentType: 'video/mp4', size: MP4.length } });
  assert.equal(vi.data.mode, 'multipart');
  const p1 = await call('PUT', `/api/admin/uploads/part?key=${vi.data.key}&uploadId=${vi.data.uploadId}&partNumber=1`, { token: t, raw: MP4.slice(0, 13) });
  const p2 = await call('PUT', `/api/admin/uploads/part?key=${vi.data.key}&uploadId=${vi.data.uploadId}&partNumber=2`, { token: t, raw: MP4.slice(13) });
  assert.equal(p1.status, 200, p1.text);
  const done = await call('POST', '/api/admin/uploads/complete', { token: t, body: { key: vi.data.key, uploadId: vi.data.uploadId, parts: [p1.data, p2.data] } });
  assert.equal(done.status, 200, done.text);
  assert.equal(done.data.size, MP4.length);
  globalThis.videoKey = vi.data.key;

  // a "video" whose bytes are not a video is rejected and removed
  const v2 = await call('POST', '/api/admin/uploads/init', { token: t, body: { kind: 'video', contentType: 'video/mp4', size: 30 } });
  const bad = await call('PUT', `/api/admin/uploads/part?key=${v2.data.key}&uploadId=${v2.data.uploadId}&partNumber=1`, { token: t, raw: new Uint8Array(30).fill(65) });
  const rej = await call('POST', '/api/admin/uploads/complete', { token: t, body: { key: v2.data.key, uploadId: v2.data.uploadId, parts: [bad.data] } });
  assert.equal(rej.data.error.code, 'bad_content');
  assert.equal(await bucket.head(v2.data.key), null, 'rejected upload is deleted');
});

test('video create/update validation; ad URL must be https', async () => {
  const t = admin.token();
  const base = { title: 'Big Buck Demo', description: 'A test video', tags: ['Demo', 'demo', 'Test'], status: 'published', videoKey: globalThis.videoKey, thumbnailKey: globalThis.thumbKey };
  assert.equal((await call('POST', '/api/admin/videos', { token: t, body: { ...base, videoKey: 'videos/11111111-1111-1111-1111-111111111111.mp4' } })).data.error.code, 'media_missing');
  assert.equal((await call('POST', '/api/admin/videos', { token: t, body: { ...base, videoKey: '../../secret' } })).status, 400);
  assert.equal((await call('POST', '/api/admin/videos', { token: t, body: { ...base, title: '' } })).status, 400);
  assert.equal((await call('POST', '/api/admin/videos', { token: t, body: { ...base, ad: { enabled: true, url: 'http://insecure.test' } } })).status, 400);
  assert.equal((await call('POST', '/api/admin/videos', { token: t, body: { ...base, ad: { enabled: true, url: 'javascript:alert(1)' } } })).status, 400);
  const ok = await call('POST', '/api/admin/videos', { token: t, body: { ...base, ad: { enabled: true, url: 'https://ads.example.com/offer?sid={sid}', minAwaySeconds: 1 } } });
  assert.equal(ok.status, 201, ok.text);
  videoId = ok.data.id;
  const v = mock.read(`videos/${videoId}`);
  assert.deepEqual(v.tags, ['demo', 'test']);
  assert.equal(v.views, 0);
  assert.ok(v.searchTokens.includes('big') && v.searchTokens.includes('dem'));
  const upd = await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { title: 'Renamed Clip' } });
  assert.equal(upd.status, 200);
  assert.ok(mock.read(`videos/${videoId}`).searchTokens.includes('renamed'));
  assert.equal(mock.read(`videos/${videoId}`).ad.url, 'https://ads.example.com/offer?sid={sid}', 'ad kept on partial update');
});

// ------------------------------------------------------------------------------------------------ viewer flow
test('watching is blocked until the sponsor flow is completed', async () => {
  const t = alice.token();
  const denied = await call('POST', `/api/videos/${videoId}/play`, { token: t });
  assert.equal(denied.status, 403);
  assert.equal(denied.data.error.code, 'ad_required');

  const st = await call('GET', `/api/videos/${videoId}/state`, { token: t });
  assert.equal(st.data.gate.watch.required, true);
  assert.equal(st.data.gate.watch.unlocked, false);

  const start = await call('POST', '/api/ads/start', { token: t, body: { videoId, purpose: 'watch' } });
  assert.equal(start.status, 200, start.text);
  assert.match(start.data.adUrl, /^https:\/\/ads\.example\.com\/offer\?sid=[0-9a-f-]{36}$/);

  // another user cannot complete my session
  const steal = await call('POST', '/api/ads/complete', { token: bob.token(), body: { sessionId: start.data.sessionId } });
  assert.equal(steal.status, 404);

  // too early: the server measures the wait itself
  const early = await call('POST', '/api/ads/complete', { token: t, body: { sessionId: start.data.sessionId } });
  assert.equal(early.status, 409);
  assert.equal(early.data.error.code, 'too_early');
  assert.equal((await call('POST', `/api/videos/${videoId}/play`, { token: t })).status, 403);

  await new Promise((r) => setTimeout(r, 1100));
  const done = await call('POST', '/api/ads/complete', { token: t, body: { sessionId: start.data.sessionId } });
  assert.equal(done.status, 200, done.text);
  assert.equal(done.data.unlocked, true);
  // completing twice is harmless
  assert.equal((await call('POST', '/api/ads/complete', { token: t, body: { sessionId: start.data.sessionId } })).data.unlocked, true);
});

test('play: signed stream URL, server-side view counting, range requests', async () => {
  const t = alice.token();
  const play = await call('POST', `/api/videos/${videoId}/play`, { token: t });
  assert.equal(play.status, 200, play.text);
  assert.equal(play.data.viewCounted, true);
  assert.equal(mock.read(`videos/${videoId}`).views, 1);
  // replays inside the window do not inflate the count
  const again = await call('POST', `/api/videos/${videoId}/play`, { token: t });
  assert.equal(again.data.viewCounted, false);
  assert.equal(mock.read(`videos/${videoId}`).views, 1);

  const u = new URL(play.data.url);
  const full = await call('GET', u.pathname + u.search);
  assert.equal(full.status, 200);
  assert.equal(full.res.headers.get('Accept-Ranges'), 'bytes');
  const part = await call('GET', u.pathname + u.search, { headers: { Range: 'bytes=4-7' } });
  assert.equal(part.status, 206);
  assert.equal(part.res.headers.get('Content-Range'), `bytes 4-7/${MP4.length}`);
  assert.equal(part.text, 'ftyp');
  // tampered / missing token
  assert.equal((await call('GET', u.pathname + u.search.slice(0, -3) + 'abc')).status, 403);
  assert.equal((await call('GET', '/api/media/stream')).status, 403);
  // a signed token for an unrelated key is refused
  assert.equal(parseRange('bytes=5-2'), null);
  assert.deepEqual(parseRange('bytes=-10'), { suffix: 10 });

  // thumbnails are public, only under thumbs/
  assert.equal((await call('GET', `/api/media/public/${globalThis.thumbKey}`)).status, 200);
  assert.equal((await call('GET', `/api/media/public/${globalThis.videoKey}`)).status, 404);
});

test('likes: one per user, idempotent, counters stay consistent', async () => {
  const like = (p, liked) => call('POST', `/api/videos/${videoId}/like`, { token: p.token(), body: { liked } });
  assert.equal((await like(alice, true)).data.likes, 1);
  assert.equal((await like(alice, true)).data.likes, 1, 'double like ignored');
  assert.equal((await like(bob, true)).data.likes, 2);
  assert.equal((await like(alice, false)).data.likes, 1);
  assert.equal((await like(alice, false)).data.likes, 1, 'double unlike ignored');
  assert.equal(mock.read(`videos/${videoId}`).likes, 1);
  assert.equal((await call('POST', `/api/videos/${videoId}/like`, { token: alice.token(), body: { liked: 'yes' } })).status, 400);
  // parallel likes from one user still produce a single like
  await Promise.all([like(alice, true), like(alice, true), like(alice, true)]);
  assert.equal(mock.read(`videos/${videoId}`).likes, 2);
});

test('saving requires the save unlock; unsave works', async () => {
  const t = alice.token();
  const denied = await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: true } });
  assert.equal(denied.data.error.code, 'ad_required');
  await new Promise((r) => setTimeout(r, 2100)); // ad starts are rate limited to one per 2 s per user
  const s = await call('POST', '/api/ads/start', { token: t, body: { videoId, purpose: 'save' } });
  assert.equal(s.status, 200, s.text);
  await new Promise((r) => setTimeout(r, 1100));
  assert.equal((await call('POST', '/api/ads/complete', { token: t, body: { sessionId: s.data.sessionId } })).status, 200);
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: true } })).status, 200);
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: true } })).status, 200);
  assert.equal(mock.read(`videos/${videoId}`).savesCount, 1);
  assert.ok(mock.read(`saves/${alice.u.uid}_${videoId}`));
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: false } })).status, 200);
  assert.equal(mock.read(`videos/${videoId}`).savesCount, 0);
  // the unlock for "watch" does not unlock "save" for other users
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: bob.token(), body: { saved: true } })).data.error.code, 'ad_required');
});

test('comments: validation, ownership, admin moderation, counters', async () => {
  const post = (p, text) => call('POST', `/api/videos/${videoId}/comments`, { token: p.token(), body: { text } });
  assert.equal((await post(alice, '   ')).status, 400);
  assert.equal((await post(alice, 'x'.repeat(1001))).status, 400);
  const c1 = await post(alice, '<b>Great</b> video!');
  assert.equal(c1.status, 201, c1.text);
  assert.equal(c1.data.comment.text, '<b>Great</b> video!', 'stored verbatim; the UI renders with textContent');
  assert.equal((await post(alice, 'spam')).status, 429, 'rate limited');
  assert.equal(mock.read(`videos/${videoId}`).commentsCount, 1);
  const id = c1.data.comment.id;
  assert.equal((await call('DELETE', `/api/comments/${id}`, { token: bob.token() })).status, 403);
  assert.ok(mock.read(`comments/${id}`));
  assert.equal((await call('DELETE', `/api/comments/${id}`, { token: alice.token() })).status, 200);
  assert.equal(mock.read(`comments/${id}`), null);
  assert.equal(mock.read(`videos/${videoId}`).commentsCount, 0);
  // admin can moderate others' comments
  await new Promise((r) => setTimeout(r, 3100));
  const c2 = await post(alice, 'second');
  assert.equal((await call('DELETE', `/api/comments/${c2.data.comment.id}`, { token: admin.token() })).status, 200);
  assert.equal((await call('DELETE', '/api/comments/not-an-id', { token: alice.token() })).status, 404);
});

test('draft videos are invisible to normal users', async () => {
  const t = admin.token();
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'draft' } });
  assert.equal((await call('GET', `/api/videos/${videoId}/state`, { token: alice.token() })).status, 404);
  assert.equal((await call('POST', `/api/videos/${videoId}/play`, { token: alice.token() })).status, 404);
  assert.equal((await call('GET', `/api/videos/${videoId}/state`, { token: t })).status, 200, 'admin can preview');
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'published' } });
});

test('postback verification mode requires provider confirmation', async () => {
  const t = admin.token();
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { ad: { verification: 'postback' } } });
  const p = bob;
  const start = await call('POST', '/api/ads/start', { token: p.token(), body: { videoId, purpose: 'watch' } });
  assert.equal(start.data.verification, 'postback');
  await new Promise((r) => setTimeout(r, 1100));
  const early = await call('POST', '/api/ads/complete', { token: p.token(), body: { sessionId: start.data.sessionId } });
  assert.equal(early.data.error.code, 'not_confirmed');
  assert.equal((await call('GET', `/api/ads/postback?sid=${start.data.sessionId}&secret=wrong`)).status, 403);
  assert.equal((await call('GET', `/api/ads/postback?sid=${start.data.sessionId}&secret=${'p'.repeat(24)}`)).status, 200);
  const done = await call('POST', '/api/ads/complete', { token: p.token(), body: { sessionId: start.data.sessionId } });
  assert.equal(done.data.unlocked, true);
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { ad: { verification: 'sponsor_opened' } } });
});

// ------------------------------------------------------------------------------------------------ admin
test('admin: dashboard, user management, suspension, no self-demotion', async () => {
  const t = admin.token();
  const d = await call('GET', '/api/admin/dashboard', { token: t });
  assert.equal(d.status, 200, d.text);
  assert.equal(d.data.totals.users, 4);
  assert.equal(d.data.totals.videos, 1);
  assert.equal(d.data.totals.views, 1);
  assert.ok(d.data.recentUsers.length > 0);

  assert.equal((await call('PATCH', `/api/admin/users/${admin.u.uid}`, { token: t, body: { role: 'user' } })).status, 400);
  assert.equal((await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'superuser' } })).status, 400);
  const sus = await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { status: 'suspended' } });
  assert.equal(sus.status, 200, sus.text);
  assert.equal(sus.data.authSync, true);
  assert.equal(mock.users.get('bob@site.test').disabled, true, 'Firebase Auth account disabled as well');
  assert.equal((await call('POST', `/api/videos/${videoId}/like`, { token: bob.token(), body: { liked: true } })).data.error.code, 'account_suspended');
  assert.equal((await call('POST', '/api/session', { token: bob.token() })).status, 403);
  await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { status: 'active' } });
  assert.equal((await call('POST', '/api/session', { token: bob.token() })).status, 200);

  // role management
  assert.equal((await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'admin' } })).status, 200);
  assert.equal((await call('GET', '/api/admin/users', { token: bob.token() })).status, 200);
  await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'user' } });
  assert.equal((await call('GET', '/api/admin/users', { token: bob.token() })).status, 403, 'demotion takes effect immediately');

  const list = await call('GET', '/api/admin/users?q=ali', { token: t });
  assert.equal(list.data.users.length, 1);
  const an = await call('GET', '/api/admin/analytics', { token: t });
  assert.equal(an.status, 200, an.text);
  assert.ok(an.data.auditLog.length > 0);
});

test('admin: media list protects files in use; delete video cascades', async () => {
  const t = admin.token();
  const list = await call('GET', '/api/admin/media?prefix=videos/', { token: t });
  assert.equal(list.data.objects[0].usedBy.id, videoId);
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { key: globalThis.videoKey } })).data.error.code, 'in_use');
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { key: 'videos/../x' } })).status, 400);

  const del = await call('DELETE', `/api/admin/videos/${videoId}?deleteMedia=1`, { token: t });
  assert.equal(del.status, 200, del.text);
  assert.equal(del.data.cleanupPending, false);
  assert.equal(mock.read(`videos/${videoId}`), null);
  assert.equal(await bucket.head(globalThis.videoKey), null, 'media removed from storage');
  for (const col of ['likes', 'saves', 'comments', 'views', 'unlocks', 'adSessions']) assert.equal(mock.ids(col).length, 0, `${col} cleaned up`);
  assert.equal((await call('DELETE', `/api/admin/media`, { token: t, body: { key: globalThis.thumbKey } })).status, 200, 'orphan thumbnail can now be deleted');
});

test('account deletion needs a recent login and removes user data', async () => {
  const stale = mock.signIdToken(alice.u, { auth_time: Math.floor(Date.now() / 1000) - 3600 });
  assert.equal((await call('DELETE', '/api/me', { token: stale, body: { confirm: true } })).data.error.code, 'reauth_required');
  assert.equal((await call('DELETE', '/api/me', { token: alice.token(), body: {} })).status, 400);
  const adminDel = await call('DELETE', '/api/me', { token: admin.token(), body: { confirm: true } });
  assert.equal(adminDel.data.error.code, 'admin_self_delete');
  const del = await call('DELETE', '/api/me', { token: alice.token(), body: { confirm: true } });
  assert.equal(del.data.done, true, del.text);
  assert.equal(mock.read(`users/${alice.u.uid}`), null);
  assert.equal(mock.users.has('alice@site.test'), false);
});

test('closed sign-ups block new profiles', async () => {
  await call('PUT', '/api/admin/settings', { token: admin.token(), body: { allowSignups: false } });
  const carol = person('carol@site.test');
  const r = await call('POST', '/api/session', { token: carol.token() });
  assert.equal(r.data.error.code, 'signups_closed');
  await call('PUT', '/api/admin/settings', { token: admin.token(), body: { allowSignups: true } });
});

test('unknown routes and methods', async () => {
  assert.equal((await call('GET', '/api/nope')).status, 404);
  assert.equal((await call('DELETE', '/api/health')).status, 405);
  const big = await call('POST', '/api/session', { token: admin.token(), raw: 'x'.repeat(10) });
  assert.equal(big.status, 200);
});
