// Local test rig: serves the static frontend, mocks Firebase Auth + Firestore REST (what the browser talks to),
// and runs the REAL Worker on a second origin (so CORS is exercised). Used by the browser tests and for manual previews:
//   node test/dev-server.js        -> http://localhost:4173  (login: boss@example.test / password123 is the admin)
// Everything here is a test double. Real Firebase / Cloudflare behaviour must still be verified after deployment.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { installMocks, signIdToken } from './mock-google.js';
import { handle } from '../worker/src/index.js';
import { invalidateSettingsCache } from '../worker/src/lib/context.js';
import { searchTokens } from '../worker/src/lib/ids.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json' };

const rand = (n) => Array.from({ length: n }, () => 'abcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(Math.random() * 36)]).join('');

export async function startRig({ webPort = 4173, apiPort = 4174, seed = true } = {}) {
  const m = await installMocks({ projectId: 'demo-proapp' });
  const webOrigin = `http://localhost:${webPort}`;
  const apiOrigin = `http://localhost:${apiPort}`;
  m.env.ALLOWED_ORIGINS = webOrigin;
  m.env.PUBLIC_API_URL = apiOrigin;
  m.env.AD_SCRIPT_HOSTS = 'ads.example.test';

  // ---------------- mock Firebase Auth
  const accounts = new Map(); // email -> { uid, password, displayName, verified }
  const refreshTokens = new Map(); // token -> uid
  const byUid = (uid) => [...accounts.values()].find((a) => a.uid === uid);
  const mailbox = [];
  const idTokenFor = async (acct) => {
    const t = await signIdToken(m.keys, 'demo-proapp', { sub: acct.uid, user_id: acct.uid, email: acct.email, email_verified: acct.verified, name: acct.displayName || undefined, auth_time: Math.floor(Date.now() / 1000), firebase: { sign_in_provider: 'password' } });
    const refresh = `rt_${rand(24)}`;
    refreshTokens.set(refresh, acct.uid);
    return { idToken: t, refreshToken: refresh, localId: acct.uid, email: acct.email, displayName: acct.displayName || '', expiresIn: '3600' };
  };
  const authErr = (res, message) => json(res, 400, { error: { code: 400, message } });

  async function authApi(req, res, url, body) {
    const action = url.pathname.split('/').pop();
    if (action === 'accounts:signUp') {
      const email = String(body.email || '').toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return authErr(res, 'INVALID_EMAIL');
      if (accounts.has(email)) return authErr(res, 'EMAIL_EXISTS');
      if (String(body.password || '').length < 6) return authErr(res, 'WEAK_PASSWORD : Password should be at least 6 characters');
      const acct = { uid: `u${rand(20)}`, email, password: body.password, displayName: '', verified: email === 'boss@example.test' };
      accounts.set(email, acct);
      return json(res, 200, await idTokenFor(acct));
    }
    if (action === 'accounts:signInWithPassword') {
      const acct = accounts.get(String(body.email || '').toLowerCase());
      if (!acct || acct.password !== body.password) return authErr(res, 'INVALID_LOGIN_CREDENTIALS');
      if (m.authUsers.get(acct.uid)?.disabled) return authErr(res, 'USER_DISABLED');
      return json(res, 200, await idTokenFor(acct));
    }
    if (action === 'accounts:sendOobCode') {
      mailbox.push({ type: body.requestType, email: body.email });
      return json(res, 200, { email: body.email });
    }
    if (action === 'accounts:update') {
      const claims = JSON.parse(Buffer.from(String(body.idToken).split('.')[1], 'base64url'));
      const acct = byUid(claims.sub);
      if (!acct) return authErr(res, 'USER_NOT_FOUND');
      if ('displayName' in body) acct.displayName = body.displayName;
      if (body.password) acct.password = body.password;
      return json(res, 200, await idTokenFor(acct));
    }
    return authErr(res, 'OPERATION_NOT_ALLOWED');
  }

  async function tokenApi(req, res, url, bodyText) {
    const params = new URLSearchParams(bodyText);
    const uid = refreshTokens.get(params.get('refresh_token'));
    const acct = uid && byUid(uid);
    if (!acct) return authErr(res, 'INVALID_REFRESH_TOKEN');
    if (m.authUsers.get(uid)?.disabled || m.authUsers.get(uid)?.deleted) return authErr(res, 'USER_DISABLED');
    const t = await idTokenFor(acct);
    return json(res, 200, { id_token: t.idToken, refresh_token: t.refreshToken, user_id: uid, expires_in: '3600' });
  }

  // ---------------- Firestore REST for the browser (rules are NOT enforced here; see firestore.rules + README)
  async function firestoreApi(req, res, url, body) {
    const r = m.fs.handle(req.method, `https://firestore.googleapis.com${url.pathname.replace(/^\/firestore\/v1/, '')}${url.search}`, body);
    res.writeHead(r.status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(await r.text());
  }

  function json(res, status, data) {
    res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(data));
  }
  const readBody = (req) => new Promise((r) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => r(Buffer.concat(chunks)));
  });

  const sponsorHits = [];
  const web = http.createServer(async (req, res) => {
    const url = new URL(req.url, webOrigin);
    try {
      if (req.method === 'OPTIONS') {
        res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' });
        return res.end();
      }
      if (url.pathname.startsWith('/auth/v1/')) return authApi(req, res, url, JSON.parse((await readBody(req)).toString() || '{}'));
      if (url.pathname.startsWith('/token/v1/token')) return tokenApi(req, res, url, (await readBody(req)).toString());
      if (url.pathname.startsWith('/firestore/v1/')) {
        const raw = (await readBody(req)).toString();
        return firestoreApi(req, res, url, raw ? JSON.parse(raw) : undefined);
      }
      if (url.pathname === '/sponsor') {
        sponsorHits.push(url.search);
        res.writeHead(200, { 'Content-Type': 'text/html' });
        return res.end('<!doctype html><title>Sponsor</title><h1>Sponsor page</h1>');
      }
      if (url.pathname === '/__mailbox') return json(res, 200, mailbox);
      if (url.pathname === '/js/config.js') {
        res.writeHead(200, { 'Content-Type': TYPES['.js'] });
        return res.end(`window.PROAPP_CONFIG = ${JSON.stringify({ firebase: { apiKey: 'test-key', projectId: 'demo-proapp' }, apiBase: apiOrigin, overrides: { authBase: `${webOrigin}/auth/v1`, tokenBase: `${webOrigin}/token/v1`, firestoreBase: `${webOrigin}/firestore/v1` } })};`);
      }
      let file = path.join(ROOT, path.normalize(decodeURIComponent(url.pathname)));
      if (!file.startsWith(ROOT)) throw new Error('bad path');
      if (url.pathname.endsWith('/')) file = path.join(file, 'index.html');
      if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
        res.writeHead(404);
        return res.end('not found');
      }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
      fs.createReadStream(file).pipe(res);
    } catch (e) {
      console.error('web error', e);
      res.writeHead(500);
      res.end('error');
    }
  });

  // ---------------- the real Worker behind a Node HTTP adapter
  const api = http.createServer(async (req, res) => {
    const body = await readBody(req);
    const headers = new Headers();
    for (const [k, v] of Object.entries(req.headers)) if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(',') : v);
    const request = new Request(`${apiOrigin}${req.url}`, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body });
    const response = await handle(request, m.env, {});
    const out = {};
    response.headers.forEach((v, k) => (out[k] = v));
    res.writeHead(response.status, out);
    if (response.body) {
      const buf = Buffer.from(await response.arrayBuffer());
      res.end(buf);
    } else res.end();
  });

  await new Promise((r) => web.listen(webPort, r));
  await new Promise((r) => api.listen(apiPort, r));

  const rig = {
    m,
    webOrigin,
    apiOrigin,
    accounts,
    mailbox,
    sponsorHits,
    close: async () => {
      web.closeAllConnections?.();
      api.closeAllConnections?.();
      await Promise.all([new Promise((r) => web.close(r)), new Promise((r) => api.close(r))]);
      m.restore();
    },
    /** Create an account the same way the app does (Auth account + Worker profile). */
    async createAccount(email, password, displayName, { verified } = {}) {
      const acct = { uid: `u${rand(20)}`, email, password, displayName, verified: verified ?? email === 'boss@example.test' };
      accounts.set(email, acct);
      const token = (await idTokenFor(acct)).idToken;
      const r = await handle(new Request(`${apiOrigin}/api/session`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, Origin: webOrigin } }), m.env, {});
      if (!r.ok) throw new Error(`session failed ${r.status}`);
      return { ...acct, token };
    },
    async seedVideo(over = {}) {
      const id = over.id || rand(16);
      const key = `videos/${crypto.randomUUID()}.mp4`;
      await m.bucket.put(key, Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypmp42'), Buffer.alloc(4000, 1)]), { httpMetadata: { contentType: 'video/mp4' } });
      const title = over.title || 'Sample video';
      m.fs.seed(`videos/${id}`, { title, description: 'A sample description.\n\nSecond paragraph.', tags: ['sample'], status: 'published', videoKey: key, thumbnailKey: '', durationSec: 95, sizeBytes: 4012, contentType: 'video/mp4', views: 0, likes: 0, commentsCount: 0, savesCount: 0, ad: { enabled: false, url: '', verification: 'sponsor_opened', minAwaySeconds: 0, label: '' }, searchTokens: searchTokens(title, 'sample'), createdAt: new Date(Date.now() - (over.ageMin || 60) * 60000), updatedAt: new Date(), createdBy: 'seed', ...over });
      return id;
    },
    resetSettingsCache: invalidateSettingsCache,
  };

  if (seed) {
    await rig.createAccount('boss@example.test', 'password123', 'Boss');
    const titles = [['Cooking Basics: Perfect Rice', 5400, 31], ['বাংলা রান্না — সহজ রেসিপি', 3100, 19], ['Street Photography Walk', 2200, 8], ['Mountain Bike Trail Tour', 800, 4], ['Lo-fi Coding Session', 120, 1], ['Home Workout in 10 Minutes', 4700, 22], ['Learn Guitar Chords Fast', 640, 3]];
    for (const [i, [title, views, likes]] of titles.entries()) await rig.seedVideo({ id: `seedvideo${i}00000`, title, views, likes, ageMin: 30 + i * 90 });
  }
  return rig;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const rig = await startRig();
  console.log(`ProApp Vault test rig running: ${rig.webOrigin}\nAdmin login: boss@example.test / password123`);
}
