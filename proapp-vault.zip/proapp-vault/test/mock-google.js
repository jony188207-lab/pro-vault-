// In-memory stand-ins for the external services the Worker talks to, so the real Worker code can be exercised
// without credentials: Firestore REST, Google OAuth token endpoint, Firebase JWKS, Identity Toolkit and an R2 bucket.
// This is a TEST DOUBLE written for this project - it implements only the subset of behaviour the Worker uses.
import { decodeFields, decodeValue, encodeFields } from '../worker/src/lib/firestore.js';

const b64u = (buf) => Buffer.from(buf).toString('base64url');
const enc = (o) => b64u(JSON.stringify(o));

export async function makeKeys() {
  const pair = await crypto.subtle.generateKey(
    { name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' },
    true,
    ['sign', 'verify'],
  );
  const jwk = { ...(await crypto.subtle.exportKey('jwk', pair.publicKey)), kid: 'test-kid', alg: 'RS256', use: 'sig' };
  const pkcs8 = Buffer.from(await crypto.subtle.exportKey('pkcs8', pair.privateKey)).toString('base64');
  const pem = `-----BEGIN PRIVATE KEY-----\n${pkcs8.match(/.{1,64}/g).join('\n')}\n-----END PRIVATE KEY-----\n`;
  return { pair, jwk, pem };
}

export async function signIdToken(keys, projectId, claims = {}, { kid = 'test-kid', alg = 'RS256', signKey } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    iss: `https://securetoken.google.com/${projectId}`,
    aud: projectId,
    iat: now - 5,
    auth_time: now - 5,
    exp: now + 3600,
    ...claims,
  };
  const head = enc({ alg, kid, typ: 'JWT' });
  const body = enc(payload);
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', (signKey || keys.pair.privateKey), new TextEncoder().encode(`${head}.${body}`));
  return `${head}.${body}.${b64u(sig)}`;
}

// ------------------------------------------------------------------ Firestore
function cmp(a, b) {
  if (a instanceof Date) a = a.getTime();
  if (b instanceof Date) b = b.getTime();
  return a < b ? -1 : a > b ? 1 : 0;
}

export class MockFirestore {
  constructor(projectId) {
    this.projectId = projectId;
    this.docs = new Map(); // path -> { fields(decoded), createTime, updateTime, version }
    this.version = 0;
    this.log = [];
  }

  raw(path) {
    return this.docs.get(path)?.data;
  }
  seed(path, data) {
    this.version++;
    const t = new Date().toISOString();
    this.docs.set(path, { data: { ...data }, createTime: t, updateTime: `${t}#${this.version}`, version: this.version });
  }
  list(collection) {
    return [...this.docs.entries()].filter(([p]) => p.startsWith(`${collection}/`) && p.split('/').length === 2).map(([p, d]) => ({ id: p.split('/')[1], ...d.data }));
  }
  count(collection) {
    return this.list(collection).length;
  }

  #toApi(path) {
    const d = this.docs.get(path);
    return { name: `projects/${this.projectId}/databases/(default)/documents/${path}`, fields: encodeFields(d.data), createTime: d.createTime, updateTime: d.updateTime };
  }

  #field(data, path) {
    return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), data);
  }

  #runQuery(sq) {
    const coll = sq.from[0].collectionId;
    let rows = [...this.docs.entries()].filter(([p]) => p.startsWith(`${coll}/`) && p.split('/').length === 2);
    const filters = !sq.where ? [] : sq.where.compositeFilter ? sq.where.compositeFilter.filters : [sq.where];
    for (const f of filters) {
      const { field, op, value } = f.fieldFilter;
      const v = decodeValue(value);
      rows = rows.filter(([, d]) => {
        const x = this.#field(d.data, field.fieldPath);
        if (x === undefined) return false;
        switch (op) {
          case 'EQUAL': return cmp(x, v) === 0;
          case 'LESS_THAN': return cmp(x, v) < 0;
          case 'LESS_THAN_OR_EQUAL': return cmp(x, v) <= 0;
          case 'GREATER_THAN': return cmp(x, v) > 0;
          case 'GREATER_THAN_OR_EQUAL': return cmp(x, v) >= 0;
          case 'ARRAY_CONTAINS': return Array.isArray(x) && x.includes(v);
          case 'IN': return Array.isArray(v) && v.some((y) => cmp(x, y) === 0);
          default: throw new Error(`mock: unsupported op ${op}`);
        }
      });
    }
    for (const o of [...(sq.orderBy || [])].reverse()) {
      const f = o.field.fieldPath;
      rows = rows.filter(([, d]) => this.#field(d.data, f) !== undefined); // Firestore omits docs lacking the ordered field
      rows.sort((a, b) => cmp(this.#field(a[1].data, f), this.#field(b[1].data, f)) * (o.direction === 'DESCENDING' ? -1 : 1));
    }
    return rows.slice(sq.offset || 0, sq.limit ? (sq.offset || 0) + sq.limit : undefined);
  }

  #commit(writes) {
    const staged = new Map(); // path -> data | null (deleted)
    const get = (p) => (staged.has(p) ? staged.get(p) : this.docs.get(p)?.data ?? null);
    const err = (code, status, message) => Object.assign(new Error(message), { code, status });
    for (const w of writes) {
      const path = (w.update?.name || w.delete).split('/documents/')[1];
      const cur = get(path);
      const pre = w.currentDocument;
      if (pre) {
        if (pre.exists === true && cur === null) throw err(404, 'NOT_FOUND', `no document to update: ${path}`);
        if (pre.exists === false && cur !== null) throw err(409, 'ALREADY_EXISTS', `document already exists: ${path}`);
        if (pre.updateTime && this.docs.get(path)?.updateTime !== pre.updateTime) throw err(400, 'FAILED_PRECONDITION', `updateTime mismatch: ${path}`);
      }
      if (w.delete) {
        staged.set(path, null);
        continue;
      }
      const incoming = decodeFields(w.update.fields || {});
      let next;
      if (w.updateMask) {
        next = { ...(cur || {}) };
        for (const f of w.updateMask.fieldPaths) next[f] = incoming[f];
      } else next = incoming;
      for (const t of w.updateTransforms || []) {
        if (t.setToServerValue === 'REQUEST_TIME') next[t.fieldPath] = new Date();
        else if (t.increment) next[t.fieldPath] = (Number(next[t.fieldPath]) || 0) + Number(decodeValue(t.increment));
      }
      staged.set(path, next);
    }
    for (const [p, data] of staged) {
      if (data === null) this.docs.delete(p);
      else {
        this.version++;
        const prev = this.docs.get(p);
        const t = new Date().toISOString();
        this.docs.set(p, { data, createTime: prev?.createTime || t, updateTime: `${t}#${this.version}`, version: this.version });
      }
    }
  }

  handle(method, url, body) {
    const u = new URL(url);
    const marker = '/documents';
    const idx = u.pathname.indexOf(marker);
    const rest = u.pathname.slice(idx + marker.length);
    const json = (status, data) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });
    this.log.push(`${method} ${rest}`);
    try {
      if (method === 'GET') {
        const path = decodeURIComponent(rest.replace(/^\//, ''));
        return this.docs.has(path) ? json(200, this.#toApi(path)) : json(404, { error: { code: 404, status: 'NOT_FOUND', message: 'not found' } });
      }
      if (rest === ':batchGet') {
        return json(
          200,
          body.documents.map((name) => {
            const path = name.split('/documents/')[1];
            return this.docs.has(path) ? { found: this.#toApi(path) } : { missing: name };
          }),
        );
      }
      if (rest === ':runQuery') {
        const rows = this.#runQuery(body.structuredQuery);
        return json(200, rows.length ? rows.map(([p]) => ({ document: this.#toApi(p) })) : [{}]);
      }
      if (rest === ':runAggregationQuery') {
        const sq = body.structuredAggregationQuery;
        const rows = this.#runQuery(sq.structuredQuery);
        const out = {};
        for (const a of sq.aggregations) {
          if (a.count) out[a.alias] = { integerValue: String(rows.length) };
          else {
            const f = a.sum.field.fieldPath;
            out[a.alias] = { integerValue: String(rows.reduce((s, [, d]) => s + (Number(d.data[f]) || 0), 0)) };
          }
        }
        return json(200, [{ result: { aggregateFields: out } }]);
      }
      if (rest === ':commit') {
        this.#commit(body.writes);
        return json(200, { writeResults: body.writes.map(() => ({})) });
      }
    } catch (e) {
      if (e.status) return json(e.code, { error: { code: e.code, status: e.status, message: e.message } });
      throw e;
    }
    return json(404, { error: { code: 404, status: 'NOT_FOUND', message: `mock: unhandled ${method} ${rest}` } });
  }
}

// ------------------------------------------------------------------ R2
export class MockR2 {
  constructor() {
    this.objects = new Map();
    this.uploads = new Map();
  }
  async put(key, body, opts = {}) {
    const buf = ArrayBuffer.isView(body)
      ? Buffer.from(body.buffer, body.byteOffset, body.byteLength)
      : body instanceof ArrayBuffer
        ? Buffer.from(body)
        : Buffer.from(await new Response(body).arrayBuffer());
    this.objects.set(key, { buf, httpMetadata: opts.httpMetadata || {}, uploaded: new Date() });
  }
  #meta(key, o) {
    return { key, size: o.buf.length, httpMetadata: o.httpMetadata, httpEtag: `"etag-${key.length}-${o.buf.length}"`, uploaded: o.uploaded };
  }
  async head(key) {
    const o = this.objects.get(key);
    return o ? this.#meta(key, o) : null;
  }
  async get(key, opts) {
    const o = this.objects.get(key);
    if (!o) return null;
    let offset = 0;
    let length = o.buf.length;
    const r = opts?.range;
    if (r) {
      if (r.suffix !== undefined) {
        length = Math.min(r.suffix, o.buf.length);
        offset = o.buf.length - length;
      } else {
        offset = r.offset ?? 0;
        if (offset >= o.buf.length) throw new Error('range not satisfiable');
        length = Math.min(r.length ?? o.buf.length - offset, o.buf.length - offset);
      }
    }
    const slice = o.buf.subarray(offset, offset + length);
    return { ...this.#meta(key, o), body: new Response(slice).body, range: r ? { offset, length } : undefined };
  }
  async delete(key) {
    this.objects.delete(key);
  }
  async list({ prefix = '', limit = 1000 } = {}) {
    const all = [...this.objects.entries()].filter(([k]) => k.startsWith(prefix)).map(([k, o]) => this.#meta(k, o));
    return { objects: all.slice(0, limit), truncated: all.length > limit, cursor: undefined };
  }
  async createMultipartUpload(key, opts) {
    const uploadId = `upload-${Math.random().toString(36).slice(2)}-${Date.now()}`;
    this.uploads.set(uploadId, { key, parts: new Map(), httpMetadata: opts?.httpMetadata || {} });
    return { uploadId, key };
  }
  resumeMultipartUpload(key, uploadId) {
    const up = this.uploads.get(uploadId);
    const self = this;
    return {
      async uploadPart(n, body) {
        if (!up || up.key !== key) throw new Error('no such upload');
        const buf = Buffer.from(body instanceof ArrayBuffer ? body : await new Response(body).arrayBuffer());
        up.parts.set(n, buf);
        return { partNumber: n, etag: `part-${n}-${buf.length}` };
      },
      async complete(parts) {
        if (!up || up.key !== key) throw new Error('no such upload');
        const buf = Buffer.concat(parts.map((p) => up.parts.get(p.partNumber)));
        self.objects.set(key, { buf, httpMetadata: up.httpMetadata, uploaded: new Date() });
        self.uploads.delete(uploadId);
      },
      async abort() {
        self.uploads.delete(uploadId);
      },
    };
  }
}

// ------------------------------------------------------------------ the combined fetch mock
export async function installMocks({ projectId = 'test-project' } = {}) {
  const keys = await makeKeys();
  const fs = new MockFirestore(projectId);
  const bucket = new MockR2();
  const authUsers = new Map(); // uid -> { disabled, deleted }
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (input, init = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const u = new URL(url);
    const method = (init.method || 'GET').toUpperCase();
    if (u.hostname === 'firestore.googleapis.com') return fs.handle(method, url, init.body ? JSON.parse(init.body) : undefined);
    if (u.hostname === 'oauth2.googleapis.com') return Response.json({ access_token: 'mock-access-token', expires_in: 3600 });
    if (u.hostname === 'www.googleapis.com' && u.pathname.includes('/service_accounts/v1/jwk/')) {
      return Response.json({ keys: [keys.jwk] }, { headers: { 'Cache-Control': 'max-age=3600' } });
    }
    if (u.hostname === 'identitytoolkit.googleapis.com') {
      const body = JSON.parse(init.body || '{}');
      const action = u.pathname.split(':').pop();
      authUsers.set(body.localId, { ...(authUsers.get(body.localId) || {}), ...(action === 'delete' ? { deleted: true } : { disabled: body.disableUser }) });
      return Response.json({});
    }
    return new Response(`mock: unexpected outbound request to ${url}`, { status: 599 });
  };
  const serviceAccount = JSON.stringify({ client_email: 'test@test-project.iam.gserviceaccount.com', private_key: keys.pem, token_uri: 'https://oauth2.googleapis.com/token' });
  const env = {
    FIREBASE_PROJECT_ID: projectId,
    FIREBASE_SERVICE_ACCOUNT_JSON: serviceAccount,
    MEDIA_SIGNING_SECRET: 'test-signing-secret-0123456789abcdef',
    AD_POSTBACK_SECRET: 'test-postback-secret-0123456789',
    ALLOWED_ORIGINS: 'https://app.example.test',
    BOOTSTRAP_ADMIN_EMAILS: 'boss@example.test',
    AD_SCRIPT_HOSTS: 'ads.example.test,*.adnet.test',
    MAX_VIDEO_BYTES: String(50 * 1024 * 1024),
    STORAGE_PROVIDER: 'r2',
    MEDIA_BUCKET: bucket,
  };
  return { keys, fs, bucket, env, authUsers, restore: () => (globalThis.fetch = realFetch), token: (uid, claims) => signIdToken(keys, projectId, { sub: uid, user_id: uid, ...claims }) };
}
