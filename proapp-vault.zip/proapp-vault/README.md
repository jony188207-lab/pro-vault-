# ProApp Vault

A mobile-first dark video streaming web app.

| Part | Tech | Where |
| --- | --- | --- |
| Frontend | HTML, CSS, JavaScript (ES modules, no build step) | `public/` |
| Accounts | Firebase Authentication (email + password) | called from `public/js/lib/firebase.js` |
| App data | Cloud Firestore | rules in `firestore.rules` |
| API + admin backend | Cloudflare Worker | `worker/` |
| Media | Cloudflare R2 behind a swappable **Storage Adapter** | `worker/src/storage/` |

## Status: read this first

This repository was built and tested **without access to real Firebase, Cloudflare or Adsterra accounts**. Nothing is deployed and no credentials exist in it.

What was verified, using in-memory stand-ins for Google services (`test/mock-backend.js`):

* **25 automated tests pass** (`node --test test/*.test.js`): token verification, ownership and admin checks, the like/save/comment rules, the ad-unlock flow, server-side view counting, signed video URLs and range requests, upload validation, banner sanitising, user suspension, cascade deletion, and a lint of `firestore.rules`.
* **A 40-step browser run passes** in Chromium on a phone-size screen (`node test/e2e.mjs`): sign-up, login, admin setup, video upload through the UI, the locked/unlock/watch flow, like, comment, save, search, profile and admin screens, with the production Content-Security-Policy applied and no console errors.

What was **not** verified and needs you:

* `firestore.rules` was only linted, not run. Run them in the Firebase emulator before launch (see "Testing the security rules").
* Nothing was run against real Firebase, R2 or Adsterra. Expect to fix small configuration issues on first deploy.
* Video playback of a real, large file, and real Adsterra banner rendering, were not exercised.
* The first-time Firestore index build (step 4) can take a few minutes.

## A note on the "ad before watching" feature

Adsterra's publisher terms (section 6) prohibit using incentives to increase impressions or clicks, and prohibit forcing or confusing visitors into taking an action. Gating content behind an ad may fall under that, and other networks have similar rules. So:

* The feature is **off by default**, and the admin must tick "I checked that my ad network allows this flow" before it can be turned on.
* The app **never claims an ad was watched**. A plain ad link gives no proof of that. What the server can prove is: the sponsor link was issued to this user, at least N seconds passed (measured by the server, not the browser), and, only if your provider sends server-to-server postbacks, that the provider confirmed (`verification: postback`).
* The wording is yours to edit in Admin -> Ads. Write it honestly (for example "Open the sponsor page, then come back"), and check the rules of your ad network. The Bangla example text from the brief is the default.

## 1. Prerequisites

* A Google account and a Firebase project.
* A Cloudflare account (R2 needs a payment method on file; the free allowance is generous).
* A Netlify account (or any static host).
* Node.js 20+ on your computer, then `npm install -g wrangler` (or use `npx wrangler`) and `npm install -g firebase-tools`.

## 2. Firebase

1. Create a project at <https://console.firebase.google.com>.
2. **Build -> Authentication -> Get started -> Email/Password -> Enable.**
3. **Build -> Firestore Database -> Create database** (production mode, pick a region near your users).
4. Deploy the rules and indexes from this folder:
   ```
   firebase login
   firebase use --add          # choose your project
   firebase deploy --only firestore:rules,firestore:indexes
   ```
   Wait until the indexes show "Enabled" in the console (Firestore -> Indexes). Until then, the home list and search show a "needs an index" message.
5. **Project settings -> General -> Your apps -> Web app** (`</>`): copy `apiKey` and `projectId`. These are public by design.
6. **Project settings -> Service accounts -> Generate new private key.** This downloads a JSON file. It is a **secret**: it goes only into the Worker (step 4 below) and nowhere else. Never commit it.
7. **Authentication -> Settings -> Authorized domains:** add your Netlify domain.

## 3. Cloudflare R2

```
cd worker
npx wrangler login
npx wrangler r2 bucket create proapp-vault-media
```

The bucket stays **private**. The Worker reaches it through a binding (`MEDIA_BUCKET` in `wrangler.toml`), so no R2 access keys are created or needed.

## 4. The Worker (backend API)

Edit `worker/wrangler.toml` `[vars]`:

| Variable | Meaning |
| --- | --- |
| `FIREBASE_PROJECT_ID` | your Firebase project id |
| `ALLOWED_ORIGINS` | your site origin(s), exact, comma separated, no trailing slash, e.g. `https://proapp-vault.netlify.app` |
| `BOOTSTRAP_ADMIN_EMAILS` | e-mail(s) that become admin on first sign-in. The address must be **verified** in Firebase Auth. |
| `AD_SCRIPT_HOSTS` | hosts banner `<script src>` may load from, e.g. `ads.example-network.com` (see "Allow your ad network") |
| `MAX_VIDEO_BYTES` | upload limit in bytes (default 2 GiB) |
| `STORAGE_PROVIDER` | `r2` |

Set the secrets (each command prompts for the value):

```
cd worker
npx wrangler secret put FIREBASE_SERVICE_ACCOUNT_JSON   # paste the entire JSON file contents
npx wrangler secret put MEDIA_SIGNING_SECRET            # a random string, 32+ characters
# optional, only for providers that send server-to-server postbacks:
npx wrangler secret put AD_POSTBACK_SECRET
```

Generate a random value with: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

Deploy:

```
npx wrangler deploy
```

Wrangler prints the Worker URL (`https://proapp-vault-api.<you>.workers.dev`). Check `<url>/api/health` returns `{"ok":true,...}`.

For local development, copy `worker/.dev.vars.example` to `worker/.dev.vars`, fill it in, and run `npx wrangler dev`.

### Allow your ad network (Adsterra banner)

1. In Adsterra, create a banner and copy its code. It usually looks like `<script>atOptions = {...};</script><script src="https://HOST/KEY/invoke.js"></script>`.
2. Put `HOST` in `AD_SCRIPT_HOSTS` in `wrangler.toml` and run `npx wrangler deploy`.
3. Paste the code in Admin -> Ads -> Banner. The server checks it and the app shows it inside a sandboxed iframe served by the Worker. If the host is missing, the save is refused and the message names the host to add.

## 5. The frontend (Netlify)

1. Edit `public/js/config.js`: fill in `firebase.apiKey`, `firebase.projectId` and `apiBase` (your Worker URL, no trailing slash).
2. Edit `public/_headers`: replace every `YOUR-WORKER-URL` with your Worker **origin including https://** (replace every occurrence, including in the comment line). This is the Content-Security-Policy. If you skip it, images, video and the banner are blocked.
3. Deploy the `public` folder: drag it onto <https://app.netlify.com/drop>, or connect the repo (publish directory `public`, no build command).
4. Take the resulting site URL back to `ALLOWED_ORIGINS` in `wrangler.toml` and redeploy the Worker. Add the domain to Firebase authorized domains (step 2.7).

Any other static host (Cloudflare Pages, Firebase Hosting, Vercel) works. You must send the headers from `public/_headers` in that host's format.

## 6. First run

1. Open the site, **Create account** with the e-mail from `BOOTSTRAP_ADMIN_EMAILS`.
2. Verify the e-mail (profile page -> "Send verification email", click the link, then "I verified it"). Admin rights are only granted for a verified address.
3. An **Admin** tab appears. Go to Videos -> Add video, upload a file and a thumbnail.
4. Admin -> Settings and Ads: site texts, list sizes, banner, and (optionally) the sponsor step.

## 7. How it is secured

* **Browsers can read some Firestore data but can never write it.** Every `allow write` in `firestore.rules` is `false`. Profiles, roles, views, likes, saves, comments, unlocks and settings are all written by the Worker with the service account.
* **The Worker re-checks everything.** It verifies the Firebase ID token's signature, issuer, audience and expiry, then loads the user's profile from Firestore. The role (`user`/`admin`) and status (`active`/`suspended`) come from that profile, never from the request or a token claim, so a demotion or suspension applies immediately.
* **No privilege escalation:** a user cannot write their own profile; admins cannot change their own role; the first admin comes only from a verified e-mail in `BOOTSTRAP_ADMIN_EMAILS`.
* **Views are counted on the server** when a signed stream URL is issued (once per user per video per 30 minutes). The browser never reports a view.
* **One like per user per video** is enforced by the document id (`<uid>_<videoId>`) and a "must not exist" write precondition, so parallel requests cannot double-count.
* **Comments:** only the author or an admin can delete; rate-limited; shown with `textContent` so HTML in a comment is displayed as text.
* **Media:** uploads go through the Worker (admin only), which checks type, size and the file's leading bytes. Videos play only through short-lived HMAC-signed URLs; the bucket is private. Files used by a video cannot be deleted.
* **Admin HTML (banner):** only a small tag allowlist survives; `<script src>` must be https and on `AD_SCRIPT_HOSTS`; inline scripts may only assign a plain object (`atOptions = {...}`); event handlers and unsafe URLs are removed. It is never inserted into the app: it is served from the Worker in a sandboxed iframe (no `allow-same-origin`) with its own CSP.
* **Suspension** sets the profile status and disables the Firebase Auth account.
* **Account deletion** requires a login from the last 5 minutes and removes the user's data.
* **Secrets** (service account, signing key) exist only as Worker secrets. The frontend contains only the public Firebase web key.

Remaining risks to be aware of: Firebase email/password sign-in has no CAPTCHA by default (consider App Check); ad-network scripts you allow run in their own sandbox but can still show whatever that network serves; a leaked stream URL works until it expires (6 hours).

## 8. Database structure

| Collection | Document id | Fields | Browser access |
| --- | --- | --- | --- |
| `users` | Firebase uid | email, displayName, role, status, emailVerified, createdAt, lastActiveAt | own profile read only |
| `videos` | uuid | title, description, tags, status, videoKey, thumbnailKey, durationSec, sizeBytes, contentType, ad{enabled,url,verification,minAwaySeconds,label}, views, likes, commentsCount, savesCount, searchTokens, createdAt, updatedAt | read published |
| `comments` | uuid | videoId, uid, authorName, text, createdAt | read |
| `likes` | `<uid>_<videoId>` | uid, videoId, createdAt | read own |
| `saves` | `<uid>_<videoId>` | uid, videoId, createdAt | read own |
| `views` | `<uid>_<videoId>` | uid, videoId, lastViewAt | none |
| `adSessions` | uuid | uid, videoId, purpose, status, verification, minAwaySeconds, openedAt, expiresAt | none |
| `unlocks` | `<uid>_<videoId>_<watch\|save>` | uid, videoId, purpose, expiresAt, unlockedAt | none |
| `settings` | `public` | siteName, tagline, popularCount, homeListLimit, allowSignups, commentsEnabled, banner, gate, texts | read |
| `stats` | `d_YYYYMMDD` | day, views, likes, comments, signups | admin read |
| `auditLogs` | uuid | actorUid, action, target, meta, createdAt | admin read |

## 9. API reference (Worker)

Authenticated routes need `Authorization: Bearer <Firebase ID token>`.

| Method + path | Who | Purpose |
| --- | --- | --- |
| `GET /api/health` | public | liveness |
| `POST /api/session` | signed in | create/refresh profile after login |
| `PATCH /api/me`, `DELETE /api/me` | user | rename; delete account |
| `GET /api/videos/:id/state` | user | liked/saved and unlock status |
| `POST /api/videos/:id/like` `{liked}` | user | like/unlike |
| `POST /api/videos/:id/save` `{saved}` | user | save/unsave (needs save unlock if gated) |
| `POST /api/videos/:id/comments` `{text}` | user | add comment |
| `DELETE /api/comments/:id` | author or admin | delete comment |
| `POST /api/videos/:id/play` | user | signed stream URL + server-side view count |
| `POST /api/ads/start`, `POST /api/ads/complete` | user | sponsor step |
| `GET/POST /api/ads/postback?sid&secret` | ad provider | server-to-server confirmation |
| `GET /api/ads/banner-frame` | public | sandboxed banner document |
| `GET /api/media/stream?t=` , `GET /api/media/public/thumbs/*` | token / public | video (Range supported) / thumbnails |
| `/api/admin/*` | admin | dashboard, analytics, users, videos, settings, uploads, media |

## 10. Changing the storage provider

Implement the methods listed at the top of `worker/src/storage/index.js` in a new class (for example `S3Storage`), register it in `PROVIDERS`, set `STORAGE_PROVIDER`. Firestore stores only provider-neutral object keys, and the rest of the code only calls the adapter.

## 11. Testing

```
node --test test/*.test.js     # Worker + rules lint, no dependencies, ~10 s
node test/e2e.mjs              # browser run; needs Playwright with Chromium installed
```

The tests use an in-memory stand-in for Firestore, Firebase Auth and R2. It is a re-implementation, so it can differ from the real services.

### Testing the security rules

Before launch, run the rules against the emulator, for example with `@firebase/rules-unit-testing`:

```
firebase emulators:exec --only firestore "npm test"
```

Cases worth asserting: a signed-in user cannot write to any collection; cannot read another user's `users/{uid}`, `likes` or `saves`; cannot read `views`, `unlocks`, `adSessions`; the public can read `published` videos but not drafts; an admin (profile role `admin`) can read drafts, `stats` and `auditLogs`.

## 12. Troubleshooting

| Symptom | Likely cause |
| --- | --- |
| "Setup needed" screen | `public/js/config.js` still has placeholders |
| Everything fails with a network/CORS error | `ALLOWED_ORIGINS` does not match the site origin exactly |
| Thumbnails, video or banner blocked | `YOUR-WORKER-URL` not replaced in `public/_headers` |
| "The database needs an index" | indexes not deployed or still building |
| No Admin tab | e-mail not verified, or not in `BOOTSTRAP_ADMIN_EMAILS`, or the account was created before that was set (an admin can also promote you in Users) |
| Banner save refused: "host not allowed" | add the host to `AD_SCRIPT_HOSTS` and redeploy |
| Large uploads fail | check `MAX_VIDEO_BYTES`; uploads are 8 MB parts and retry 3 times |
