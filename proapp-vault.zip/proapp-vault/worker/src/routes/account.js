// Session bootstrap and account management for the signed-in user.
import { W, FirestoreError, identityAdmin } from '../lib/firestore.js';
import { forbidden, json, readJson, unauthorized, badRequest } from '../lib/http.js';
import { cleanText, parseList } from '../lib/sanitize.js';
import { publicUser, statsWrite } from '../lib/context.js';
import { cleanupUserRound } from '../lib/cleanup.js';

const ACTIVE_TOUCH_MS = 5 * 60 * 1000;

function defaultName(claims) {
  const fromToken = typeof claims.name === 'string' ? claims.name : '';
  const fromEmail = (claims.email || '').split('@')[0];
  try {
    return cleanText(fromToken || fromEmail || 'Member', { field: 'Name', min: 1, max: 40 });
  } catch {
    return 'Member';
  }
}

/** POST /api/session - called right after sign-in. Creates the profile on first use. */
export async function session(c) {
  const { claims } = c.auth;
  let user = c.auth.user;
  const email = String(claims.email || '').toLowerCase();
  const settings = await c.settings();
  // Bootstrap admins: only trusted when Firebase says the e-mail address is verified.
  const bootstrap = claims.email_verified === true && email && parseList(c.env.BOOTSTRAP_ADMIN_EMAILS).includes(email);

  if (!user) {
    if (!settings.allowSignups) throw forbidden('New sign-ups are currently closed', 'signups_closed');
    const fresh = {
      email,
      displayName: defaultName(claims),
      photoURL: '',
      role: bootstrap ? 'admin' : 'user',
      status: 'active',
      emailVerified: claims.email_verified === true,
    };
    try {
      await c.fs.commit([
        W.set(`users/${c.uid}`, fresh, {
          exists: false,
          transforms: [
            { field: 'createdAt', serverTime: true },
            { field: 'lastActiveAt', serverTime: true },
          ],
        }),
        statsWrite({ signups: 1 }),
      ]);
    } catch (e) {
      if (!(e instanceof FirestoreError && e.isPrecondition)) throw e; // concurrent first call: profile already exists
    }
    const doc = await c.fs.get(`users/${c.uid}`);
    user = { ...doc.data, uid: c.uid };
  } else {
    if (user.status !== 'active') throw forbidden('This account is suspended', 'account_suspended');
    const patch = {};
    if (user.emailVerified !== (claims.email_verified === true)) patch.emailVerified = claims.email_verified === true;
    if (email && user.email !== email) patch.email = email;
    if (bootstrap && user.role !== 'admin') patch.role = 'admin';
    const last = user.lastActiveAt instanceof Date ? user.lastActiveAt.getTime() : 0;
    const touch = Date.now() - last > ACTIVE_TOUCH_MS;
    if (touch || Object.keys(patch).length) {
      await c.fs.commit([W.update(`users/${c.uid}`, patch, { exists: true, transforms: touch ? [{ field: 'lastActiveAt', serverTime: true }] : [] })]);
      user = { ...user, ...patch };
    }
  }
  return json({ user: publicUser(user) });
}

/** PATCH /api/me - change display name. */
export async function updateMe(c) {
  const body = await readJson(c.request);
  const displayName = cleanText(body.displayName, { field: 'Display name', min: 2, max: 40 });
  await c.fs.commit([W.update(`users/${c.uid}`, { displayName }, { exists: true })]);
  return json({ user: publicUser({ ...c.user, displayName }) });
}

/**
 * DELETE /api/me - permanently delete the account and its data.
 * Requires a recent sign-in (auth_time within 5 minutes). Call repeatedly while { done: false }.
 */
export async function deleteMe(c) {
  const body = await readJson(c.request);
  if (body.confirm !== true) throw badRequest('Confirmation required', 'confirm_required');
  const authTime = Number(c.auth.claims.auth_time || 0);
  if (!authTime || Date.now() / 1000 - authTime > 300) throw unauthorized('Please sign in again to delete your account', 'reauth_required');
  if (c.user.role === 'admin') throw forbidden('Administrators cannot delete their own account. Ask another admin to remove the admin role first.', 'admin_self_delete');
  const { pending } = await cleanupUserRound(c.fs, c.uid);
  if (pending) return json({ done: false });
  await c.fs.commit([W.del(`users/${c.uid}`)]);
  let authDeleted = true;
  try {
    await identityAdmin(c.env, 'delete', { localId: c.uid });
  } catch (e) {
    authDeleted = false;
    console.error('Auth user deletion failed', e.message);
  }
  return json({ done: true, authDeleted });
}
