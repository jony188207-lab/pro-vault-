// Administrator endpoints. Every handler here is reached only after Ctx.authenticate('admin'), which re-reads the
// caller's role from Firestore on each request.
import { W, identityAdmin } from '../lib/firestore.js';
import { badRequest, conflict, HttpError, intParam, json, notFound, readJson } from '../lib/http.js';
import { bool, cleanText, httpsUrl, intInRange, oneOf } from '../lib/sanitize.js';
import { applySettingsPatch, SETTINGS_PATH } from '../lib/settings.js';
import { invalidateSettingsCache, publicUser } from '../lib/context.js';
import { searchTokens, uuid } from '../lib/ids.js';
import { cleanupVideoRound } from '../lib/cleanup.js';
import { IMAGE_TYPES, THUMB_KEY, VIDEO_KEY, VIDEO_TYPES, sniffMatches } from '../storage/index.js';

const PART_SIZE = 8 * 1024 * 1024;
const MAX_PART_BYTES = 16 * 1024 * 1024;
const MAX_THUMB_BYTES = 5 * 1024 * 1024;
const DEFAULT_MAX_VIDEO = 2 * 1024 * 1024 * 1024;

// ------------------------------------------------------------------ dashboard & analytics
export async function dashboard(c) {
  const [users, suspended, videos, recent, daily] = await Promise.all([
    c.fs.aggregate({ collection: 'users', aggregations: [{ op: 'count', alias: 'total' }] }),
    c.fs.aggregate({ collection: 'users', where: [['status', '==', 'suspended']], aggregations: [{ op: 'count', alias: 'total' }] }),
    c.fs.aggregate({
      collection: 'videos',
      aggregations: [
        { op: 'count', alias: 'videos' },
        { op: 'sum', field: 'views', alias: 'views' },
        { op: 'sum', field: 'likes', alias: 'likes' },
        { op: 'sum', field: 'commentsCount', alias: 'comments' },
        { op: 'sum', field: 'savesCount', alias: 'saves' },
      ],
    }),
    c.fs.query({ collection: 'users', orderBy: [['lastActiveAt', 'desc']], limit: 8 }),
    c.fs.query({ collection: 'stats', orderBy: [['day', 'desc']], limit: 14 }),
  ]);
  return json({
    totals: { users: users.total, suspendedUsers: suspended.total, ...videos },
    recentUsers: recent.map((d) => publicUser({ ...d.data, uid: d.id })),
    daily: daily.map((d) => d.data).reverse(),
  });
}

export async function analytics(c) {
  const [topViews, topLikes, daily, logs] = await Promise.all([
    c.fs.query({ collection: 'videos', orderBy: [['views', 'desc']], limit: 10 }),
    c.fs.query({ collection: 'videos', orderBy: [['likes', 'desc']], limit: 10 }),
    c.fs.query({ collection: 'stats', orderBy: [['day', 'desc']], limit: 30 }),
    c.fs.query({ collection: 'auditLogs', orderBy: [['createdAt', 'desc']], limit: 25 }),
  ]);
  const slim = (d) => ({ id: d.id, title: d.data.title, views: d.data.views || 0, likes: d.data.likes || 0, comments: d.data.commentsCount || 0, saves: d.data.savesCount || 0, status: d.data.status });
  return json({
    topByViews: topViews.map(slim),
    topByLikes: topLikes.map(slim),
    daily: daily.map((d) => d.data).reverse(),
    auditLog: logs.map((d) => ({ id: d.id, ...d.data })),
  });
}

// ------------------------------------------------------------------ users
export async function listUsers(c) {
  const limit = intParam(c.url.searchParams.get('limit'), { min: 1, max: 50, def: 25 });
  const offset = intParam(c.url.searchParams.get('offset'), { min: 0, max: 5000, def: 0 });
  const q = (c.url.searchParams.get('q') || '').trim().toLowerCase().slice(0, 80);
  const spec = q
    ? { collection: 'users', where: [['email', '>=', q], ['email', '<', `${q}`]], orderBy: [['email', 'asc']] }
    : { collection: 'users', orderBy: [['createdAt', 'desc']] };
  const docs = await c.fs.query({ ...spec, limit: limit + 1, offset });
  return json({ users: docs.slice(0, limit).map((d) => publicUser({ ...d.data, uid: d.id })), hasMore: docs.length > limit });
}

export async function updateUser(c) {
  const uid = c.params.uid;
  if (!/^[A-Za-z0-9]{6,128}$/.test(uid)) throw notFound('User not found');
  if (uid === c.uid) throw badRequest('You cannot change your own role or status', 'self_change');
  const body = await readJson(c.request);
  const target = await c.fs.get(`users/${uid}`);
  if (!target) throw notFound('User not found');
  const changes = {};
  if ('role' in body) changes.role = oneOf(body.role, ['user', 'admin'], { field: 'role' });
  if ('status' in body) changes.status = oneOf(body.status, ['active', 'suspended'], { field: 'status' });
  if (!Object.keys(changes).length) throw badRequest('Nothing to change');
  await c.fs.commit([W.update(`users/${uid}`, changes, { exists: true })]);
  let authSync = null;
  if (changes.status && changes.status !== target.data.status) {
    try {
      await identityAdmin(c.env, 'update', { localId: uid, disableUser: changes.status === 'suspended' });
      authSync = true;
    } catch (e) {
      authSync = false;
      console.error('Auth sync failed', e.message);
    }
  }
  await c.audit('user.update', uid, { ...changes, email: target.data.email });
  return json({ user: publicUser({ ...target.data, ...changes, uid }), authSync });
}

// ------------------------------------------------------------------ videos
function parseAd(input, existing = {}) {
  const ad = { enabled: false, url: '', verification: 'sponsor_opened', minAwaySeconds: 0, label: '', ...existing };
  if (input === undefined) return ad;
  if (!input || typeof input !== 'object') throw badRequest('ad must be an object');
  if ('enabled' in input) ad.enabled = bool(input.enabled);
  if ('url' in input) ad.url = httpsUrl(input.url, { field: 'Ad URL', allowEmpty: true });
  if ('verification' in input) ad.verification = oneOf(input.verification, ['sponsor_opened', 'postback'], { field: 'Ad verification' });
  if ('minAwaySeconds' in input) ad.minAwaySeconds = input.minAwaySeconds ? intInRange(input.minAwaySeconds, { field: 'Seconds away', min: 1, max: 120 }) : 0;
  if ('label' in input) ad.label = cleanText(input.label, { field: 'Ad label', max: 60 });
  if (ad.enabled && !ad.url) throw badRequest('Add an ad URL before enabling the ad for this video', 'invalid_field', { field: 'ad.url' });
  return ad;
}

function parseTags(tags) {
  if (!Array.isArray(tags)) throw badRequest('tags must be a list');
  if (tags.length > 10) throw badRequest('Use at most 10 tags', 'invalid_field', { field: 'tags' });
  return [...new Set(tags.map((t) => cleanText(t, { field: 'Tag', min: 1, max: 30 }).toLowerCase()))];
}

async function checkMedia(c, key, regex, label) {
  if (typeof key !== 'string' || !regex.test(key)) throw badRequest(`${label} key is invalid`, 'invalid_field', { field: label });
  const head = await c.storage.headObject(key);
  if (!head) throw badRequest(`${label} was not found in storage. Upload it first.`, 'media_missing', { field: label });
  return head;
}

async function buildVideo(c, body, existing) {
  const out = {};
  const merged = { ...(existing || {}) };
  if (!existing || 'title' in body) merged.title = out.title = cleanText(body.title, { field: 'Title', min: 1, max: 120 });
  if ('description' in body || !existing) merged.description = out.description = cleanText(body.description ?? '', { field: 'Description', max: 2000, multiline: true });
  if ('tags' in body || !existing) merged.tags = out.tags = parseTags(body.tags ?? []);
  if ('status' in body || !existing) merged.status = out.status = oneOf(body.status, ['published', 'draft'], { field: 'status', def: 'draft' });
  if ('durationSec' in body) merged.durationSec = out.durationSec = body.durationSec === null ? 0 : intInRange(body.durationSec, { field: 'Duration', min: 0, max: 86400 });
  if (!existing || 'videoKey' in body) {
    const head = await checkMedia(c, body.videoKey, VIDEO_KEY, 'videoKey');
    merged.videoKey = out.videoKey = body.videoKey;
    out.sizeBytes = merged.sizeBytes = head.size;
    out.contentType = merged.contentType = head.contentType;
  }
  if ('thumbnailKey' in body) {
    if (body.thumbnailKey) await checkMedia(c, body.thumbnailKey, THUMB_KEY, 'thumbnailKey');
    merged.thumbnailKey = out.thumbnailKey = body.thumbnailKey || '';
  }
  if ('ad' in body || !existing) merged.ad = out.ad = parseAd(body.ad, existing?.ad);
  if (!existing) {
    out.thumbnailKey ??= '';
    out.durationSec ??= 0;
  }
  if ('title' in out || 'tags' in out) out.searchTokens = searchTokens(merged.title, (merged.tags || []).join(' '));
  return out;
}

export async function listVideos(c) {
  const limit = intParam(c.url.searchParams.get('limit'), { min: 1, max: 50, def: 25 });
  const offset = intParam(c.url.searchParams.get('offset'), { min: 0, max: 5000, def: 0 });
  const docs = await c.fs.query({ collection: 'videos', orderBy: [['createdAt', 'desc']], limit: limit + 1, offset });
  return json({ videos: docs.slice(0, limit).map((d) => ({ id: d.id, ...d.data })), hasMore: docs.length > limit });
}

export async function createVideo(c) {
  const body = await readJson(c.request);
  const data = await buildVideo(c, body, null);
  const id = uuid();
  await c.fs.commit([
    W.set(
      `videos/${id}`,
      { ...data, views: 0, likes: 0, commentsCount: 0, savesCount: 0, createdBy: c.uid },
      { exists: false, transforms: [{ field: 'createdAt', serverTime: true }, { field: 'updatedAt', serverTime: true }] },
    ),
  ]);
  await c.audit('video.create', id, { title: data.title });
  return json({ id }, 201);
}

export async function updateVideo(c) {
  const id = c.params.id;
  const existing = await c.fs.get(`videos/${id}`);
  if (!existing) throw notFound('Video not found');
  const body = await readJson(c.request);
  const data = await buildVideo(c, body, existing.data);
  if (!Object.keys(data).length) throw badRequest('Nothing to change');
  await c.fs.commit([W.update(`videos/${id}`, data, { exists: true, transforms: [{ field: 'updatedAt', serverTime: true }] })]);
  await c.audit('video.update', id, { fields: Object.keys(data) });
  return json({ id });
}

/** DELETE /api/admin/videos/:id[?deleteMedia=1] - safe to call repeatedly until cleanupPending is false. */
export async function deleteVideo(c) {
  const id = c.params.id;
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(id)) throw notFound('Video not found');
  const doc = await c.fs.get(`videos/${id}`);
  if (doc) {
    await c.fs.commit([W.del(`videos/${id}`, { exists: true })]);
    if (c.url.searchParams.get('deleteMedia') === '1') {
      for (const key of [doc.data.videoKey, doc.data.thumbnailKey]) if (key) await c.storage.deleteObject(key);
    }
    await c.audit('video.delete', id, { title: doc.data.title, deleteMedia: c.url.searchParams.get('deleteMedia') === '1' });
  }
  const { pending } = await cleanupVideoRound(c.fs, id);
  return json({ deleted: true, cleanupPending: pending });
}

// ------------------------------------------------------------------ settings
export async function getSettings(c) {
  return json({ settings: await c.settings({ fresh: true }), adScriptHostsConfigured: !!String(c.env.AD_SCRIPT_HOSTS || '').trim() });
}

export async function putSettings(c) {
  const body = await readJson(c.request, 128 * 1024);
  const current = await c.settings({ fresh: true });
  const { settings, warnings } = applySettingsPatch(current, body, { env: c.env, adminUid: c.uid });
  await c.fs.commit([W.set(SETTINGS_PATH, settings, { transforms: [{ field: 'updatedAt', serverTime: true }] })]);
  invalidateSettingsCache();
  await c.audit('settings.update', 'settings/public', { keys: Object.keys(body) });
  return json({ settings, warnings });
}

// ------------------------------------------------------------------ media (uploads, listing, deletion)
function maxVideoBytes(env) {
  const n = Number(env.MAX_VIDEO_BYTES);
  return Number.isFinite(n) && n > 0 ? n : DEFAULT_MAX_VIDEO;
}

export async function uploadInit(c) {
  const body = await readJson(c.request);
  const kind = oneOf(body.kind, ['video', 'thumbnail'], { field: 'kind' });
  const size = intInRange(body.size, { field: 'size', min: 1, max: Number.MAX_SAFE_INTEGER });
  if (kind === 'video') {
    const ext = VIDEO_TYPES[body.contentType];
    if (!ext) throw badRequest(`Unsupported video type. Allowed: ${Object.keys(VIDEO_TYPES).join(', ')}`, 'unsupported_type');
    if (size > maxVideoBytes(c.env)) throw new HttpError(413, `Video is larger than the allowed ${Math.round(maxVideoBytes(c.env) / 1048576)} MB`, 'too_large');
    const key = `videos/${uuid()}.${ext}`;
    const { uploadId } = await c.storage.createMultipart(key, { contentType: body.contentType });
    return json({ mode: 'multipart', key, uploadId, partSize: PART_SIZE });
  }
  const ext = IMAGE_TYPES[body.contentType];
  if (!ext) throw badRequest(`Unsupported image type. Allowed: ${Object.keys(IMAGE_TYPES).join(', ')}`, 'unsupported_type');
  if (size > MAX_THUMB_BYTES) throw new HttpError(413, 'Thumbnail must be 5 MB or smaller', 'too_large');
  return json({ mode: 'single', key: `thumbs/${uuid()}.${ext}`, contentType: body.contentType });
}

/** PUT /api/admin/uploads/object?key=thumbs/<uuid>.<ext> (thumbnails; body = image bytes) */
export async function uploadObject(c) {
  const key = c.url.searchParams.get('key') || '';
  if (!THUMB_KEY.test(key)) throw badRequest('Invalid thumbnail key', 'invalid_key');
  const contentType = Object.entries(IMAGE_TYPES).find(([, ext]) => key.endsWith(`.${ext}`))?.[0];
  if (Number(c.request.headers.get('Content-Length') || 0) > MAX_THUMB_BYTES) throw new HttpError(413, 'Thumbnail must be 5 MB or smaller', 'too_large');
  const buf = await c.request.arrayBuffer();
  if (!buf.byteLength || buf.byteLength > MAX_THUMB_BYTES) throw new HttpError(413, 'Thumbnail must be 5 MB or smaller', 'too_large');
  if (!sniffMatches(contentType, new Uint8Array(buf, 0, Math.min(16, buf.byteLength)))) throw badRequest('File content does not match its image type', 'bad_content');
  if (await c.storage.headObject(key)) throw conflict('That key is already used', 'key_exists');
  await c.storage.putObject(key, buf, { contentType });
  await c.audit('media.upload', key, { size: buf.byteLength });
  return json({ key, size: buf.byteLength, contentType });
}

function multipartParams(c) {
  const key = c.url.searchParams.get('key') || '';
  const uploadId = c.url.searchParams.get('uploadId') || '';
  if (!VIDEO_KEY.test(key)) throw badRequest('Invalid video key', 'invalid_key');
  if (!/^[\w.~-]{8,512}$/.test(uploadId)) throw badRequest('Invalid upload id', 'invalid_upload');
  return { key, uploadId };
}

export async function uploadPart(c) {
  const { key, uploadId } = multipartParams(c);
  const partNumber = intInRange(c.url.searchParams.get('partNumber'), { field: 'partNumber', min: 1, max: 10000 });
  if (Number(c.request.headers.get('Content-Length') || 0) > MAX_PART_BYTES) throw new HttpError(413, 'Part too large', 'too_large');
  const buf = await c.request.arrayBuffer();
  if (!buf.byteLength || buf.byteLength > MAX_PART_BYTES) throw new HttpError(413, 'Part too large', 'too_large');
  const part = await c.storage.uploadPart(key, uploadId, partNumber, buf);
  return json(part);
}

export async function uploadComplete(c) {
  const body = await readJson(c.request, 512 * 1024);
  const { key, uploadId } = { key: body.key, uploadId: body.uploadId };
  if (!VIDEO_KEY.test(key || '')) throw badRequest('Invalid video key', 'invalid_key');
  if (!/^[\w.~-]{8,512}$/.test(uploadId || '')) throw badRequest('Invalid upload id', 'invalid_upload');
  if (!Array.isArray(body.parts) || !body.parts.length || body.parts.length > 10000) throw badRequest('parts are required');
  const parts = body.parts.map((p) => ({
    partNumber: intInRange(p.partNumber, { field: 'partNumber', min: 1, max: 10000 }),
    etag: cleanText(p.etag, { field: 'etag', min: 1, max: 200 }),
  }));
  await c.storage.completeMultipart(key, uploadId, parts);
  const head = await c.storage.headObject(key);
  const reject = async (status, message, code) => {
    await c.storage.deleteObject(key);
    throw new HttpError(status, message, code);
  };
  if (!head) throw new HttpError(500, 'Upload could not be finalised', 'upload_failed');
  if (head.size > maxVideoBytes(c.env)) await reject(413, 'Video is larger than the allowed size', 'too_large');
  const first = await c.storage.getObject(key, { range: { offset: 0, length: 16 } });
  const bytes = new Uint8Array(await new Response(first.body).arrayBuffer());
  if (!sniffMatches(head.contentType, bytes)) await reject(422, 'File content does not look like a valid video of the declared type', 'bad_content');
  await c.audit('media.upload', key, { size: head.size });
  return json({ key, size: head.size, contentType: head.contentType });
}

export async function uploadAbort(c) {
  const body = await readJson(c.request);
  if (!VIDEO_KEY.test(body.key || '')) throw badRequest('Invalid video key', 'invalid_key');
  try {
    await c.storage.abortMultipart(body.key, String(body.uploadId || ''));
  } catch {
    /* already completed or aborted */
  }
  return json({ aborted: true });
}

export async function listMedia(c) {
  const prefix = oneOf(c.url.searchParams.get('prefix') || 'videos/', ['videos/', 'thumbs/'], { field: 'prefix' });
  const cursor = c.url.searchParams.get('cursor') || undefined;
  const [list, videos] = await Promise.all([c.storage.listObjects({ prefix, limit: 50, cursor }), c.fs.query({ collection: 'videos', limit: 500 })]);
  const used = new Map();
  for (const v of videos) {
    if (v.data.videoKey) used.set(v.data.videoKey, { id: v.id, title: v.data.title });
    if (v.data.thumbnailKey) used.set(v.data.thumbnailKey, { id: v.id, title: v.data.title });
  }
  return json({
    objects: list.objects.map((o) => ({ ...o, usedBy: used.get(o.key) || null })),
    cursor: list.cursor,
  });
}

export async function deleteMedia(c) {
  const body = await readJson(c.request);
  const key = body.key;
  if (!VIDEO_KEY.test(key || '') && !THUMB_KEY.test(key || '')) throw badRequest('Invalid media key', 'invalid_key');
  const field = VIDEO_KEY.test(key) ? 'videoKey' : 'thumbnailKey';
  const inUse = await c.fs.query({ collection: 'videos', where: [[field, '==', key]], limit: 1 });
  if (inUse.length) throw conflict(`This file is used by "${inUse[0].data.title}". Remove it from the video first.`, 'in_use');
  await c.storage.deleteObject(key);
  await c.audit('media.delete', key);
  return json({ deleted: true });
}
