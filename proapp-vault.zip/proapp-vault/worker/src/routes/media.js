// Media delivery. Videos are only reachable through short-lived signed URLs issued by /api/videos/:id/play;
// thumbnails (keys under thumbs/) are public.
import { HttpError, notFound } from '../lib/http.js';
import { verifyToken } from '../lib/signing.js';
import { THUMB_KEY, VIDEO_KEY } from '../storage/index.js';

/** Parse a single-range header. Returns { offset, length } | { offset } | { suffix } | null. */
export function parseRange(header) {
  const m = /^bytes=(\d*)-(\d*)$/.exec((header || '').trim());
  if (!m || (m[1] === '' && m[2] === '')) return null;
  if (m[1] === '') return { suffix: Number(m[2]) };
  const start = Number(m[1]);
  if (m[2] === '') return { offset: start };
  const end = Number(m[2]);
  if (end < start) return null;
  return { offset: start, length: end - start + 1 };
}

async function serve(c, key, { cache, download = false }) {
  const range = parseRange(c.request.headers.get('Range'));
  let obj;
  try {
    obj = await c.storage.getObject(key, { range: range || undefined });
  } catch (e) {
    if (!range) throw e;
    const head = await c.storage.headObject(key);
    if (!head) throw notFound('Not found');
    return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${head.size}` } });
  }
  if (!obj) throw notFound('Not found');
  const headers = new Headers({
    'Content-Type': obj.contentType,
    'Accept-Ranges': 'bytes',
    'Cache-Control': cache,
    'X-Content-Type-Options': 'nosniff',
    'Cross-Origin-Resource-Policy': 'cross-origin',
    ETag: obj.etag || '',
  });
  if (!obj.etag) headers.delete('ETag');
  if (download) headers.set('Content-Disposition', 'inline');
  let status = 200;
  if (range && obj.range) {
    status = 206;
    const start = obj.range.offset ?? 0;
    const len = obj.range.length ?? obj.size - start;
    headers.set('Content-Range', `bytes ${start}-${start + len - 1}/${obj.size}`);
    headers.set('Content-Length', String(len));
  } else {
    headers.set('Content-Length', String(obj.size));
  }
  return new Response(c.request.method === 'HEAD' ? null : obj.body, { status, headers });
}

/** GET /api/media/stream?t=<signed token> */
export async function streamVideo(c) {
  const payload = await verifyToken(c.url.searchParams.get('t'), c.env.MEDIA_SIGNING_SECRET);
  if (!payload || !VIDEO_KEY.test(payload.k || '')) throw new HttpError(403, 'This video link has expired. Reload the page to continue.', 'link_expired');
  return serve(c, payload.k, { cache: 'private, max-age=3600', download: true });
}

/** GET /api/media/public/thumbs/<file> */
export async function publicThumb(c) {
  const key = decodeURIComponent(c.url.pathname.replace('/api/media/public/', ''));
  if (!THUMB_KEY.test(key)) throw notFound('Not found');
  return serve(c, key, { cache: 'public, max-age=86400, immutable' });
}
