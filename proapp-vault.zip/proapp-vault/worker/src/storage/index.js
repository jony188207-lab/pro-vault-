// Storage Adapter factory.
//
// Contract every provider must implement (all methods async):
//   putObject(key, body, { contentType })
//   headObject(key)                         -> { key, size, contentType, etag, uploaded } | null
//   getObject(key, { range })               -> { body, size, contentType, etag, range } | null
//   deleteObject(key)
//   listObjects({ prefix, limit, cursor })  -> { objects: [{ key, size, uploaded, contentType }], cursor }
//   createMultipart(key, { contentType })   -> { uploadId }
//   uploadPart(key, uploadId, n, body)      -> { partNumber, etag }
//   completeMultipart(key, uploadId, parts)
//   abortMultipart(key, uploadId)
//
// To switch provider later (S3, Backblaze B2, Supabase Storage ...), add a class with the same methods,
// register it below and set STORAGE_PROVIDER. Firestore only ever stores provider-neutral object keys.
import { R2Storage } from './r2.js';

const PROVIDERS = {
  r2: (env) => new R2Storage(env.MEDIA_BUCKET),
};

export function createStorage(env) {
  const name = (env.STORAGE_PROVIDER || 'r2').toLowerCase();
  const factory = PROVIDERS[name];
  if (!factory) throw new Error(`Unknown STORAGE_PROVIDER "${name}". Available: ${Object.keys(PROVIDERS).join(', ')}`);
  return factory(env);
}

// ---------- provider-independent media rules ----------
export const VIDEO_TYPES = { 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov' };
export const IMAGE_TYPES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
export const VIDEO_KEY = /^videos\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(mp4|webm|mov)$/;
export const THUMB_KEY = /^thumbs\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(jpg|png|webp)$/;

/** Check the first bytes of an upload against its declared type. */
export function sniffMatches(contentType, b) {
  const at = (i, ...bytes) => bytes.every((v, k) => b[i + k] === v);
  if (contentType === 'image/jpeg') return at(0, 0xff, 0xd8, 0xff);
  if (contentType === 'image/png') return at(0, 0x89, 0x50, 0x4e, 0x47);
  if (contentType === 'image/webp') return at(0, 0x52, 0x49, 0x46, 0x46) && at(8, 0x57, 0x45, 0x42, 0x50);
  if (contentType === 'video/webm') return at(0, 0x1a, 0x45, 0xdf, 0xa3);
  if (contentType === 'video/mp4' || contentType === 'video/quicktime') return at(4, 0x66, 0x74, 0x79, 0x70); // "ftyp"
  return false;
}
