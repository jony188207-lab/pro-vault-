// Cloudflare R2 implementation of the Storage Adapter contract (see storage/index.js).
// R2 is reached through a Worker *binding* (env.MEDIA_BUCKET) so no R2 access keys exist anywhere.

export class R2Storage {
  constructor(bucket) {
    if (!bucket) throw new Error('R2 bucket binding MEDIA_BUCKET is not configured (see wrangler.toml)');
    this.bucket = bucket;
    this.name = 'r2';
  }

  async putObject(key, body, { contentType } = {}) {
    await this.bucket.put(key, body, { httpMetadata: { contentType } });
  }

  async headObject(key) {
    const o = await this.bucket.head(key);
    return o ? { key, size: o.size, contentType: o.httpMetadata?.contentType || 'application/octet-stream', etag: o.httpEtag, uploaded: o.uploaded } : null;
  }

  /** range: { offset, length } | { offset } | { suffix } | undefined. Returns null when the object does not exist. */
  async getObject(key, { range } = {}) {
    const o = await this.bucket.get(key, range ? { range } : undefined);
    if (!o) return null;
    return {
      body: o.body,
      size: o.size,
      contentType: o.httpMetadata?.contentType || 'application/octet-stream',
      etag: o.httpEtag,
      range: o.range || null,
    };
  }

  async deleteObject(key) {
    await this.bucket.delete(key);
  }

  async listObjects({ prefix, limit = 50, cursor } = {}) {
    const res = await this.bucket.list({ prefix, limit, cursor: cursor || undefined });
    return {
      objects: res.objects.map((o) => ({ key: o.key, size: o.size, uploaded: o.uploaded, contentType: o.httpMetadata?.contentType || null })),
      cursor: res.truncated ? res.cursor : null,
    };
  }

  async createMultipart(key, { contentType } = {}) {
    const up = await this.bucket.createMultipartUpload(key, { httpMetadata: { contentType } });
    return { uploadId: up.uploadId };
  }

  async uploadPart(key, uploadId, partNumber, body) {
    const up = this.bucket.resumeMultipartUpload(key, uploadId);
    const part = await up.uploadPart(partNumber, body);
    return { partNumber: part.partNumber, etag: part.etag };
  }

  async completeMultipart(key, uploadId, parts) {
    const up = this.bucket.resumeMultipartUpload(key, uploadId);
    await up.complete(parts.map((p) => ({ partNumber: p.partNumber, etag: p.etag })));
  }

  async abortMultipart(key, uploadId) {
    const up = this.bucket.resumeMultipartUpload(key, uploadId);
    await up.abort();
  }
}
