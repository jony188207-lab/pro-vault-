// ProApp Vault API - Cloudflare Worker entry point.
import { Ctx } from './lib/context.js';
import { HttpError, corsHeaders, errorResponse, json, withHeaders } from './lib/http.js';
import { session, updateMe, deleteMe } from './routes/account.js';
import { videoState, setLike, setSave, addComment, deleteComment, playVideo } from './routes/videos.js';
import { startAd, completeAd, postback, bannerFrame } from './routes/ads.js';
import { streamVideo, publicThumb } from './routes/media.js';
import * as admin from './routes/admin.js';

// [method, path pattern, handler, auth level]  (auth: public | session | user | admin)
const ROUTES = [
  ['GET', '/api/health', async () => json({ ok: true, name: 'proapp-vault-api' }), 'public'],
  ['GET', '/api/ads/banner-frame', bannerFrame, 'public'],
  ['GET', '/api/ads/postback', postback, 'public'],
  ['POST', '/api/ads/postback', postback, 'public'],
  ['GET', '/api/media/stream', streamVideo, 'public'],
  ['GET', '/api/media/public/*', publicThumb, 'public'],

  ['POST', '/api/session', session, 'session'],
  ['PATCH', '/api/me', updateMe, 'user'],
  ['DELETE', '/api/me', deleteMe, 'user'],

  ['GET', '/api/videos/:id/state', videoState, 'user'],
  ['POST', '/api/videos/:id/like', setLike, 'user'],
  ['POST', '/api/videos/:id/save', setSave, 'user'],
  ['POST', '/api/videos/:id/comments', addComment, 'user'],
  ['POST', '/api/videos/:id/play', playVideo, 'user'],
  ['DELETE', '/api/comments/:id', deleteComment, 'user'],
  ['POST', '/api/ads/start', startAd, 'user'],
  ['POST', '/api/ads/complete', completeAd, 'user'],

  ['GET', '/api/admin/dashboard', admin.dashboard, 'admin'],
  ['GET', '/api/admin/analytics', admin.analytics, 'admin'],
  ['GET', '/api/admin/users', admin.listUsers, 'admin'],
  ['PATCH', '/api/admin/users/:uid', admin.updateUser, 'admin'],
  ['GET', '/api/admin/videos', admin.listVideos, 'admin'],
  ['POST', '/api/admin/videos', admin.createVideo, 'admin'],
  ['PATCH', '/api/admin/videos/:id', admin.updateVideo, 'admin'],
  ['DELETE', '/api/admin/videos/:id', admin.deleteVideo, 'admin'],
  ['GET', '/api/admin/settings', admin.getSettings, 'admin'],
  ['PUT', '/api/admin/settings', admin.putSettings, 'admin'],
  ['POST', '/api/admin/uploads/init', admin.uploadInit, 'admin'],
  ['PUT', '/api/admin/uploads/object', admin.uploadObject, 'admin'],
  ['PUT', '/api/admin/uploads/part', admin.uploadPart, 'admin'],
  ['POST', '/api/admin/uploads/complete', admin.uploadComplete, 'admin'],
  ['POST', '/api/admin/uploads/abort', admin.uploadAbort, 'admin'],
  ['GET', '/api/admin/media', admin.listMedia, 'admin'],
  ['DELETE', '/api/admin/media', admin.deleteMedia, 'admin'],
].map(([method, pattern, handler, auth]) => {
  const names = [];
  const src = pattern
    .replace(/\*$/, '(.*)')
    .replace(/:([a-z]+)/g, (_, n) => {
      names.push(n);
      return '([^/]+)';
    });
  return { method, regex: new RegExp(`^${src}$`), names, handler, auth };
});

function match(method, pathname) {
  let pathMatched = false;
  for (const r of ROUTES) {
    const m = r.regex.exec(pathname);
    if (!m) continue;
    pathMatched = true;
    if (r.method !== method) continue;
    const params = {};
    r.names.forEach((n, i) => (params[n] = decodeURIComponent(m[i + 1])));
    return { route: r, params };
  }
  return { route: null, pathMatched };
}

export async function handle(request, env, execCtx) {
  const url = new URL(request.url);
  const cors = corsHeaders(request, env);
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  try {
    const method = request.method === 'HEAD' ? 'GET' : request.method;
    const { route, params, pathMatched } = match(method, url.pathname);
    if (!route) throw new HttpError(pathMatched ? 405 : 404, pathMatched ? 'Method not allowed' : 'Not found', pathMatched ? 'method_not_allowed' : 'not_found');
    const c = new Ctx(request, env, execCtx);
    c.params = params;
    if (route.auth !== 'public') await c.authenticate(route.auth);
    const response = await route.handler(c);
    return withHeaders(response, cors);
  } catch (err) {
    return withHeaders(errorResponse(err), cors);
  }
}

export default { fetch: handle };
