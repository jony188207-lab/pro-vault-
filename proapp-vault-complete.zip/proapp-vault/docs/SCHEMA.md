# Firestore schema
users/{tg_<id>} uid, telegramId, firstName, username, status(active|blocked), role, firstSeenAt, lastSeenAt
videos/{auto} title, description, thumbnailUrl, category, tags[], order, featured, status(draft|published|unpublished), unlockPolicy{required,allowLinkVisit}, viewCount, likeCount, commentCount, saveCount, createdAt, publishedAt
videoPrivate/{videoId} playbackUrl (admin/server only)
videoLikes/{videoId}__{uid} · savedVideos/{uid}__{videoId} · unlockEntitlements/{uid}__{videoId}__{watch|save} (kind: verified|link_visit)
comments/{auto} uid, videoId, text, status(visible|hidden|deleted), createdAt · adminAuditLogs/{auto} action, actorUid, target, createdAt
Planned (rules exist, no API yet): products, posts, galleries, customPages, miniApps, menuItems, appConfig, viewEvents, adEvents, reports.
