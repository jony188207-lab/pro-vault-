import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { verifyInitData } from '../src/lib/telegram.ts';
import { hasAdminClaim } from '../src/lib/claims.ts';
import { allow } from '../src/lib/ratelimit.ts';
import { signParams, checkUpload, isCloudinaryUrl } from '../src/lib/cloudinary.ts';
import { classifyLink } from '../src/lib/links.ts';
import { decideUnlock, UnlockError } from '../src/lib/unlock.ts';

const TOKEN = '1:T'; const NOW = 1_800_000_000;
const mk = (extra: Record<string, string> = {}, forgeHash = false) => {
  const f = { auth_date: String(NOW - 5), user: JSON.stringify({ id: 7 }), ...extra };
  const check = Object.keys(f).sort().map((k) => `${k}=${(f as Record<string, string>)[k]}`).join('\n');
  const hash = forgeHash ? 'a'.repeat(64) : createHmac('sha256', createHmac('sha256', 'WebAppData').update(TOKEN).digest()).update(check).digest('hex');
  return new URLSearchParams({ ...f, hash }).toString();
};
test('telegram initData', () => {
  assert.equal(verifyInitData(mk(), TOKEN, 3600, NOW).id, 7);
  assert.throws(() => verifyInitData(mk({}, true), TOKEN, 3600, NOW));
  assert.throws(() => verifyInitData(mk(), 'other', 3600, NOW));
  assert.throws(() => verifyInitData(mk({ auth_date: '1' }), TOKEN, 3600, NOW));
});
test('admin claim must be boolean true', () => {
  assert.equal(hasAdminClaim({ admin: true, uid: 'x' }), true);
  for (const t of [{ admin: 'true' }, { admin: 1 }, { role: 'admin' }, null, undefined]) assert.equal(hasAdminClaim(t as never), false);
});
test('rate limit', () => { assert.ok(allow('k', 2, 1000, 0)); assert.ok(allow('k', 2, 1000, 1)); assert.ok(!allow('k', 2, 1000, 2)); assert.ok(allow('k', 2, 1000, 5000)); });
test('cloudinary', () => {
  assert.equal(signParams({ eager: 'w_400,h_300,c_pad|w_260,h_200,c_crop', public_id: 'sample_image', timestamp: 1315060510 }, 'abcd'), 'bfd09f95f331f558cbd1320e67aa8d488770583e');
  assert.equal(checkUpload('video', 'video/mp4', 10), null); assert.ok(checkUpload('video', 'text/html', 10)); assert.ok(checkUpload('image', 'image/png', 99_000_000));
  assert.ok(isCloudinaryUrl('https://res.cloudinary.com/x/y.jpg')); assert.ok(!isCloudinaryUrl('https://evil.com/res.cloudinary.com')); assert.ok(!isCloudinaryUrl('javascript:1'));
});
test('links', () => {
  for (const bad of ['javascript:alert(1)', 'data:text/html,x', 'http://t.me/abcde_bot/app', 'https://t.me/abcde_bot', 'tg://resolve?domain=a', 'https://x.com', 'https://u:p@ok.com']) assert.equal(classifyLink(bad, ['ok.com']), null, bad);
  assert.equal(classifyLink('https://t.me/abcde_bot/app', [])?.kind, 'telegram'); assert.equal(classifyLink('https://sub.ok.com/a', ['ok.com'])?.kind, 'web');
});
test('unlock: link visit is never verified; bad proofs rejected', () => {
  const base = { uid: 'u', videoId: 'v', scope: 'watch' as const, nowSec: NOW, secret: 's' };
  assert.equal(decideUnlock({ ...base, policy: { required: true, allowLinkVisit: true } }).kind, 'link_visit');
  assert.throws(() => decideUnlock({ ...base, policy: { required: true, allowLinkVisit: false } }), UnlockError);
  assert.throws(() => decideUnlock({ ...base, policy: { required: false, allowLinkVisit: true } }), UnlockError);
  const payload = JSON.stringify({ uid: 'u', videoId: 'v', scope: 'watch', ts: NOW }); const signature = createHmac('sha256', 's').update(payload).digest('hex');
  assert.equal(decideUnlock({ ...base, policy: { required: true, allowLinkVisit: false }, proof: { payload, signature } }).kind, 'verified');
  assert.throws(() => decideUnlock({ ...base, policy: { required: true, allowLinkVisit: true }, proof: { payload, signature: '0'.repeat(64) } }), UnlockError);
  assert.throws(() => decideUnlock({ ...base, uid: 'other', policy: { required: true, allowLinkVisit: true }, proof: { payload, signature } }), UnlockError);
});
