import test from 'node:test';
import assert from 'node:assert/strict';
import { ConfigError, readFirebaseConfig } from '../src/lib/firebaseConfig.ts';
const good = { NEXT_PUBLIC_FIREBASE_API_KEY: 'AIza' + 'a'.repeat(35), NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: 'p.firebaseapp.com', NEXT_PUBLIC_FIREBASE_PROJECT_ID: 'p',
  NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET: 'p.firebasestorage.app', NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID: '1', NEXT_PUBLIC_FIREBASE_APP_ID: '1:1:web:a' };
test('valid config passes; measurement id optional', () => {
  assert.equal(readFirebaseConfig(good).projectId, 'p'); assert.equal(readFirebaseConfig(good).measurementId, undefined);
  assert.equal(readFirebaseConfig({ ...good, NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID: 'G-X' }).measurementId, 'G-X');
});
test('missing, empty, placeholder and malformed keys are rejected with a clear, value-free message', () => {
  for (const bad of [{ ...good, NEXT_PUBLIC_FIREBASE_API_KEY: undefined }, { ...good, NEXT_PUBLIC_FIREBASE_API_KEY: '  ' }, { ...good, NEXT_PUBLIC_FIREBASE_API_KEY: 'YOUR_API_KEY' }, { ...good, NEXT_PUBLIC_FIREBASE_API_KEY: 'not-a-key' }]) {
    assert.throws(() => readFirebaseConfig(bad), (e: unknown) => e instanceof ConfigError && e.message.includes('NEXT_PUBLIC_FIREBASE_API_KEY') && !e.message.includes('not-a-key'));
  }
  assert.throws(() => readFirebaseConfig({}), (e: unknown) => e instanceof ConfigError && e.problems.length === 6);
});
