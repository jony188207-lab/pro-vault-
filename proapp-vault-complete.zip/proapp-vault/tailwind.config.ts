import type { Config } from 'tailwindcss';
const config: Config = { content: ['./src/**/*.{ts,tsx}'], theme: { extend: { colors: { vault: { bg: '#0b0613', card: '#160d26', line: '#2c1d49', accent: '#7c3aed', soft: '#a78bfa' } } } }, plugins: [] };
export default config;
