/** Admin = boolean custom claim `admin: true`, set only by scripts/set-admin.mjs. Input must be a verified token. */
export const hasAdminClaim = (token: Readonly<Record<string, unknown>> | null | undefined): boolean => token?.admin === true;
