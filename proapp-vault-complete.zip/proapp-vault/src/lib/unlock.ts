import { createHmac, timingSafeEqual } from 'node:crypto';
export type Scope = 'watch' | 'save';
export type UnlockKind = 'verified' | 'link_visit';
export class UnlockError extends Error {}
export const entitlementId = (uid: string, videoId: string, scope: Scope) => `${uid}__${videoId}__${scope}`;
export interface Policy { required: boolean; allowLinkVisit: boolean }
/** `verified` only with a provider-signed, fresh event bound to this user/video/scope. A bare link visit is recorded as `link_visit`, never as a verified reward. */
export function decideUnlock(i: { uid: string; videoId: string; scope: Scope; policy: Policy; proof?: { payload: string; signature: string }; secret?: string; nowSec: number }) {
  if (!i.policy.required) throw new UnlockError('unlock not required');
  const id = entitlementId(i.uid, i.videoId, i.scope);
  if (!i.proof) { if (!i.policy.allowLinkVisit) throw new UnlockError('verified completion required'); return { id, kind: 'link_visit' as UnlockKind }; }
  if (!i.secret || !/^[0-9a-f]{64}$/.test(i.proof.signature)) throw new UnlockError('cannot verify');
  const ok = timingSafeEqual(createHmac('sha256', i.secret).update(i.proof.payload).digest(), Buffer.from(i.proof.signature, 'hex'));
  let e: { uid?: string; videoId?: string; scope?: string; ts?: number } = {};
  try { e = JSON.parse(i.proof.payload); } catch { /* handled below */ }
  if (!ok || e.uid !== i.uid || e.videoId !== i.videoId || e.scope !== i.scope || typeof e.ts !== 'number' || i.nowSec - e.ts > 600 || e.ts > i.nowSec + 60) throw new UnlockError('invalid completion');
  return { id, kind: 'verified' as UnlockKind };
}
