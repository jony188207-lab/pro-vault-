/** Pure, browser/server-safe validation of the PUBLIC Firebase web config. Never includes values in messages. */
export class ConfigError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`Firebase client configuration is missing or invalid: ${problems.join(', ')}. Set these NEXT_PUBLIC_FIREBASE_* variables in Vercel (Production scope) and redeploy.`);
    this.name = 'ConfigError';
    this.problems = problems;
  }
}
const FIELDS = [
  ['apiKey', 'NEXT_PUBLIC_FIREBASE_API_KEY'], ['authDomain', 'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN'], ['projectId', 'NEXT_PUBLIC_FIREBASE_PROJECT_ID'],
  ['storageBucket', 'NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET'], ['messagingSenderId', 'NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID'], ['appId', 'NEXT_PUBLIC_FIREBASE_APP_ID'],
] as const;
const PLACEHOLDER = /^(your[_-]|<|changeme|todo|xxx|replace)/i;
export interface FirebaseWebConfig { apiKey: string; authDomain: string; projectId: string; storageBucket: string; messagingSenderId: string; appId: string; measurementId?: string }
export function readFirebaseConfig(env: Readonly<Record<string, string | undefined>>): FirebaseWebConfig {
  const problems: string[] = []; const out: Record<string, string> = {};
  for (const [key, name] of FIELDS) {
    const v = (env[name] ?? '').trim();
    if (!v) problems.push(`${name} (missing/empty)`); else if (PLACEHOLDER.test(v)) problems.push(`${name} (placeholder)`); else out[key] = v;
  }
  if (out.apiKey && !/^AIza[\w-]{35}$/.test(out.apiKey)) problems.push('NEXT_PUBLIC_FIREBASE_API_KEY (not a Firebase web API key)');
  if (problems.length) throw new ConfigError(problems);
  const m = (env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID ?? '').trim();
  return { ...(out as unknown as FirebaseWebConfig), ...(m && !PLACEHOLDER.test(m) ? { measurementId: m } : {}) };
}
