import { createHmac, timingSafeEqual } from 'node:crypto';
export class TelegramAuthError extends Error {}
export interface TelegramUser { id: number; first_name?: string; username?: string }
/** Telegram Mini App initData check: HMAC_SHA256(key = HMAC_SHA256("WebAppData", botToken), dataCheckString). */
export function verifyInitData(initData: string, botToken: string, maxAgeSec: number, nowSec: number): TelegramUser {
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash || !/^[0-9a-f]{64}$/.test(hash)) throw new TelegramAuthError('missing hash');
  params.delete('hash');
  const check = [...params.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('\n');
  const key = createHmac('sha256', 'WebAppData').update(botToken).digest();
  const expected = createHmac('sha256', key).update(check).digest();
  if (!timingSafeEqual(expected, Buffer.from(hash, 'hex'))) throw new TelegramAuthError('bad signature');
  const authDate = Number(params.get('auth_date'));
  if (!Number.isFinite(authDate) || nowSec - authDate > maxAgeSec || authDate > nowSec + 60) throw new TelegramAuthError('expired');
  let user: TelegramUser;
  try { user = JSON.parse(params.get('user') ?? ''); } catch { throw new TelegramAuthError('missing user'); }
  if (!Number.isSafeInteger(user.id)) throw new TelegramAuthError('bad user');
  return user;
}
export const firebaseUid = (telegramId: number) => `tg_${telegramId}`;
