import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import { getAuth, signInWithCustomToken, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { ConfigError, readFirebaseConfig } from '../firebaseConfig.ts';
export { ConfigError };

// NEXT_PUBLIC_* values are inlined by Next.js only when written as literal `process.env.NEXT_PUBLIC_X` references.
const publicEnv = {
  NEXT_PUBLIC_FIREBASE_API_KEY: process.env.NEXT_PUBLIC_FIREBASE_API_KEY, NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  NEXT_PUBLIC_FIREBASE_PROJECT_ID: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID, NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID, NEXT_PUBLIC_FIREBASE_APP_ID: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
};
/** Lazy and browser-only: importing this module never initializes Firebase, so server prerendering cannot trigger auth/invalid-api-key. Invalid config throws ConfigError (never swallowed here). */
export function getFirebaseApp(): FirebaseApp {
  if (typeof window === 'undefined') throw new Error('The Firebase client SDK is browser-only; use the Admin SDK on the server.');
  return getApps().length ? getApp() : initializeApp(readFirebaseConfig(publicEnv));
}
export const getFirebaseAuth = (): Auth => getAuth(getFirebaseApp());
export const getFirebaseDb = (): Firestore => getFirestore(getFirebaseApp());
export async function startAnalytics() {
  if (typeof window === 'undefined') return null;
  const { getAnalytics, isSupported } = await import('firebase/analytics');
  return (await isSupported()) ? getAnalytics(getFirebaseApp()) : null;
}
type Tg = { Telegram?: { WebApp?: { initData?: string; ready?: () => void } } };
export const telegramInitData = () => (window as unknown as Tg).Telegram?.WebApp?.initData ?? '';
export const telegramReady = () => (window as unknown as Tg).Telegram?.WebApp?.ready?.();
export async function loginWithTelegram() {
  const auth = getFirebaseAuth(); // surfaces ConfigError before any network call
  const r = await fetch('/api/auth/telegram', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ initData: telegramInitData() }) });
  if (!r.ok) throw new Error('login failed');
  return signInWithCustomToken(auth, ((await r.json()) as { token: string }).token);
}
export async function authedFetch(url: string, init: RequestInit = {}) {
  const t = await getFirebaseAuth().currentUser?.getIdToken();
  return fetch(url, { ...init, headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: `Bearer ${t}` } : {}) } });
}
