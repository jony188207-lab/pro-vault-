import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth, type DecodedIdToken } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { hasAdminClaim } from '../claims.ts';
export class ApiError extends Error { constructor(public status: number, message: string) { super(message); } }
export function adminApp() {
  const existing = getApps()[0]; if (existing) return existing;
  const { FIREBASE_ADMIN_PROJECT_ID: projectId, FIREBASE_ADMIN_CLIENT_EMAIL: clientEmail, FIREBASE_ADMIN_PRIVATE_KEY: key } = process.env;
  if (!projectId || !clientEmail || !key) throw new ApiError(500, 'server not configured');
  return initializeApp({ credential: cert({ projectId, clientEmail, privateKey: key.replace(/\\n/g, '\n') }) });
}
export const adminDb = () => getFirestore(adminApp());
export const adminAuth = () => getAuth(adminApp());
/** Verifies the bearer ID token and checks revocation. */
export async function requireUser(req: Request): Promise<DecodedIdToken> {
  const token = (req.headers.get('authorization') ?? '').replace(/^Bearer /, '');
  let t: DecodedIdToken;
  try { t = await adminAuth().verifyIdToken(token, true); } catch { throw new ApiError(401, 'unauthorized'); }
  if ((await adminDb().doc(`users/${t.uid}`).get()).get('status') === 'blocked') throw new ApiError(403, 'blocked');
  return t;
}
/** Valid login is not enough: the verified token must carry admin === true. Checked on every admin request. */
export async function requireAdmin(req: Request): Promise<DecodedIdToken> {
  const t = await requireUser(req);
  if (!hasAdminClaim(t)) throw new ApiError(403, 'forbidden');
  return t;
}
export const audit = (action: string, actorUid: string, target: string) =>
  adminDb().collection('adminAuditLogs').add({ action, actorUid, target, createdAt: new Date() });
export function failure(e: unknown): Response {
  if (e instanceof ApiError) return Response.json({ error: e.message }, { status: e.status });
  return Response.json({ error: 'server error' }, { status: 500 });
}
