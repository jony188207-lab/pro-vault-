export type Link = { kind: 'telegram' | 'web'; url: string };
/** Mini App / external links: https only; t.me Mini App links, or hosts on an explicit allowlist. javascript:, data:, http:, tg: are rejected. */
export function classifyLink(raw: string, approvedHosts: readonly string[]): Link | null {
  let u: URL; try { u = new URL(raw.trim()); } catch { return null; }
  if (u.protocol !== 'https:' || u.username || u.password) return null;
  const host = u.hostname.toLowerCase();
  if (host === 't.me') {
    const [bot, app, ...rest] = u.pathname.split('/').filter(Boolean);
    if (!bot || rest.length || !/^[A-Za-z]\w{4,31}$/.test(bot) || (app && !/^\w{1,64}$/.test(app))) return null;
    return app || u.searchParams.has('startapp') ? { kind: 'telegram', url: u.toString() } : null;
  }
  return approvedHosts.some((h) => host === h.toLowerCase() || host.endsWith(`.${h.toLowerCase()}`)) ? { kind: 'web', url: u.toString() } : null;
}
