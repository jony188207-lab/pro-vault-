import { createHash } from 'node:crypto';
const NOT_SIGNED = new Set(['file', 'cloud_name', 'resource_type', 'api_key']);
export const signParams = (p: Record<string, string | number>, secret: string) =>
  createHash('sha1').update(Object.keys(p).filter((k) => !NOT_SIGNED.has(k)).sort().map((k) => `${k}=${p[k]}`).join('&') + secret).digest('hex');
export type MediaKind = 'video' | 'image';
const LIMITS: Record<MediaKind, { max: number; mime: readonly string[] }> = {
  video: { max: 2_000_000_000, mime: ['video/mp4', 'video/quicktime', 'video/webm'] },
  image: { max: 10_000_000, mime: ['image/jpeg', 'image/png', 'image/webp'] } };
export function checkUpload(kind: MediaKind, mime: string, size: number): string | null {
  const l = LIMITS[kind];
  if (!l.mime.includes(mime)) return 'unsupported file type';
  if (!Number.isInteger(size) || size <= 0 || size > l.max) return 'file size not allowed';
  return null;
}
export function uploadTicket(kind: MediaKind, cfg: { cloudName: string; apiKey: string; apiSecret: string }, nowSec: number) {
  const p = { folder: `proapp/${kind}s`, timestamp: nowSec };
  return { ...p, signature: signParams(p, cfg.apiSecret), apiKey: cfg.apiKey, cloudName: cfg.cloudName, resourceType: kind };
}
export const isCloudinaryUrl = (u: string) => { try { const x = new URL(u); return x.protocol === 'https:' && x.hostname === 'res.cloudinary.com'; } catch { return false; } };
