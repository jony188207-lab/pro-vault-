'use client';
import { useCallback, useEffect, useState } from 'react';
import { authedFetch, ConfigError, loginWithTelegram, startAnalytics, telegramReady } from '@/lib/firebase/client';
type Video = { id: string; title: string; description: string | null; thumbnailUrl: string; category: string; viewCount: number; likeCount: number };
const TABS = ['Home', 'Saved', 'More', 'Account'] as const;
const SORTS = ['latest', 'popular', 'featured'] as const;
export default function Home() {
  const [tab, setTab] = useState<(typeof TABS)[number]>('Home'); const [sort, setSort] = useState<(typeof SORTS)[number]>('latest');
  const [items, setItems] = useState<Video[]>([]); const [state, setState] = useState<'loading' | 'ok' | 'error'>('loading'); const [note, setNote] = useState(''); const [signedIn, setSignedIn] = useState(false);
  useEffect(() => { startAnalytics().catch(() => undefined); telegramReady(); loginWithTelegram().then(() => setSignedIn(true)).catch((e: unknown) => setNote(e instanceof ConfigError ? e.message : 'Open this app inside Telegram to sign in.')); }, []);
  const load = useCallback(async () => { setState('loading'); try { const r = await fetch(`/api/videos?sort=${sort}`); if (!r.ok) throw new Error(); setItems(((await r.json()) as { items: Video[] }).items); setState('ok'); } catch { setState('error'); } }, [sort]);
  useEffect(() => { void load(); }, [load]);
  return (
    <main className="mx-auto max-w-3xl p-3 pb-24">
      {note && <p role="status" className="mb-2 text-sm text-vault-soft">{note}</p>}
      {tab === 'Home' ? (<>
        <div className="mb-3 flex gap-2">{SORTS.map((s) => <button key={s} onClick={() => setSort(s)} className={`rounded-lg bg-vault-accent px-3 py-1 text-sm ${s === sort ? '' : 'opacity-50'}`}>{s}</button>)}</div>
        {state === 'loading' && <p>Loading…</p>}
        {state === 'error' && <p>Could not load videos. <button className="underline" onClick={() => void load()}>Retry</button></p>}
        {state === 'ok' && items.length === 0 && <p>No videos published yet.</p>}
        <div className="grid grid-cols-2 gap-3">{items.map((v) => (
          <article key={v.id} className="overflow-hidden rounded-2xl border border-vault-line bg-vault-card">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={v.thumbnailUrl} alt="" loading="lazy" className="aspect-video w-full object-cover" />
            <div className="p-2"><h2 className="font-semibold">{v.title}</h2><p className="text-xs opacity-70">{v.category} · {v.viewCount} views · {v.likeCount} likes</p>
              <button disabled={!signedIn} onClick={async () => { const r = await authedFetch(`/api/videos/${v.id}/like`, { method: 'POST' }); setNote(r.ok ? 'Like updated.' : 'Like failed.'); }} className="mt-1 rounded bg-vault-accent px-2 py-1 text-xs disabled:opacity-40">Like</button></div>
          </article>))}</div></>)
        : <p>The {tab} screen has not been built yet.</p>}
      <nav className="fixed inset-x-0 bottom-0 flex border-t border-vault-line bg-vault-bg pb-[env(safe-area-inset-bottom)]">
        {TABS.map((t) => <button key={t} onClick={() => setTab(t)} className={`flex-1 py-4 ${t === tab ? 'text-vault-soft' : 'text-neutral-500'}`}>{t}</button>)}</nav>
    </main>);
}
