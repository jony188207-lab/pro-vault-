import { diagnoseFirebaseEnv } from '@/lib/firebaseConfig';
export const dynamic = 'force-dynamic';
/** Status words only (ok/missing/empty/placeholder/quoted/malformed) for PUBLIC Firebase variables: no values, no secrets. Runtime view; the browser bundle uses BUILD-time values. */
export async function GET() {
  const e = process.env;
  const status = diagnoseFirebaseEnv({
    NEXT_PUBLIC_FIREBASE_API_KEY: e.NEXT_PUBLIC_FIREBASE_API_KEY, NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: e.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN, NEXT_PUBLIC_FIREBASE_PROJECT_ID: e.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
    NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET: e.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET, NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID: e.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID, NEXT_PUBLIC_FIREBASE_APP_ID: e.NEXT_PUBLIC_FIREBASE_APP_ID });
  return Response.json({ status, allOk: Object.values(status).every((s) => s === 'ok'), deployment: { env: e.VERCEL_ENV ?? null, branch: e.VERCEL_GIT_COMMIT_REF ?? null, commit: e.VERCEL_GIT_COMMIT_SHA?.slice(0, 7) ?? null } });
}
