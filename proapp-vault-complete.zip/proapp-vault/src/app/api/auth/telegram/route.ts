import { FieldValue } from 'firebase-admin/firestore';
import { adminAuth, adminDb, failure, ApiError } from '@/lib/firebase/admin';
import { firebaseUid, verifyInitData } from '@/lib/telegram';
import { allow } from '@/lib/ratelimit';
export async function POST(req: Request) {
  try {
    if (!allow(`login:${req.headers.get('x-forwarded-for') ?? 'unknown'}`, 20, 60_000)) throw new ApiError(429, 'too many requests');
    const body: unknown = await req.json().catch(() => null);
    const initData = typeof body === 'object' && body !== null && 'initData' in body ? (body as { initData: unknown }).initData : null;
    if (typeof initData !== 'string' || initData.length > 4096 || !process.env.TELEGRAM_BOT_TOKEN) throw new ApiError(400, 'bad request');
    let user; try { user = verifyInitData(initData, process.env.TELEGRAM_BOT_TOKEN, Number(process.env.TELEGRAM_INITDATA_MAX_AGE_SECONDS ?? 3600), Math.floor(Date.now() / 1000)); } catch { throw new ApiError(401, 'unauthorized'); }
    const uid = firebaseUid(user.id); const ref = adminDb().doc(`users/${uid}`); const snap = await ref.get();
    if (snap.get('status') === 'blocked') throw new ApiError(403, 'blocked');
    await ref.set({ uid, telegramId: String(user.id), firstName: user.first_name ?? null, username: user.username ?? null, status: snap.get('status') ?? 'active', role: snap.get('role') ?? 'user',
      lastSeenAt: FieldValue.serverTimestamp(), ...(snap.exists ? {} : { firstSeenAt: FieldValue.serverTimestamp() }) }, { merge: true });
    return Response.json({ token: await adminAuth().createCustomToken(uid) }); // existing custom claims (admin) ride along on the user record
  } catch (e) { return failure(e); }
}
