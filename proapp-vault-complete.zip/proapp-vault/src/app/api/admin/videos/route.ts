import { z } from 'zod';
import { adminDb, audit, failure, requireAdmin, ApiError } from '@/lib/firebase/admin';
import { isCloudinaryUrl } from '@/lib/cloudinary';
export const dynamic = 'force-dynamic';
const url = z.string().max(2048).refine(isCloudinaryUrl, 'Cloudinary https URL required');
const Body = z.object({ title: z.string().min(1).max(120), description: z.string().max(1000).default(''), thumbnailUrl: url, playbackUrl: url, category: z.string().min(1).max(40).default('general'),
  tags: z.array(z.string().max(30)).max(10).default([]), order: z.number().int().min(0).default(0),
  unlockPolicy: z.object({ required: z.boolean(), allowLinkVisit: z.boolean() }).default({ required: true, allowLinkVisit: false }) });
export async function GET(req: Request) {
  try {
    await requireAdmin(req);
    const s = await adminDb().collection('videos').orderBy('createdAt', 'desc').limit(50).get();
    return Response.json({ items: s.docs.map((d) => ({ id: d.id, title: d.get('title'), status: d.get('status'), featured: d.get('featured') === true, viewCount: d.get('viewCount') ?? 0 })) });
  } catch (e) { return failure(e); }
}
export async function POST(req: Request) {
  try {
    const admin = await requireAdmin(req);
    const b = Body.safeParse(await req.json().catch(() => null)); if (!b.success) throw new ApiError(400, 'bad request');
    const { playbackUrl, ...pub } = b.data; const db = adminDb(); const ref = db.collection('videos').doc();
    const batch = db.batch();
    batch.set(ref, { ...pub, status: 'draft', featured: false, viewCount: 0, likeCount: 0, commentCount: 0, saveCount: 0, createdAt: new Date(), publishedAt: null });
    batch.set(db.doc(`videoPrivate/${ref.id}`), { playbackUrl }); await batch.commit();
    await audit('video.create', admin.uid, ref.id);
    return Response.json({ id: ref.id }, { status: 201 });
  } catch (e) { return failure(e); }
}
