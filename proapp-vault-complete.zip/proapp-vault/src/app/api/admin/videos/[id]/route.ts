import { z } from 'zod';
import { adminDb, audit, failure, requireAdmin, ApiError } from '@/lib/firebase/admin';
const Patch = z.object({ status: z.enum(['draft', 'published', 'unpublished']).optional(), featured: z.boolean().optional(), order: z.number().int().min(0).optional() }).strict();
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireAdmin(req); const { id } = await params;
    const b = Patch.safeParse(await req.json().catch(() => null)); if (!b.success || !Object.keys(b.data).length || !/^\w{1,100}$/.test(id)) throw new ApiError(400, 'bad request');
    const ref = adminDb().doc(`videos/${id}`); if (!(await ref.get()).exists) throw new ApiError(404, 'not found');
    await ref.update({ ...b.data, updatedAt: new Date(), ...(b.data.status === 'published' ? { publishedAt: new Date() } : {}) });
    await audit(`video.${b.data.status ?? 'update'}`, admin.uid, id);
    return Response.json({ ok: true });
  } catch (e) { return failure(e); }
}
