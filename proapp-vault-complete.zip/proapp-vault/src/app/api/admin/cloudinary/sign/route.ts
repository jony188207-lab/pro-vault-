import { z } from 'zod';
import { failure, requireAdmin, ApiError } from '@/lib/firebase/admin';
import { checkUpload, uploadTicket } from '@/lib/cloudinary';
const Body = z.object({ kind: z.enum(['video', 'image']), mime: z.string().max(100), size: z.number().int().positive() });
export async function POST(req: Request) {
  try {
    await requireAdmin(req);
    const b = Body.safeParse(await req.json().catch(() => null)); if (!b.success) throw new ApiError(400, 'bad request');
    const bad = checkUpload(b.data.kind, b.data.mime, b.data.size); if (bad) throw new ApiError(422, bad);
    const { NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME: cloudName, CLOUDINARY_API_KEY: apiKey, CLOUDINARY_API_SECRET: apiSecret } = process.env;
    if (!cloudName || !apiKey || !apiSecret) throw new ApiError(500, 'cloudinary not configured');
    return Response.json(uploadTicket(b.data.kind, { cloudName, apiKey, apiSecret }, Math.floor(Date.now() / 1000)));
  } catch (e) { return failure(e); }
}
