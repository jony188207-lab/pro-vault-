import type { Query } from 'firebase-admin/firestore';
import { adminDb, failure } from '@/lib/firebase/admin';
const FIELDS = ['title', 'description', 'thumbnailUrl', 'category', 'viewCount', 'likeCount', 'commentCount', 'saveCount', 'featured'] as const;
export async function GET(req: Request) {
  try {
    const p = new URL(req.url).searchParams; const sort = p.get('sort') ?? 'latest'; const category = p.get('category'); const after = p.get('after');
    const db = adminDb(); let q: Query = db.collection('videos').where('status', '==', 'published');
    if (sort === 'featured') q = q.where('featured', '==', true).orderBy('order');
    else if (sort === 'popular') q = q.orderBy('viewCount', 'desc');
    else { if (category) q = q.where('category', '==', category); q = q.orderBy('publishedAt', 'desc'); }
    if (after && /^\w{1,100}$/.test(after)) { const s = await db.doc(`videos/${after}`).get(); if (s.exists) q = q.startAfter(s); }
    const snap = await q.limit(20).get();
    return Response.json({ items: snap.docs.map((d) => ({ id: d.id, ...Object.fromEntries(FIELDS.map((f) => [f, d.get(f) ?? null])) })), next: snap.size === 20 ? snap.docs[19].id : null });
  } catch (e) { return failure(e); }
}
