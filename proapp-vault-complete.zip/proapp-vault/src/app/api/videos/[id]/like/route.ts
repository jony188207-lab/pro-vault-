import { FieldValue } from 'firebase-admin/firestore';
import { adminDb, failure, requireUser, ApiError } from '@/lib/firebase/admin';
import { allow } from '@/lib/ratelimit';
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req); const { id } = await params;
    if (!/^\w{1,100}$/.test(id)) throw new ApiError(400, 'bad request');
    if (!allow(`like:${user.uid}`, 30, 60_000)) throw new ApiError(429, 'too many requests');
    const db = adminDb(); const video = db.doc(`videos/${id}`); const like = db.doc(`videoLikes/${id}__${user.uid}`); // ID = one like per user per video
    const liked = await db.runTransaction(async (tx) => {
      const [v, l] = await Promise.all([tx.get(video), tx.get(like)]);
      if (!v.exists || v.get('status') !== 'published') throw new ApiError(404, 'not found');
      if (l.exists) { tx.delete(like); tx.update(video, { likeCount: FieldValue.increment(-1) }); return false; }
      tx.set(like, { uid: user.uid, videoId: id, createdAt: FieldValue.serverTimestamp() }); tx.update(video, { likeCount: FieldValue.increment(1) }); return true;
    });
    return Response.json({ liked });
  } catch (e) { return failure(e); }
}
