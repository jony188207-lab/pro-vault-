'use client';
import { useCallback, useEffect, useState } from 'react';
import { authedFetch, ConfigError, loginWithTelegram } from '@/lib/firebase/client';
type Row = { id: string; title: string; status: string; featured: boolean; viewCount: number };
export default function AdminVideos() {
  const [rows, setRows] = useState<Row[]>([]); const [msg, setMsg] = useState('Signing in…'); const [ok, setOk] = useState(false);
  const [f, setF] = useState({ title: '', thumbnailUrl: '', playbackUrl: '', category: 'general' });
  const load = useCallback(async () => { const r = await authedFetch('/api/admin/videos'); if (r.status === 403) return setMsg('Not an admin.'); if (!r.ok) return setMsg('Failed to load.'); setRows(((await r.json()) as { items: Row[] }).items); setMsg(''); setOk(true); }, []);
  useEffect(() => { loginWithTelegram().then(load).catch((e: unknown) => setMsg(e instanceof ConfigError ? e.message : 'Open inside Telegram as an admin.')); }, [load]);
  async function create() { const r = await authedFetch('/api/admin/videos', { method: 'POST', body: JSON.stringify(f) }); setMsg(r.ok ? 'Draft created.' : 'Rejected: Cloudinary https URLs only.'); if (r.ok) void load(); }
  async function patch(id: string, body: object) { const r = await authedFetch(`/api/admin/videos/${id}`, { method: 'PATCH', body: JSON.stringify(body) }); setMsg(r.ok ? 'Saved.' : 'Failed.'); void load(); }
  return (<main className="mx-auto max-w-2xl p-4"><h1 className="text-xl font-bold">Admin — Videos</h1>{msg && <p role="status">{msg}</p>}
    {ok && <><div className="my-3 space-y-2">{(['title', 'thumbnailUrl', 'playbackUrl', 'category'] as const).map((k) => <input key={k} placeholder={k} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} className="w-full rounded border border-vault-line bg-vault-card p-2" />)}
      <button onClick={() => void create()} className="rounded bg-vault-accent px-3 py-1">Create draft</button></div>
      {rows.length === 0 && <p>No videos yet.</p>}
      {rows.map((v) => <div key={v.id} className="border-t border-vault-line py-2"><b>{v.title}</b> <small>[{v.status}{v.featured ? ', featured' : ''}]</small>
        <div className="mt-1 flex gap-2"><button className="rounded bg-vault-accent px-2" onClick={() => void patch(v.id, { status: v.status === 'published' ? 'unpublished' : 'published' })}>{v.status === 'published' ? 'Unpublish' : 'Publish'}</button>
          <button className="rounded bg-vault-accent px-2" onClick={() => void patch(v.id, { featured: !v.featured })}>{v.featured ? 'Unfeature' : 'Feature'}</button></div></div>)}</>}</main>);
}
