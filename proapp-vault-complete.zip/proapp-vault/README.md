# ProApp Vault (clean-room rebuild) — STATUS: FOUNDATION
Single Next.js 15 app (App Router, strict TS, Tailwind). Admin UI lives at /admin; admin APIs under /api/admin/*.
Built: Telegram initData verification + Firebase custom-token login, token-revocation + admin-claim guards, Cloudinary signing, rate limiter,
unlock-decision logic (verified vs link_visit), safe-link classifier, feed API + Home screen, like API, admin video create/publish/feature API + screen,
Firestore rules/indexes/schema, admin bootstrap script.
NOT built: Saved/More/Account screens, player, comments, save/unlock/play routes, Adsterra, Mini App directory, menu builder, products/posts/galleries/pages,
users/moderation/ads/media/audit screens, Visual Builder, settings. Not run: install, typecheck, lint, build, emulator.
## Setup
    cp .env.example .env.local   # fill in secrets
    npm install && npm run typecheck && npm run lint && npm test && npm run build
## Firebase
    npm i -g firebase-tools && firebase login && firebase deploy --only firestore:rules,firestore:indexes
Console: enable Authentication (no providers needed; custom tokens), create Firestore, create a service account key (store only in Vercel env vars).
Admin: `GOOGLE_APPLICATION_CREDENTIALS=/secure/key.json node scripts/set-admin.mjs <telegramId>` (needs `npm i firebase-admin`, already a dependency).
## Vercel
Root Directory `.` (repo root), framework Next.js, default build. Add all variables from .env.example. Rate limiting is per-instance only.
## Telegram
@BotFather: /newbot → token into TELEGRAM_BOT_TOKEN; /newapp or menu button → your Vercel HTTPS URL. Admins open /admin inside Telegram.
## Cloudinary
Copy cloud name, API key and secret into env vars. Uploads need a signature from POST /api/admin/cloudinary/sign (admin only).

## Vercel environment variables (Project Settings > Environment Variables)
Public web config (all REQUIRED at BUILD time; scope: Production, and Preview if you use it; values without quotes or spaces):
`NEXT_PUBLIC_FIREBASE_API_KEY`, `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`, `NEXT_PUBLIC_FIREBASE_PROJECT_ID`, `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`,
`NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`, `NEXT_PUBLIC_FIREBASE_APP_ID`; optional `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID`, `NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME`.
Server secrets (never `NEXT_PUBLIC_`): `FIREBASE_ADMIN_PROJECT_ID`, `FIREBASE_ADMIN_CLIENT_EMAIL`, `FIREBASE_ADMIN_PRIVATE_KEY`, `TELEGRAM_BOT_TOKEN`,
`TELEGRAM_INITDATA_MAX_AGE_SECONDS`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`, `APPROVED_HTTPS_HOSTS`.
Troubleshooting `auth/invalid-api-key`: NEXT_PUBLIC_* values are inlined during the build, so after adding or changing one you must REDEPLOY (without build cache).
The client SDK initializes lazily in the browser only; if the config is missing the pages show a ConfigError message naming the variables.
