// GOOGLE_APPLICATION_CREDENTIALS=/path/outside/repo/key.json node scripts/set-admin.mjs <telegramNumericId>
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
const id = process.argv[2];
if (!/^\d{1,15}$/.test(id ?? '')) { console.error('usage: set-admin.mjs <telegramNumericId>'); process.exit(1); }
initializeApp({ credential: applicationDefault(), projectId: 'proappvault-ffe3f' });
const uid = `tg_${id}`;
try { await getAuth().getUser(uid); } catch { await getAuth().createUser({ uid }); }
await getAuth().setCustomUserClaims(uid, { admin: true });
await getFirestore().doc(`users/${uid}`).set({ uid, telegramId: id, role: 'admin', status: 'active' }, { merge: true });
await getFirestore().collection('adminAuditLogs').add({ action: 'admin.bootstrap', actorUid: 'script', target: uid, createdAt: new Date() });
console.log(`admin claim set for ${uid}; re-open the app to refresh the token`);
