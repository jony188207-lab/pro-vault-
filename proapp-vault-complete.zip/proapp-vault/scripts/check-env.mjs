// Runs automatically before `npm run build` (package.json "prebuild"). Prints status words only, never values.
// 1) Proves the code being built has no eager browser-Firebase initialization (the cause of auth/invalid-api-key during prerender).
// 2) Checks the public Firebase variables. On Vercel (VERCEL=1) problems FAIL the build with a clear message; locally they only warn.
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
const NAMES = ['NEXT_PUBLIC_FIREBASE_API_KEY', 'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN', 'NEXT_PUBLIC_FIREBASE_PROJECT_ID', 'NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET', 'NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID', 'NEXT_PUBLIC_FIREBASE_APP_ID'];
const PLACEHOLDER = /^(your[_-]|<|changeme|todo|xxx|replace)/i;
const status = (n) => { const raw = process.env[n]; if (raw === undefined) return 'MISSING'; const v = raw.trim(); if (!v) return 'EMPTY'; if (/^["']|["']$/.test(v)) return 'QUOTED'; if (PLACEHOLDER.test(v)) return 'PLACEHOLDER';
  return n.endsWith('API_KEY') && !/^AIza[\w-]{35}$/.test(v) ? 'MALFORMED' : 'OK'; };
const e = process.env;
console.log(`[env-check] vercelEnv=${e.VERCEL_ENV ?? 'n/a'} branch=${e.VERCEL_GIT_COMMIT_REF ?? 'n/a'} commit=${(e.VERCEL_GIT_COMMIT_SHA ?? 'n/a').slice(0, 7)}`);
// Top-level (non-function) Firebase client initialization, e.g. `export const auth = getAuth(app)`.
const EAGER = /^(export\s+)?(const|let|var)\s+\w+(\s*:\s*[\w<>]+)?\s*=\s*(?!.*=>)(getApps\(\)\.length\s*\?\s*getApp\(\)\s*:\s*)?(initializeApp|getAuth|getFirestore|getAnalytics)\(/;
const hits = [];
function walk(dir) { let list; try { list = readdirSync(dir); } catch { return; }
  for (const f of list) { if (f === 'node_modules' || f === '.next' || f.startsWith('.')) continue; const p = join(dir, f); const st = statSync(p);
    if (st.isDirectory()) walk(p);
    else if (/\.(ts|tsx)$/.test(f) && !/(^|[\\/])tests?[\\/]/.test(relative(process.cwd(), p))) readFileSync(p, 'utf8').split('\n').forEach((l, i) => { if (EAGER.test(l)) hits.push(`${relative(process.cwd(), p)}:${i + 1}`); }); } }
for (const d of ['src', 'app', 'apps', 'packages']) walk(join(process.cwd(), d));
console.log(hits.length ? `[env-check] FAIL eager Firebase initialization found at: ${hits.join(', ')}` : '[env-check] OK no top-level Firebase client initialization found');
let bad = 0;
for (const n of NAMES) { const s = status(n); if (s !== 'OK') bad++; console.log(`[env-check] ${n}: ${s}`); }
const strict = Boolean(e.VERCEL) || e.ENV_CHECK_STRICT === '1';
if (hits.length || (bad && strict)) { console.error(bad ? '[env-check] Fix the variables above in Vercel (Production scope), then redeploy without build cache.' : '[env-check] Remove eager initialization; use getFirebaseApp()/getFirebaseAuth().'); process.exit(1); }
if (bad) console.warn('[env-check] WARNING: variables above are not OK (not failing: not running on Vercel).');
