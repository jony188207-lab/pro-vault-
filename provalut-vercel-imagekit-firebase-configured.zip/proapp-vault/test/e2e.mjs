// End-to-end browser test (Playwright + Chromium) against the local rig: real frontend, real api/index.js (Vercel entry),
// mocked Google services. Run:  node test/e2e.mjs   (needs playwright; see README "Testing")
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { startRig } from './e2e-server.js';

const require = createRequire(import.meta.url);
let chromium;
try {
  ({ chromium } = require('playwright'));
} catch {
  ({ chromium } = require('/opt/npm-tools/node_modules/playwright'));
}

const SHOTS = process.env.SHOTS_DIR;
if (SHOTS) fs.mkdirSync(SHOTS, { recursive: true });

const rig = await startRig();
const { mock, siteOrigin } = rig;
const adminAuth = mock.newAuthUser('boss@site.test', 'adminpass1');
adminAuth.verified = true;

const MP4 = Buffer.from([0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d, 0, 0, 2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

const browser = await chromium.launch();
const problems = [];
let step = 0;
const log = (m) => console.log(`  ${String(++step).padStart(2, '0')} ${m}`);

async function newSession(name, viewport = { width: 390, height: 844 }) {
  const ctx = await browser.newContext({ viewport });
  await ctx.route('https://ads.example.com/**', (r) =>
    r.request().url().endsWith('.js') ? r.fulfill({ contentType: 'text/javascript', body: '/* fake ad script */' }) : r.fulfill({ contentType: 'text/html', body: '<html><body>Sponsor page</body></html>' }),
  );
  await ctx.route('https://fonts.googleapis.com/**', (r) => r.fulfill({ contentType: 'text/css', body: '' }));
  await ctx.route('https://fonts.gstatic.com/**', (r) => r.abort());
  const page = await ctx.newPage();
  page.on('console', (m) => {
    // 4xx/5xx resource errors are reported with their URL by the response listener below (some are expected)
    if (/Failed to load resource/.test(m.text())) return;
    if (m.type() === 'error' || /Content Security Policy|violates/i.test(m.text())) problems.push(`[${name}] console ${m.type()}: ${m.text()} @ ${m.location().url}`);
  });
  page.on('response', (r) => {
    if (r.status() < 400) return;
    const u = r.url();
    const expected = /\/api\/admin\/settings$/.test(u) && r.request().method() === 'PUT'; // deliberate invalid banner / policy tests
    const firstRun = /documents\/settings\/public$/.test(u); // no settings document until an admin saves once: the app falls back to defaults
    const expected2 = firstRun || /\/api\/parts\/[^/]+\/access$/.test(u) || /accounts:(signInWithPassword|signUp)/.test(u) || (/\/api\/admin\/videos$/.test(u) && r.request().method() === 'POST');
    if (!expected && !expected2 && !/accounts:update/.test(u)) problems.push(`[${name}] HTTP ${r.status()} ${r.request().method()} ${u}`);
  });
  page.on('pageerror', (e) => problems.push(`[${name}] pageerror: ${e.message} ${e.stack?.split('\n')[1] || ''}`));
  page.on('requestfailed', (r) => {
    if (!/fonts\.gstatic|ads\.example\.com|favicon|banner-frame/.test(r.url())) problems.push(`[${name}] request failed: ${r.url()} ${r.failure()?.errorText}`);
  });
  return { ctx, page };
}

const shot = async (page, name) => SHOTS && (await page.waitForTimeout(600), await page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: false }));
const go = async (page, hash) => {
  await page.goto(`${siteOrigin}/${hash}`);
  await page.waitForSelector('main#main > *', { timeout: 10000 });
};
const until = async (fn, what = 'condition') => { for (let i = 0; i < 80; i++) { if (await fn()) return; await new Promise((r) => setTimeout(r, 100)); } throw new Error(`timed out waiting for ${what}`); };
const toastText = (page, re) => page.locator('.toast').filter({ hasText: re }).first().waitFor({ timeout: 8000 });

async function login(page, email, password) {
  await go(page, '#/login');
  await page.fill('#email', email);
  await page.fill('#password', password);
  await page.click('button[type=submit]');
  await page.waitForSelector('.avatar', { timeout: 8000 });
}

try {
  // ============================================================== visitor
  console.log('Visitor');
  const visitor = await newSession('visitor');
  let p = visitor.page;
  await go(p, '');
  await p.getByText('Recently Added').first().waitFor();
  assert.equal(await p.title(), 'Provalut');
  assert.equal(await p.locator('.wordmark').first().innerText().then((t) => t.replace(/\s/g, '')), 'PROVALUT');
  assert.equal(await p.locator('body').innerText().then((t) => /proapp/i.test(t)), false);
  log('home renders as Provalut, no old name');
  await p.goto(`${siteOrigin}/#/saved`);
  await p.waitForSelector('#email');
  await p.goto(`${siteOrigin}/#/admin`);
  await p.waitForSelector('#email');
  log('protected and admin routes redirect visitors to login');

  // ============================================================== admin
  console.log('Admin');
  const adm = await newSession('admin');
  p = adm.page;
  await login(p, 'boss@site.test', 'adminpass1');
  log('bootstrap admin logs in');

  await go(p, '#/admin/ads');
  const bannerCode = '<script>atOptions = {"key":"abc","format":"iframe","height":60,"width":468,"params":{}};</script><script src="https://ads.example.com/abc/invoke.js"></script>';
  for (const key of ['home', 'homeBottom', 'listCard', 'detailsBelow', 'partsBottom']) {
    await p.fill(`#b-${key}-html`, bannerCode);
    await p.fill(`#b-${key}-w`, '468');
    await p.fill(`#b-${key}-h`, '60');
    if (key === 'detailsBelow') continue; // left DISABLED: must render nothing for visitors
    await p.check(`#b-${key}-on`);
    await p.locator('section.placement').filter({ has: p.locator(`#b-${key}-on`) }).getByRole('button', { name: 'Save placement' }).click();
    await until(() => mock.read('settings/public')?.banners?.[key]?.enabled === true, `banner ${key}`);
  }
  await p.locator('section.placement').filter({ has: p.locator('#b-detailsBelow-on') }).getByRole('button', { name: 'Save placement' }).click();
  await until(() => mock.read('settings/public')?.banners?.detailsBelow?.html, 'detailsBelow');
  const s1 = mock.read('settings/public');
  assert.equal(s1.banners.home.enabled, true);
  assert.equal(s1.banners.detailsBelow.enabled, false);
  assert.equal(s1.banners.detailsBelow.html.includes('invoke.js'), true);
  log('five banner placements saved independently (one left disabled)');

  await p.fill('#b-listCard-html', '<script>alert(document.cookie)</script>');
  await p.locator('section.placement').filter({ has: p.locator('#b-listCard-on') }).getByRole('button', { name: 'Save placement' }).click();
  await toastText(p, /Inline scripts are limited/);
  log('malicious banner code is rejected');

  await p.fill('#g-away', '2');
  await p.check('#g-ack');
  await p.getByRole('button', { name: 'Save unlock settings' }).click();
  await until(() => mock.read('settings/public')?.gate?.minAwaySeconds === 2, 'gate');
  log('unlock settings saved after policy acknowledgement');
  await shot(p, 'admin-ads');

  await go(p, '#/admin/settings');
  await p.fill('#s-cats', 'Movies\nSeries');
  await p.getByRole('button', { name: 'Save settings' }).click();
  await until(() => mock.read('settings/public')?.categories?.length === 2, 'categories');
  assert.deepEqual(mock.read('settings/public').categories, ['Movies', 'Series']);
  log('categories saved');

  // create video (draft) then add parts
  await go(p, '#/admin/videos/new');
  await p.fill('#f-title', 'Mountain Sunrise Saga');
  await p.fill('#f-desc', 'A calm sunrise.');
  await p.fill('#f-cat', 'Movies');
  await p.fill('#f-tags', 'nature, sunrise');
  await p.setInputFiles('#f-thumb', { name: 'thumb.png', mimeType: 'image/png', buffer: PNG });
  await p.click('button:has-text("Create video")');
  await toastText(p, /Video created/);
  await p.waitForURL(/#\/admin\/videos\/[^/]+$/);
  await p.getByRole('heading', { name: 'Parts' }).waitFor();
  const vid = mock.ids('videos')[0];
  assert.equal(mock.read(`videos/${vid}`).status, 'draft');
  log('video created as a draft with a cover; parts editor appears');

  const addPart = async ({ title, quality, file, ext, unlock, locked = true, download }) => {
    await p.getByRole('button', { name: 'Add part' }).click();
    const form = p.locator('form.part-card');
    await form.getByLabel('Title (optional)').fill(title);
    await form.getByLabel('Quality').fill(quality);
    if (file) await form.getByLabel('Video file').setInputFiles({ name: 'part.mp4', mimeType: 'video/mp4', buffer: MP4 });
    else {
      await form.getByLabel('Source').selectOption('url');
      await form.getByLabel('Video URL').fill(ext);
    }
    if (download) await form.getByLabel('Download URL').fill(download);
    if (!locked) await form.getByLabel(/Locked:/).uncheck();
    if (unlock) await form.getByLabel('Unlock link (Smartlink)').fill(unlock);
    await form.getByLabel('Visibility').selectOption('published');
    await form.getByRole('button', { name: 'Add part' }).click();
    await toastText(p, /Part saved/);
    await p.locator('form.part-card').waitFor({ state: 'detached' });
  };
  await addPart({ title: 'Opening', quality: 'HD', file: true, unlock: 'https://ads.example.com/offer-1?sid={sid}' });
  await addPart({ title: 'Middle', quality: '720p', ext: 'https://ads.example.com/video2.mp4', unlock: 'https://ads.example.com/offer-2?sid={sid}', download: 'https://ads.example.com/dl2.zip' });
  await addPart({ title: 'Finale', quality: '4K', ext: 'https://ads.example.com/video3.mp4', locked: false });
  const parts = Object.values(mock.collection('parts')).filter((x) => x.videoId === vid).sort((a, b) => a.number - b.number);
  assert.deepEqual(parts.map((x) => x.number), [1, 2, 3]);
  assert.equal(parts[0].unlockUrl.includes('offer-1'), true);
  assert.equal(parts[1].unlockUrl.includes('offer-2'), true);
  assert.equal(mock.read(`videos/${vid}`).partsCount, 3);
  assert.equal(JSON.stringify(mock.read(`videos/${vid}`)).includes('offer-1'), false, 'unlock links never reach the public video doc');
  log('three parts added: upload + two external URLs, separate unlock links, one free part');

  // reorder: move Finale up then back
  await p.getByRole('button', { name: 'Move up' }).nth(2).click();
  await p.locator('.part-card-head strong').nth(1).filter({ hasText: 'Finale' }).waitFor();
  await p.getByRole('button', { name: 'Move up' }).nth(1).click();
  await p.locator('.part-card-head strong').nth(0).filter({ hasText: 'Finale' }).waitFor();
  await p.getByRole('button', { name: 'Move down' }).nth(0).click();
  await p.getByRole('button', { name: 'Move down' }).nth(1).click();
  await p.locator('.part-card-head strong').nth(0).filter({ hasText: 'Opening' }).waitFor();
  log('parts reordered and renumbered');
  await shot(p, 'admin-parts');

  await p.fill('#f-status', 'published').catch(() => {});
  await p.selectOption('#f-status', 'published');
  await p.click('button:has-text("Save details")');
  await until(() => mock.read(`videos/${vid}`).status === 'published', 'publish');
  await until(() => mock.read(`videos/${vid}`).notifiedAt, 'notifiedAt');
  assert.ok(mock.read(`notifications/pub_${vid}`), 'in-app notification created');
  log('video published; in-app notification created');

  // ============================================================== member
  console.log('Member');
  const mem = await newSession('alice');
  p = mem.page;
  await go(p, '#/signup');
  await p.fill('#name', 'Alice');
  await p.fill('#email', 'alice@site.test');
  await p.fill('#password', 'secret123');
  await p.click('button[type=submit]');
  await p.waitForSelector('.avatar');
  const aliceUid = mock.users.get('alice@site.test').uid;
  log('member signs up');

  await go(p, '');
  await p.locator('.vcard').first().waitFor();
  await p.waitForFunction(() => document.querySelectorAll('.banner-home iframe, .banner-homeBottom iframe').length === 2, null, { timeout: 8000 });
  assert.ok(await p.locator('.banner-listCard').count() >= 0);
  assert.equal(await p.locator('.banner-detailsBelow').count(), 0, 'disabled placement renders nothing');
  await shot(p, 'home');
  log('home shows trending, recently added, and the enabled banners only');

  await p.locator('.vcard').first().click();
  await p.locator('.dtitle').filter({ hasText: 'Mountain Sunrise Saga' }).waitFor();
  assert.equal(await p.locator('.banner-detailsBelow').count(), 0);
  await p.locator('.part-row').nth(2).waitFor();
  assert.equal(/\bnull\b|undefined/.test(await p.locator('main').innerText()), false, 'no stray null/undefined text');
  await shot(p, 'details');
  log('details page lists all three parts; disabled details banner absent');

  await p.getByRole('button', { name: /Download/ }).first().click();
  await p.locator('.parts-modal .part-row').nth(2).waitFor();
  await shot(p, 'parts-modal');
  await p.keyboard.press('Escape');

  // unlock part 1 only
  await p.locator('.part-row').nth(0).click();
  await p.getByRole('button', { name: /স্পনসর লিংক খুলুন/ }).click();
  await p.getByText('Unlocking is based on you returning').waitFor();
  await shot(p, 'unlock');
  const verify = p.getByRole('button', { name: /আনলক করুন/ });
  await p.waitForFunction(() => [...document.querySelectorAll('.unlock button')].some((b) => /আনলক করুন/.test(b.textContent) && !b.disabled), null, { timeout: 8000 });
  await verify.click();
  await toastText(p, /আনলক হয়েছে/);
  const unlocks = Object.keys(mock.collection('unlocks'));
  assert.equal(unlocks.length, 1);
  assert.ok(unlocks[0].startsWith(aliceUid) && unlocks[0].endsWith(parts[0].id));
  assert.equal(await p.locator('.part-row.locked').count(), 2 - 1, 'part 2 stays locked; free part 3 is open');
  log('part 1 unlocked on its own; part 2 still locked; banners never unlocked anything');

  // repeated click does not duplicate
  await p.reload();
  await p.locator('.part-row').nth(2).waitFor();
  await p.waitForFunction(() => document.querySelectorAll('.part-row.locked').length === 1);
  assert.equal(Object.keys(mock.collection('unlocks')).length, 1);
  log('unlock persists across reload; no duplicates');

  // watch part 1 (ImageKit signed URL)
  await p.locator('.part-row').nth(0).click();
  await p.getByRole('button', { name: 'Watch' }).click();
  const src = await p.locator('video.video-el').getAttribute('src');
  assert.match(src, /\/provalut\/videos\/.*[?&]ik-s=[0-9a-f]{40}/, 'signed ImageKit URL');
  const range = await p.evaluate(async (u) => { const r = await fetch(u, { headers: { Range: 'bytes=0-9' } }); return r.status; }, src);
  assert.equal(range, 206);
  await p.keyboard.press('Escape');
  log('watch gives a signed ImageKit URL that streams with range requests');

  // locked part 2 opens its own unlock dialog and cannot be accessed
  const denied = await p.evaluate(async (pid) => {
    const { api } = await import('/js/lib/api.js');
    try { await api.post(`/api/parts/${pid}/access`, { mode: 'watch' }); return 'allowed'; } catch (e) { return e.code || e.message; }
  }, parts[1].id);
  assert.notEqual(denied, 'allowed');
  log('locked part refuses access server-side');

  // comments via sticky bar
  await p.locator('.cinput').fill('Great part one!');
  await p.locator('.cbar .send').click();
  await p.locator('.comment-text').filter({ hasText: 'Great part one!' }).waitFor();
  assert.equal(mock.ids('comments').length, 1);
  await shot(p, 'comments');
  log('comment posted through the sticky bar');

  // inbox + history + saved
  await go(p, '#/inbox');
  await p.getByText('Mountain Sunrise Saga').first().waitFor();
  log('inbox shows the publish notification');
  await go(p, '#/history');
  await p.getByText('Mountain Sunrise Saga').first().waitFor();
  log('recently watched lists the video');
  await go(p, `#/v/${vid}`);
  await p.locator('.savelater').click();
  await go(p, '#/saved');
  await p.getByText('Mountain Sunrise Saga').first().waitFor();
  log('save for later and Saved list work');

  await p.locator('button.tab').last().click();
  await p.getByText('alice@site.test').first().waitFor({ timeout: 4000 }).catch(() => {});
  await shot(p, 'menu');
  await p.keyboard.press('Escape');

  // ============================================================== anonymous access
  const anon = await visitor.page.evaluate(async (pid) => (await fetch(`/api/parts/${pid}/access`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"mode":"watch"}' })).status, parts[2].id);
  assert.equal(anon, 401, 'even a free part needs a signed-in user');
  log('anonymous access to a part is refused');

  // admin deletes a part
  p = adm.page;
  await go(p, `#/admin/videos/${vid}`);
  await p.getByRole('heading', { name: 'Parts' }).waitFor();
  await p.locator('.part-card .btn.danger').last().click();
  await p.getByRole('button', { name: 'Delete part' }).click();
  await toastText(p, /Part deleted/);
  assert.equal(mock.read(`videos/${vid}`).partsCount, 2);
  log('admin deletes a part; remaining parts renumbered');
} finally {
  await browser.close();
  await rig.stop();
}

if (problems.length) {
  console.error('\nBrowser problems:\n' + [...new Set(problems)].join('\n'));
  process.exit(1);
}
console.log('\nAll end-to-end steps passed.');
