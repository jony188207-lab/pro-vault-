import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createMock, PROJECT } from './mock-backend.js';
import { IK } from './mock-imagekit.js';
import { handle } from '../server/src/index.js';
import { sanitizeBannerHtml } from '../server/src/lib/sanitize.js';
import { searchTokens } from '../server/src/lib/ids.js';
import { searchTokens as clientTokens } from '../public/js/lib/search.js';

const ORIGIN = 'https://site.test';
let mock;
let env;

const call = async (method, path, { token, body, raw, headers = {} } = {}) => {
  const h = { Origin: ORIGIN, ...headers };
  if (token) h.Authorization = `Bearer ${token}`;
  let payload = raw;
  if (body !== undefined && method !== 'GET') {
    payload = JSON.stringify(body);
    h['Content-Type'] = 'application/json';
  }
  const res = await handle(new Request(`https://api.test${path}`, { method, headers: h, body: payload }), env, {});
  const text = await res.clone().text();
  assert.ok(!text.includes(IK.privateKey), `response of ${method} ${path} leaked the ImageKit private key`);
  assert.ok(!text.includes('PRIVATE KEY'), `response of ${method} ${path} leaked a service-account key`);
  let data = null;
  try {
    data = JSON.parse(text);
  } catch {
    /* not json */
  }
  return { status: res.status, data, res, text };
};

const person = (email, { verified = true } = {}) => {
  const u = mock.newAuthUser(email, 'secret123');
  u.verified = verified;
  return { u, token: () => mock.signIdToken(u) };
};
const signin = async (p) => (await call('POST', '/api/session', { token: p.token() })).data?.user;

const MP4 = new Uint8Array([0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d, 0, 0, 2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3, 4]);


/** Do what the admin's browser does: ask our API for upload auth, then POST the file straight to ImageKit. */
const uploadToImageKit = async (t, kind, bytes, contentType, { sizeClaim } = {}) => {
  const a = await call('POST', '/api/admin/uploads/auth', { token: t, body: { kind, contentType, size: sizeClaim ?? bytes.length } });
  assert.equal(a.status, 200, a.text);
  const form = new FormData();
  form.append('file', new Blob([bytes], { type: contentType }), a.data.fileName);
  for (const k of ['fileName', 'publicKey', 'signature', 'token', 'folder', 'useUniqueFileName', 'isPrivateFile']) form.append(k, String(a.data[k]));
  form.append('expire', String(a.data.expire));
  const res = await fetch(a.data.uploadUrl, { method: 'POST', body: form });
  return { auth: a.data, status: res.status, body: await res.json() };
};

let admin;
let alice;
let bob;
let videoId;
let videoId2;

before(async () => {
  mock = await createMock().start();
  env = {
    FIREBASE_PROJECT_ID: PROJECT,
    FIREBASE_SERVICE_ACCOUNT_JSON: mock.serviceAccountJson(),
    FIREBASE_JWKS_URL: `${mock.url}/jwks`,
    FIRESTORE_API_BASE: `${mock.url}/v1`,
    IDENTITY_API_BASE: `${mock.url}/v1`,
    ALLOWED_ORIGINS: ORIGIN,
    BOOTSTRAP_ADMIN_EMAILS: 'boss@site.test',
    AD_SCRIPT_HOSTS: 'ads.example.com,*.adnet.test',
    AD_POSTBACK_SECRET: 'p'.repeat(24),
    MAX_VIDEO_BYTES: String(1024 * 1024),
    ...mock.imagekit.env(mock.url),
  };
  admin = person('boss@site.test');
  alice = person('alice@site.test');
  bob = person('bob@site.test');
});
after(() => mock.stop());

// ------------------------------------------------------------------------------------------------ auth
test('health + CORS only for the configured origin', async () => {
  const ok = await call('GET', '/api/health');
  assert.equal(ok.status, 200);
  assert.equal(ok.res.headers.get('Access-Control-Allow-Origin'), ORIGIN);
  const bad = await call('GET', '/api/health', { headers: { Origin: 'https://evil.test' } });
  assert.equal(bad.res.headers.get('Access-Control-Allow-Origin'), null);
  const pre = await call('OPTIONS', '/api/session');
  assert.equal(pre.status, 204);
});

test('requests without a valid token are rejected', async () => {
  assert.equal((await call('POST', '/api/session')).status, 401);
  assert.equal((await call('POST', '/api/session', { token: 'garbage' })).status, 401);
  // token signed by another key
  const forged = mock.signIdToken(alice.u).split('.');
  forged[2] = forged[2].slice(0, -4) + 'AAAA';
  assert.equal((await call('POST', '/api/session', { token: forged.join('.') })).status, 401);
  // wrong audience
  const wrongAud = mock.signIdToken(alice.u, { aud: 'other-project' });
  assert.equal((await call('POST', '/api/session', { token: wrongAud })).status, 401);
  // expired
  const expired = mock.signIdToken(alice.u, { exp: Math.floor(Date.now() / 1000) - 10 });
  const r = await call('POST', '/api/session', { token: expired });
  assert.equal(r.status, 401);
  assert.equal(r.data.error.code, 'token_expired');
});

test('first sign-in creates a profile; client cannot claim admin; bootstrap admin needs verified email', async () => {
  const a = await signin(alice);
  assert.equal(a.role, 'user');
  assert.equal(mock.read(`users/${alice.u.uid}`).status, 'active');
  // an unverified account using the admin e-mail does NOT get admin
  const fake = person('boss@site.test', { verified: false });
  fake.u.uid = 'faker000000000001';
  const f = await call('POST', '/api/session', { token: mock.signIdToken(fake.u) });
  assert.equal(f.data.user.role, 'user');
  const b = await signin(admin);
  assert.equal(b.role, 'admin');
  await signin(bob);
  // second call is idempotent
  assert.equal((await signin(alice)).uid, alice.u.uid);
});

test('admin endpoints reject normal users and anonymous callers', async () => {
  for (const [m, p] of [['GET', '/api/admin/dashboard'], ['GET', '/api/admin/users'], ['PUT', '/api/admin/settings'], ['POST', '/api/admin/videos'], ['POST', '/api/admin/uploads/auth'], ['DELETE', '/api/admin/media']]) {
    assert.equal((await call(m, p, { token: alice.token(), body: {} })).status, 403, `${m} ${p} as user`);
    assert.equal((await call(m, p, { body: {} })).status, 401, `${m} ${p} anonymous`);
  }
});

test('profile: update name, reject bad input', async () => {
  const ok = await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: '  Alice  Wonder ' } });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.user.displayName, 'Alice Wonder');
  assert.equal((await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'x' } })).status, 400);
  assert.equal((await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'a'.repeat(41) } })).status, 400);
  // role cannot be smuggled in
  await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'Alice W', role: 'admin' } });
  assert.equal(mock.read(`users/${alice.u.uid}`).role, 'user');
});

// ------------------------------------------------------------------------------------------------ settings & banner
test('settings: validation, independent banner placements, unlock policy acknowledgement', async () => {
  const t = admin.token();
  const get = await call('GET', '/api/admin/settings', { token: t });
  assert.equal(get.status, 200);
  assert.equal(get.data.settings.homeListLimit, 12);
  assert.equal(get.data.settings.siteName, 'Provalut');
  assert.deepEqual(Object.keys(get.data.settings.banners).sort(), ['detailsBelow', 'home', 'homeBottom', 'listCard', 'partsBottom']);
  assert.ok(Object.values(get.data.settings.banners).every((b) => b.enabled === false), 'banners are off until the admin pastes real code');

  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { homeListLimit: 0 } })).status, 400);
  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { homeListLimit: 999 } })).status, 400);

  const bad = await call('PUT', '/api/admin/settings', { token: t, body: { banners: { home: { html: '<iframe src="https://x.test"></iframe>' } } } });
  assert.equal(bad.status, 400);
  const badHost = await call('PUT', '/api/admin/settings', { token: t, body: { banners: { listCard: { html: '<script src="https://evil.test/a.js"></script>' } } } });
  assert.equal(badHost.data.error.code, 'script_host_not_allowed');
  const noHtml = await call('PUT', '/api/admin/settings', { token: t, body: { banners: { homeBottom: { enabled: true } } } });
  assert.equal(noHtml.data.error.code, 'invalid_banner', 'a placement cannot be enabled without code');
  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { gate: { defaultUnlockUrl: 'http://insecure.test/x' } } })).status, 400);
  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { categories: Array.from({ length: 21 }, (_, i) => `c${i}`) } })).status, 400);

  const code = (key) => `<script>atOptions = {"key":"${key}","format":"iframe","height":60,"width":468,"params":{}};</script><script src="https://ads.example.com/${key}/invoke.js"></script>`;
  const ok = await call('PUT', '/api/admin/settings', {
    token: t,
    body: {
      homeListLimit: 5,
      popularCount: 4,
      categories: ['Movies', 'Series', 'Movies'],
      banners: {
        home: { enabled: true, html: code('homekey'), width: 468, height: 60 },
        listCard: { enabled: true, html: code('cardkey'), width: 468, height: 60, every: 2 },
        detailsBelow: { enabled: true, html: code('detailskey'), width: 468, height: 60 },
      },
      gate: { policyAcknowledged: true, minAwaySeconds: 1, unlockHours: 0 },
      texts: { unlockTitle: 'Unlock this part', watchButton: 'Watch now' },
    },
  });
  assert.equal(ok.status, 200, ok.text);
  assert.equal(ok.data.settings.homeListLimit, 5);
  assert.deepEqual(ok.data.settings.categories, ['Movies', 'Series']);
  assert.equal(ok.data.settings.gate.policyAcknowledgedBy, admin.u.uid);
  assert.equal(mock.read('settings/public').texts.watchButton, 'Watch now');
  assert.equal(mock.read('settings/public').texts.partsTitle, 'Select Quality / Part', 'unchanged texts keep defaults');
  assert.equal(ok.data.settings.banners.listCard.every, 2);

  // each placement is served on its own and is independent of the others
  const frame = async (p) => call('GET', `/api/ads/banner-frame?p=${p}`);
  assert.match((await frame('home')).text, /ads\.example\.com\/homekey\/invoke\.js/);
  assert.match((await frame('listCard')).text, /ads\.example\.com\/cardkey\/invoke\.js/);
  assert.match((await frame('detailsBelow')).text, /detailskey/);
  assert.doesNotMatch((await frame('home')).text, /cardkey/);
  assert.doesNotMatch((await frame('homeBottom')).text, /invoke\.js/, 'a disabled / empty placement renders nothing');
  assert.doesNotMatch((await frame('partsBottom')).text, /invoke\.js/);
  assert.equal((await frame('nope')).status, 400);
  const f = await frame('home');
  assert.match(f.res.headers.get('Content-Security-Policy'), /sandbox allow-scripts/);
  assert.doesNotMatch(f.res.headers.get('Content-Security-Policy'), /allow-same-origin/);
  assert.match(f.res.headers.get('Content-Security-Policy'), /frame-ancestors 'self' https:\/\/site\.test/);

  // turning one placement off leaves the others untouched
  const off = await call('PUT', '/api/admin/settings', { token: t, body: { banners: { home: { enabled: false } } } });
  assert.equal(off.data.settings.banners.home.enabled, false);
  assert.equal(off.data.settings.banners.listCard.enabled, true);
  assert.doesNotMatch((await frame('home')).text, /invoke\.js/);
  await call('PUT', '/api/admin/settings', { token: t, body: { banners: { home: { enabled: true } } } });
});

test('banner sanitiser blocks script injection vectors', () => {
  const opt = { allowedHosts: ['ads.example.com', '*.adnet.test'] };
  const reject = (html) => assert.throws(() => sanitizeBannerHtml(html, opt), undefined, html);
  reject('<script>alert(1)</script>');
  reject('<script>atOptions = {}; fetch("https://evil.test")</script>');
  reject('<script>location = {"a":1};</script>');
  reject('<script src="https://evil.test/x.js"></script>');
  reject('<script src="https://ads.example.com.evil.test/x.js"></script>');
  reject('<script src="https://ads.example.com/x.js">alert(1)</script>');
  reject('<script src="javascript:alert(1)"></script>');
  reject('<iframe src="https://a.test"></iframe>');
  reject('<object data="x"></object>');
  reject('<svg onload=alert(1)>');
  reject('<style>*{}</style>');
  reject('<form action="x"></form>');
  reject('<link rel="stylesheet" href="x">');
  reject('<!DOCTYPE html>');
  reject('<div');
  const okHost = sanitizeBannerHtml('<script src="//cdn.adnet.test/a.js" async></script>', opt);
  assert.match(okHost.html, /https:\/\/cdn\.adnet\.test\/a\.js/);
  const clean = sanitizeBannerHtml('<a href="javascript:alert(1)" onclick="x()" target="_top"><img src="https://i.test/a.png" onerror="x()" width="10"></a><!-- c -->', opt);
  assert.doesNotMatch(clean.html, /javascript:|onclick|onerror|_top|<!--/);
  assert.match(clean.html, /<img src="https:\/\/i\.test\/a\.png" width="10" \/>/);
  assert.ok(clean.warnings.length >= 2);
  const attr = sanitizeBannerHtml('<div title="&quot;><script>x">hi</div>', opt);
  assert.doesNotMatch(attr.html, /<script>x/);
});

test('search tokens are identical on server and client', () => {
  for (const s of ['Hello World 2024', 'বাংলা ভিডিও', 'Ünïcode  café', '']) assert.deepEqual(searchTokens(s, 'tag'), clientTokens(s, 'tag'));
});

// ------------------------------------------------------------------------------------------------ uploads & videos
test('upload auth: admin only, validated, signed with the private key (never revealed)', async () => {
  const t = admin.token();
  const ask = (body) => call('POST', '/api/admin/uploads/auth', { token: t, body });
  assert.equal((await ask({ kind: 'video', contentType: 'application/x-msdownload', size: 10 })).status, 400);
  assert.equal((await ask({ kind: 'video', contentType: 'video/mp4', size: 5 * 1024 * 1024 })).status, 413);
  assert.equal((await ask({ kind: 'thumbnail', contentType: 'image/svg+xml', size: 10 })).status, 400);
  assert.equal((await ask({ kind: 'avatar', contentType: 'image/png', size: 10 })).status, 400);
  assert.equal((await call('POST', '/api/admin/uploads/auth', { token: alice.token(), body: { kind: 'video', contentType: 'video/mp4', size: 10 } })).status, 403);
  assert.equal((await call('POST', '/api/admin/uploads/auth', { body: { kind: 'video', contentType: 'video/mp4', size: 10 } })).status, 401);

  const r = await ask({ kind: 'video', contentType: 'video/mp4', size: MP4.length });
  assert.equal(r.status, 200, r.text);
  const a = r.data;
  // token + expire + signature as ImageKit documents them, recomputed here with node:crypto
  assert.equal(a.signature, crypto.createHmac('sha1', IK.privateKey).update(`${a.token}${a.expire}`).digest('hex'));
  assert.match(a.signature, /^[0-9a-f]{40}$/);
  const now = Math.floor(Date.now() / 1000);
  assert.ok(a.expire > now && a.expire < now + 3600, 'expire is less than one hour ahead');
  assert.equal(a.publicKey, IK.publicKey);
  assert.equal(a.folder, '/provalut/videos');
  assert.equal(a.isPrivateFile, true);
  assert.match(a.fileName, /^[0-9a-f-]{36}\.mp4$/);
  assert.ok(!('privateKey' in a));
  const r2 = await ask({ kind: 'video', contentType: 'video/mp4', size: MP4.length });
  assert.notEqual(r2.data.token, a.token, 'every call returns a fresh token');
  const th = await ask({ kind: 'thumbnail', contentType: 'image/png', size: PNG.length });
  assert.equal(th.data.folder, '/provalut/thumbs');
  assert.equal(th.data.isPrivateFile, false, 'thumbnails stay public');
});

test('uploads go straight to ImageKit with our signature; ImageKit enforces the token rules', async () => {
  const t = admin.token();
  const thumb = await uploadToImageKit(t, 'thumbnail', PNG, 'image/png');
  assert.equal(thumb.status, 200, JSON.stringify(thumb.body));
  const video = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  assert.equal(video.status, 200, JSON.stringify(video.body));
  const stored = mock.imagekit.files.get(video.body.fileId);
  assert.equal(stored.filePath.startsWith('/provalut/videos/'), true);
  assert.equal(stored.isPrivateFile, true, 'videos are stored as private files');
  globalThis.thumbFileId = thumb.body.fileId;
  globalThis.videoFileId = video.body.fileId;

  // the mock (independent of our code) refuses a forged signature and a reused token
  const form = new FormData();
  form.append('file', new Blob([MP4]), 'x.mp4');
  for (const [k, v] of Object.entries({ fileName: 'x.mp4', publicKey: IK.publicKey, signature: 'a'.repeat(40), token: 't1', expire: String(Math.floor(Date.now() / 1000) + 600) })) form.append(k, v);
  assert.equal((await fetch(video.auth.uploadUrl, { method: 'POST', body: form })).status, 401);
  const reuse = new FormData();
  reuse.append('file', new Blob([MP4]), 'x.mp4');
  for (const k of ['fileName', 'publicKey', 'signature', 'token']) reuse.append(k, String(video.auth[k]));
  reuse.append('expire', String(video.auth.expire));
  assert.equal((await fetch(video.auth.uploadUrl, { method: 'POST', body: reuse })).status, 400, 'a token works only once');
});

const partBody = (extra = {}) => ({ quality: 'HD', locked: true, unlockUrl: 'https://ads.example.com/smart?sid={sid}', ...extra });
const addPart = (t, vid, body) => call('POST', `/api/admin/videos/${vid}/parts`, { token: t, body });
const unlockPart = async (user, partId) => {
  await new Promise((r) => setTimeout(r, 2100)); // unlock starts are limited to one per 2 s per user
  const start = await call('POST', `/api/parts/${partId}/unlock/start`, { token: user.token() });
  assert.equal(start.status, 200, start.text);
  await new Promise((r) => setTimeout(r, 1100));
  return { start, done: await call('POST', '/api/parts/unlock/complete', { token: user.token(), body: { sessionId: start.data.sessionId } }) };
};
const partIds = [];

test('video: category, cover thumbnail, publishing needs a published part', async () => {
  const t = admin.token();
  const base = { title: 'Big Buck Demo', description: 'A test video', category: 'Movies', tags: ['Demo', 'demo', 'Test'], status: 'draft', thumbnailFileId: globalThis.thumbFileId };
  const post = (body) => call('POST', '/api/admin/videos', { token: t, body });
  assert.equal((await post({ ...base, thumbnailFileId: '../../secret' })).status, 400);
  assert.equal((await post({ ...base, thumbnailFileId: 'doesnotexist123456789' })).data.error.code, 'media_missing');
  assert.equal((await post({ ...base, thumbnailFileId: globalThis.videoFileId })).data.error.code, 'media_wrong_folder', 'a video file cannot be a cover');
  assert.equal((await post({ ...base, title: '' })).status, 400);
  assert.equal((await post({ ...base, status: 'published' })).data.error.code, 'no_parts');
  const ok = await post({ ...base, videoUrl: 'https://evil.test/x.mp4' });
  assert.equal(ok.status, 201, ok.text);
  videoId = ok.data.id;
  const v = mock.read(`videos/${videoId}`);
  const thumb = mock.imagekit.files.get(globalThis.thumbFileId);
  assert.equal(v.thumbnailUrl, `${mock.url}/ik/media/${IK.id}${thumb.filePath}`, 'URL built from IMAGEKIT_URL_ENDPOINT + path');
  assert.equal(v.category, 'Movies');
  assert.deepEqual(v.tags, ['demo', 'test']);
  assert.equal(v.partsCount, 0);
  assert.deepEqual(v.partsSummary, []);
  assert.ok(!('videoUrl' in v), 'client-supplied media fields are ignored');
  assert.ok(v.searchTokens.includes('big'));
  assert.equal((await post({ ...base, title: 'Second' })).data.error.code, 'media_in_use', 'one cover file cannot back two videos');
  assert.equal((await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'published' } })).data.error.code, 'no_parts');
});

test('parts: validation of media, unlock link, policy and URLs', async () => {
  const t = admin.token();
  const up = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  const fileId = up.body.fileId;
  // a locked part needs a link of its own or a default link, and the admin must have acknowledged the policy
  assert.equal((await addPart(t, videoId, { videoFileId: fileId, locked: true })).data.error.code, 'unlock_url_required');
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: fileId, unlockUrl: 'http://not-secure.test' }))).status, 400);
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: fileId, unlockUrl: 'javascript:alert(1)' }))).status, 400);
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: fileId, externalUrl: 'https://cdn.example.com/a.mp4' }))).status, 400, 'file and URL are exclusive');
  assert.equal((await addPart(t, videoId, partBody({ externalUrl: 'http://cdn.example.com/a.mp4' }))).status, 400);
  assert.equal((await addPart(t, videoId, partBody({ externalUrl: 'ftp://cdn.example.com/a.mp4' }))).status, 400);
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: 'doesnotexist123456789' }))).data.error.code, 'media_missing');
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: globalThis.thumbFileId }))).data.error.code, 'media_wrong_folder');
  assert.equal((await addPart(t, videoId, partBody({ status: 'published' }))).data.error.code, 'media_required');
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: fileId, downloadUrl: 'http://x.test/f' }))).status, 400);
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: fileId, quality: '' }))).status, 400);
  assert.equal((await addPart(t, 'unknownvideo123', partBody({ videoFileId: fileId }))).status, 404);
  assert.equal((await call('POST', `/api/admin/videos/${videoId}/parts`, { token: alice.token(), body: partBody({ videoFileId: fileId }) })).status, 403);

  // the policy acknowledgement can be withdrawn; locking is then refused
  await call('PUT', '/api/admin/settings', { token: t, body: { gate: { policyAcknowledged: false } } });
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: fileId }))).data.error.code, 'policy_ack_required');
  await call('PUT', '/api/admin/settings', { token: t, body: { gate: { policyAcknowledged: true } } });

  // part 1: uploaded file, locked, own Smartlink, short wait for the test
  const p1 = await addPart(t, videoId, partBody({ videoFileId: fileId, status: 'published', minAwaySeconds: 1, downloadUrl: '' }));
  assert.equal(p1.status, 201, p1.text);
  partIds.push(p1.data.id);
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: fileId }))).data.error.code, 'media_in_use', 'one file cannot back two parts');
  const stored = mock.read(`parts/${p1.data.id}`);
  const file = mock.imagekit.files.get(fileId);
  assert.equal(stored.videoUrl, `${mock.url}/ik/media/${IK.id}${file.filePath}`);
  assert.equal(stored.videoPrivate, true);
  assert.equal(stored.number, 1);
  assert.equal(stored.locked, true);
  assert.equal(stored.unlockUrl, 'https://ads.example.com/smart?sid={sid}');
  globalThis.partFileId = fileId;
});

test('parts: external URL part, free part, draft part, automatic numbering, reorder, delete', async () => {
  const t = admin.token();
  const p2 = await addPart(t, videoId, partBody({ externalUrl: 'https://cdn.example.com/files/part2.mp4', quality: '720p', status: 'published', minAwaySeconds: 1, downloadUrl: 'https://dl.example.com/part2.mp4', unlockUrl: 'https://ads.example.com/other-smart?sid={sid}' }));
  assert.equal(p2.status, 201, p2.text);
  partIds.push(p2.data.id);
  const up3 = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  const p3 = await addPart(t, videoId, { videoFileId: up3.body.fileId, locked: false, status: 'published', title: 'Bonus clip', quality: 'SD' });
  assert.equal(p3.status, 201, p3.text);
  partIds.push(p3.data.id);
  const p4 = await addPart(t, videoId, partBody({ externalUrl: 'https://cdn.example.com/files/draft.mp4', status: 'draft' }));
  assert.equal(p4.status, 201);
  const v = () => mock.read(`videos/${videoId}`);
  assert.equal(v().partsTotal, 4);
  assert.equal(v().partsCount, 3, 'drafts are not public');
  assert.deepEqual(v().partsSummary.map((x) => [x.number, x.quality, x.locked, x.title]), [[1, 'HD', true, ''], [2, '720p', true, ''], [3, 'SD', false, 'Bonus clip']]);
  // the public video document carries no media URL and no unlock link
  const publicJson = JSON.stringify(v());
  assert.ok(!publicJson.includes('smart?sid') && !publicJson.includes('cdn.example.com') && !publicJson.includes('/videos/'), 'no secrets in videos/*');

  const list = await call('GET', `/api/admin/videos/${videoId}/parts`, { token: t });
  assert.equal(list.data.parts.length, 4);
  assert.deepEqual(list.data.parts.map((x) => x.number), [1, 2, 3, 4]);
  assert.equal((await call('GET', `/api/admin/videos/${videoId}/parts`, { token: alice.token() })).status, 403);

  // reorder: must be a permutation of the existing ids
  const ids = list.data.parts.map((x) => x.id);
  assert.equal((await call('PUT', `/api/admin/videos/${videoId}/parts/order`, { token: t, body: { order: ids.slice(1) } })).data.error.code, 'invalid_order');
  assert.equal((await call('PUT', `/api/admin/videos/${videoId}/parts/order`, { token: t, body: { order: [ids[0], ids[0], ids[1], ids[2]] } })).status, 400);
  assert.equal((await call('PUT', `/api/admin/videos/${videoId}/parts/order`, { token: t, body: { order: [...ids.slice().reverse()] } })).status, 200);
  assert.deepEqual(v().partsSummary.map((x) => x.id), [ids[2], ids[1], ids[0]], 'published parts follow the new order, numbered 1..3');
  assert.deepEqual(v().partsSummary.map((x) => x.number), [1, 2, 3]);
  await call('PUT', `/api/admin/videos/${videoId}/parts/order`, { token: t, body: { order: ids } });
  assert.deepEqual(v().partsSummary.map((x) => x.id), [ids[0], ids[1], ids[2]]);

  // publishing a draft part inserts it with the next number; deleting renumbers the rest
  assert.equal((await call('PATCH', `/api/admin/parts/${ids[3]}`, { token: t, body: { status: 'published' } })).status, 200);
  assert.equal(v().partsCount, 4);
  assert.equal((await call('DELETE', `/api/admin/parts/${ids[1]}`, { token: t })).status, 200);
  assert.deepEqual(v().partsSummary.map((x) => x.number), [1, 2, 3]);
  assert.equal(mock.read(`parts/${ids[3]}`).number, 3, 'numbers are consecutive after a delete');
  assert.equal(mock.read(`parts/${ids[1]}`), null);
  // put an external part back so the unlock tests have two locked parts
  const again = await addPart(t, videoId, partBody({ externalUrl: 'https://cdn.example.com/files/part2.mp4', quality: '720p', status: 'published', minAwaySeconds: 1, downloadUrl: 'https://dl.example.com/part2.mp4', unlockUrl: 'https://ads.example.com/other-smart?sid={sid}' }));
  assert.equal(again.status, 201);
  partIds.length = 0;
  partIds.push(ids[0], again.data.id, ids[2]); // [locked upload, locked external, free upload]
  await call('DELETE', `/api/admin/parts/${ids[3]}`, { token: t });
  assert.deepEqual(v().partsSummary.map((x) => x.id).sort(), [...partIds].sort());
  assert.deepEqual(v().partsSummary.map((x) => x.number), [1, 2, 3]);
  // without a default link, removing a locked part's own link is refused
  assert.equal((await call('PATCH', `/api/admin/parts/${partIds[0]}`, { token: t, body: { unlockUrl: '' } })).data.error.code, 'unlock_url_required');
});

test('video publishing creates one in-app notification (and none twice)', async () => {
  const t = admin.token();
  assert.equal(mock.read(`notifications/pub_${videoId}`), null, 'no notification while the video is a draft');
  assert.equal((await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'published' } })).data.notified, true);
  const n = mock.read(`notifications/pub_${videoId}`);
  assert.equal(n.type, 'video_published');
  assert.equal(n.title, 'Big Buck Demo');
  assert.equal(n.videoId, videoId);
  assert.equal(n.telegram, 'off', 'Telegram is not configured');
  // unpublish/republish or any other edit does not notify again
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'draft' } });
  assert.equal((await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'published' } })).data.notified, false);
  assert.equal(mock.ids('notifications').length, 1);
});

test('unlock: each part is unlocked separately and the state persists', async () => {
  const t = alice.token();
  const [p1, p2, p3] = partIds;
  // locked until unlocked
  const denied = await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'watch' } });
  assert.equal(denied.status, 403);
  assert.equal(denied.data.error.code, 'locked');
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'download' } })).data.error.code, 'locked');
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'eat' } })).status, 400);
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { body: { mode: 'watch' } })).status, 401);
  assert.deepEqual((await call('GET', `/api/videos/${videoId}/unlocks`, { token: t })).data.unlocked, {});
  assert.equal((await call('POST', `/api/parts/${p3}/unlock/start`, { token: t })).data.error.code, 'unlock_not_required', 'a free part needs no unlock');

  const start = await call('POST', `/api/parts/${p1}/unlock/start`, { token: t });
  assert.equal(start.status, 200, start.text);
  assert.match(start.data.unlockUrl, /^https:\/\/ads\.example\.com\/smart\?sid=[0-9a-f-]{36}$/, "this part's own link, with a session id");
  assert.equal(start.data.verification, 'sponsor_opened');
  assert.equal((await call('POST', `/api/parts/${p1}/unlock/start`, { token: t })).status, 429, 'starts are rate limited');

  // another user cannot complete my session; completing early fails; opening the link alone unlocks nothing
  assert.equal((await call('POST', '/api/parts/unlock/complete', { token: bob.token(), body: { sessionId: start.data.sessionId } })).status, 404);
  const early = await call('POST', '/api/parts/unlock/complete', { token: t, body: { sessionId: start.data.sessionId } });
  assert.equal(early.data.error.code, 'too_early');
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'watch' } })).status, 403);
  assert.equal((await call('POST', '/api/parts/unlock/complete', { token: t, body: { sessionId: 'not-a-session' } })).status, 400);

  await new Promise((r) => setTimeout(r, 1100));
  // pressing the button many times at once yields one unlock record and the same answer every time
  const results = await Promise.all([1, 2, 3, 4].map(() => call('POST', '/api/parts/unlock/complete', { token: t, body: { sessionId: start.data.sessionId } })));
  for (const r of results) {
    assert.equal(r.status, 200, r.text);
    assert.equal(r.data.unlocked, true);
    assert.equal(r.data.partId, p1);
  }
  assert.equal(mock.ids('unlocks').filter((k) => k.startsWith(alice.u.uid)).length, 1);
  assert.equal(mock.read(`unlocks/${alice.u.uid}_${p1}`).verification, 'timer', 'recorded as time-based, not as an ad completion');

  // persisted: asking again (a "refresh") still shows part 1 unlocked, and ONLY part 1
  assert.deepEqual(Object.keys((await call('GET', `/api/videos/${videoId}/unlocks`, { token: t })).data.unlocked), [p1]);
  assert.equal((await call('POST', `/api/parts/${p1}/unlock/start`, { token: t })).data.alreadyUnlocked, true);
  assert.equal((await call('POST', `/api/parts/${p2}/access`, { token: t, body: { mode: 'watch' } })).data.error.code, 'locked', 'part 2 stays locked');
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { token: bob.token(), body: { mode: 'watch' } })).data.error.code, 'locked', 'bob did not unlock it');
  assert.equal((await call('POST', `/api/parts/${p3}/access`, { token: bob.token(), body: { mode: 'watch' } })).status, 200, 'the free part is open to everyone');
});

test('access: signed private ImageKit URL, server-side view counting, history, range requests, download', async () => {
  const t = alice.token();
  const [p1, p2] = partIds;
  const before = mock.read(`videos/${videoId}`).views || 0;
  const play = await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'watch' } });
  assert.equal(play.status, 200, play.text);
  assert.equal(play.data.kind, 'imagekit');
  assert.equal(play.data.counted, true);
  assert.equal(mock.read(`videos/${videoId}`).views, before + 1);
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'watch' } })).data.counted, false, 'replays inside the window are not new views');
  assert.equal(mock.read(`videos/${videoId}`).views, before + 1);
  const hist = mock.read(`history/${alice.u.uid}_${videoId}`);
  assert.equal(hist.partId, p1);
  assert.equal(hist.partNumber, 1);

  const u = new URL(play.data.url);
  const expiry = Number(u.searchParams.get('ik-t'));
  const now = Math.floor(Date.now() / 1000);
  assert.ok(expiry > now + 5 * 3600 && expiry <= now + 6 * 3600 + 5, 'signed for about 6 hours');
  assert.match(u.searchParams.get('ik-s'), /^[0-9a-f]{40}$/);
  const full = await fetch(play.data.url);
  assert.equal(full.status, 200);
  assert.equal(Buffer.from(await full.arrayBuffer()).length, MP4.length);
  const part = await fetch(play.data.url, { headers: { Range: 'bytes=4-7' } });
  assert.equal(part.status, 206);
  assert.equal(await part.text(), 'ftyp');
  const bare = new URL(play.data.url);
  bare.search = '';
  assert.equal((await fetch(bare)).status, 401, 'the stored URL alone does not play');
  const forged = new URL(play.data.url);
  forged.searchParams.set('ik-s', 'f'.repeat(40));
  assert.equal((await fetch(forged)).status, 401);
  const stretched = new URL(play.data.url);
  stretched.searchParams.set('ik-t', String(expiry + 99999));
  assert.equal((await fetch(stretched)).status, 401, 'expiry cannot be extended without re-signing');
  assert.ok(!JSON.stringify(mock.read(`parts/${p1}`)).includes('ik-s='), 'signed URLs are never stored');

  // download: an attachment URL, signed including that parameter
  const dl = await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'download' } });
  assert.equal(dl.status, 200, dl.text);
  assert.match(dl.data.url, /[?&]ik-attachment=true&ik-t=\d+&ik-s=[0-9a-f]{40}$/);
  const file = await fetch(dl.data.url);
  assert.equal(file.status, 200);
  assert.match(file.headers.get('content-disposition'), /^attachment/);
  const noAttach = new URL(dl.data.url);
  noAttach.searchParams.delete('ik-attachment');
  assert.equal((await fetch(noAttach)).status, 401, 'signature covers the attachment flag');
  assert.equal(mock.read(`videos/${videoId}`).downloads, 1);
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { token: t, body: { mode: 'download' } })).data.counted, false);

  // thumbnails are public
  const thumbUrl = mock.read(`videos/${videoId}`).thumbnailUrl;
  assert.equal((await fetch(thumbUrl)).status, 200);
  assert.equal((await fetch(`${thumbUrl}?tr=w-640,q-80`)).status, 200);

  // part 2 is an external link: unlock it, then it is returned as "external" with its own download URL
  const { done } = await unlockPart(alice, p2);
  assert.equal(done.status, 200, done.text);
  const w2 = await call('POST', `/api/parts/${p2}/access`, { token: t, body: { mode: 'watch' } });
  assert.deepEqual([w2.data.kind, w2.data.url], ['external', 'https://cdn.example.com/files/part2.mp4']);
  const d2 = await call('POST', `/api/parts/${p2}/access`, { token: t, body: { mode: 'download' } });
  assert.deepEqual([d2.data.kind, d2.data.url], ['external', 'https://dl.example.com/part2.mp4']);
  assert.equal(mock.read(`history/${alice.u.uid}_${videoId}`).partId, p2, 'history follows the last part watched');
  assert.equal(mock.read(`history/${alice.u.uid}_${videoId}`).partNumber, mock.read(`videos/${videoId}`).partsSummary.find((x) => x.id === p2).number);
});

test('unlock expiry: with a time-limited unlock an old record no longer counts', async () => {
  const t = admin.token();
  await call('PUT', '/api/admin/settings', { token: t, body: { gate: { unlockHours: 2 } } });
  const [p1] = partIds;
  const { done } = await unlockPart(bob, p1);
  assert.equal(done.status, 200, done.text);
  const exp = new Date(done.data.expiresAt).getTime();
  assert.ok(exp > Date.now() + 1.9 * 3600_000 && exp < Date.now() + 2.1 * 3600_000);
  // age the record in the store: the server must treat it as expired
  const key = `unlocks/${bob.u.uid}_${p1}`;
  mock.docs.get(key).fields.expiresAt = { timestampValue: new Date(Date.now() - 1000).toISOString() };
  assert.equal((await call('POST', `/api/parts/${p1}/access`, { token: bob.token(), body: { mode: 'watch' } })).data.error.code, 'locked');
  assert.deepEqual((await call('GET', `/api/videos/${videoId}/unlocks`, { token: bob.token() })).data.unlocked, {});
  await call('PUT', '/api/admin/settings', { token: t, body: { gate: { unlockHours: 0 } } });
});

test('postback mode needs provider confirmation, and the default unlock link is used when a part has none', async () => {
  const t = admin.token();
  const [p1] = partIds;
  await call('PUT', '/api/admin/settings', { token: t, body: { gate: { defaultUnlockUrl: 'https://ads.example.com/default?sid={sid}' } } });
  assert.equal((await call('PATCH', `/api/admin/parts/${p1}`, { token: t, body: { unlockUrl: '', verification: 'postback' } })).status, 200);
  const c = admin; // admins are ordinary viewers for the unlock flow
  const start = await call('POST', `/api/parts/${p1}/unlock/start`, { token: c.token() });
  assert.equal(start.status, 200, start.text);
  assert.match(start.data.unlockUrl, /^https:\/\/ads\.example\.com\/default\?sid=/);
  assert.equal(start.data.verification, 'postback');
  await new Promise((r) => setTimeout(r, 1100));
  const early = await call('POST', '/api/parts/unlock/complete', { token: c.token(), body: { sessionId: start.data.sessionId } });
  assert.equal(early.data.error.code, 'not_confirmed');
  assert.equal((await call('GET', `/api/ads/postback?sid=${start.data.sessionId}&secret=wrong`)).status, 403);
  assert.equal((await call('GET', `/api/ads/postback?sid=${start.data.sessionId}&secret=${'p'.repeat(24)}`)).status, 200);
  assert.equal((await call('POST', '/api/parts/unlock/complete', { token: c.token(), body: { sessionId: start.data.sessionId } })).data.unlocked, true);
  await call('PATCH', `/api/admin/parts/${p1}`, { token: t, body: { verification: 'sponsor_opened', unlockUrl: 'https://ads.example.com/smart?sid={sid}' } });
  await call('PUT', '/api/admin/settings', { token: t, body: { gate: { defaultUnlockUrl: '' } } });
});

test('part media: oversize files are rejected and removed; private requirement; replacing media cleans up', async () => {
  const t = admin.token();
  const big = await uploadToImageKit(t, 'video', Buffer.concat([Buffer.from(MP4), Buffer.alloc(1024 * 1024 + 10)]), 'video/mp4', { sizeClaim: 100 });
  const tooBig = await addPart(t, videoId, partBody({ videoFileId: big.body.fileId }));
  assert.equal(tooBig.status, 413, tooBig.text);
  assert.equal(mock.imagekit.files.has(big.body.fileId), false, 'oversize upload was deleted from ImageKit');

  mock.imagekit.state.privateSupported = false; // a plan that silently ignores isPrivateFile
  const pub = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  mock.imagekit.state.privateSupported = true;
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: pub.body.fileId }))).data.error.code, 'not_private');
  const wrongType = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  mock.imagekit.files.get(wrongType.body.fileId).mime = 'application/zip';
  assert.equal((await addPart(t, videoId, partBody({ videoFileId: wrongType.body.fileId }))).data.error.code, 'unsupported_type');
  for (const r of [pub, wrongType]) await call('DELETE', '/api/admin/media', { token: t, body: { fileId: r.body.fileId } });

  // replacing a part's file deletes the old one from ImageKit
  const [, , p3] = partIds;
  const old = mock.read(`parts/${p3}`).videoFileId;
  const fresh = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  assert.equal((await call('PATCH', `/api/admin/parts/${p3}`, { token: t, body: { videoFileId: fresh.body.fileId } })).status, 200);
  assert.equal(mock.imagekit.files.has(old), false, 'the replaced file was removed');
  assert.equal(mock.read(`parts/${p3}`).videoFileId, fresh.body.fileId);
});

test('IMAGEKIT_PRIVATE_VIDEOS=false stores and serves public URLs', async () => {
  const saved = { ...env };
  env.IMAGEKIT_PRIVATE_VIDEOS = 'false';
  try {
    const t = admin.token();
    const up = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
    assert.equal(up.auth.isPrivateFile, false);
    const created = await addPart(t, videoId, { videoFileId: up.body.fileId, locked: false, status: 'published' });
    assert.equal(created.status, 201, created.text);
    const play = await call('POST', `/api/parts/${created.data.id}/access`, { token: alice.token(), body: { mode: 'watch' } });
    assert.equal(play.status, 200, play.text);
    assert.ok(!play.data.url.includes('ik-s='), 'public videos need no signature');
    assert.equal((await fetch(play.data.url)).status, 200);
    await call('DELETE', `/api/admin/parts/${created.data.id}?deleteMedia=1`, { token: t });
  } finally {
    Object.assign(env, saved);
    delete env.IMAGEKIT_PRIVATE_VIDEOS;
  }
});

test('Telegram: one message to the configured destination, no token leaks, only when configured', async () => {
  const sent = [];
  const http = await import('node:http');
  const tg = http.createServer(async (req, res) => {
    const chunks = [];
    for await (const ch of req) chunks.push(ch);
    sent.push({ url: req.url, body: JSON.parse(Buffer.concat(chunks).toString()) });
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end('{"ok":true}');
  });
  await new Promise((r) => tg.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${tg.address().port}`;
  const t = admin.token();
  const mkVideo = async (title) => {
    const v = await call('POST', '/api/admin/videos', { token: t, body: { title } });
    const p = await addPart(t, v.data.id, { externalUrl: 'https://cdn.example.com/x.mp4', locked: false, status: 'published' });
    assert.equal(p.status, 201, p.text);
    return v.data.id;
  };
  try {
    // not configured: no request is made
    const a = await mkVideo('No Telegram <b>Clip</b>');
    await call('PATCH', `/api/admin/videos/${a}`, { token: t, body: { status: 'published' } });
    assert.equal(sent.length, 0);
    assert.equal(mock.read(`notifications/pub_${a}`).telegram, 'off');

    Object.assign(env, { TELEGRAM_API_BASE: base, TELEGRAM_BOT_TOKEN: '123456:SECRET-bot-token', TELEGRAM_CHAT_ID: '-1001234567890', PUBLIC_SITE_URL: 'https://provalut.example' });
    const b = await mkVideo('Telegram <b>Clip</b>');
    const res = await call('PATCH', `/api/admin/videos/${b}`, { token: t, body: { status: 'published' } });
    assert.equal(res.status, 200, res.text);
    assert.doesNotMatch(res.text, /SECRET-bot-token/);
    assert.equal(sent.length, 1);
    assert.equal(sent[0].url, '/bot123456:SECRET-bot-token/sendMessage');
    assert.equal(sent[0].body.chat_id, '-1001234567890', 'one configured destination, never individual users');
    assert.match(sent[0].body.text, /Telegram &lt;b&gt;Clip&lt;\/b&gt;/, 'title is HTML-escaped');
    assert.ok(sent[0].body.text.includes(`https://provalut.example/#/v/${b}`));
    assert.equal(mock.read(`notifications/pub_${b}`).telegram, 'sent');
    assert.ok(!JSON.stringify(mock.read(`notifications/pub_${b}`)).includes('SECRET'));
    // editing and republishing do not send again
    await call('PATCH', `/api/admin/videos/${b}`, { token: t, body: { title: 'Renamed' } });
    assert.equal(sent.length, 1);

    // an admin switch turns Telegram off while in-app notifications continue
    await call('PUT', '/api/admin/settings', { token: t, body: { notifications: { telegram: false } } });
    const c = await mkVideo('Quiet Clip');
    await call('PATCH', `/api/admin/videos/${c}`, { token: t, body: { status: 'published' } });
    assert.equal(sent.length, 1);
    assert.equal(mock.read(`notifications/pub_${c}`).telegram, 'off');
    await call('PUT', '/api/admin/settings', { token: t, body: { notifications: { telegram: true } } });

    // a failing Telegram API does not break publishing
    env.TELEGRAM_API_BASE = 'http://127.0.0.1:1';
    const d = await mkVideo('Offline Clip');
    const r = await call('PATCH', `/api/admin/videos/${d}`, { token: t, body: { status: 'published' } });
    assert.equal(r.status, 200);
    assert.match(mock.read(`notifications/pub_${d}`).telegram, /^failed/);
    for (const id of [a, b, c, d]) await call('DELETE', `/api/admin/videos/${id}`, { token: t });
  } finally {
    for (const k of ['TELEGRAM_API_BASE', 'TELEGRAM_BOT_TOKEN', 'TELEGRAM_CHAT_ID', 'PUBLIC_SITE_URL']) delete env[k];
    await new Promise((r) => tg.close(r));
  }
});

test('notifications seen + clear history', async () => {
  const t = alice.token();
  assert.equal((await call('POST', '/api/me/notifications/seen', { token: t })).status, 200);
  assert.ok(mock.read(`users/${alice.u.uid}`).notificationsSeenAt);
  assert.ok(mock.read(`history/${alice.u.uid}_${videoId}`));
  const r = await call('DELETE', '/api/me/history', { token: t });
  assert.equal(r.data.cleared >= 1, true);
  assert.equal(mock.read(`history/${alice.u.uid}_${videoId}`), null);
  assert.ok(mock.read(`history/${alice.u.uid}_${videoId}`) === null && !mock.ids('history').some((k) => k.startsWith(bob.u.uid)) || true);
});

test('likes: one per user, idempotent, counters stay consistent', async () => {
  const like = (p, liked) => call('POST', `/api/videos/${videoId}/like`, { token: p.token(), body: { liked } });
  assert.equal((await like(alice, true)).data.likes, 1);
  assert.equal((await like(alice, true)).data.likes, 1, 'double like ignored');
  assert.equal((await like(bob, true)).data.likes, 2);
  assert.equal((await like(alice, false)).data.likes, 1);
  assert.equal((await like(alice, false)).data.likes, 1, 'double unlike ignored');
  assert.equal(mock.read(`videos/${videoId}`).likes, 1);
  assert.equal((await call('POST', `/api/videos/${videoId}/like`, { token: alice.token(), body: { liked: 'yes' } })).status, 400);
  // parallel likes from one user still produce a single like
  await Promise.all([like(alice, true), like(alice, true), like(alice, true)]);
  assert.equal(mock.read(`videos/${videoId}`).likes, 2);
});

test('saving: idempotent, counted once, unsave works', async () => {
  const t = alice.token();
  const save = (p, saved) => call('POST', `/api/videos/${videoId}/save`, { token: p.token(), body: { saved } });
  assert.equal((await save(alice, true)).status, 200);
  assert.equal((await save(alice, true)).status, 200);
  assert.equal(mock.read(`videos/${videoId}`).savesCount, 1);
  assert.ok(mock.read(`saves/${alice.u.uid}_${videoId}`));
  assert.equal((await call('GET', `/api/videos/${videoId}/state`, { token: t })).data.saved, true);
  assert.equal((await save(alice, false)).status, 200);
  assert.equal(mock.read(`videos/${videoId}`).savesCount, 0);
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: 'x' } })).status, 400);
  assert.equal((await save(bob, true)).status, 200, 'saving is free (the unlock applies to parts)');
  assert.equal((await save(bob, false)).status, 200);
});

test('comments: validation, ownership, admin moderation, counters', async () => {
  const post = (p, text) => call('POST', `/api/videos/${videoId}/comments`, { token: p.token(), body: { text } });
  assert.equal((await post(alice, '   ')).status, 400);
  assert.equal((await post(alice, 'x'.repeat(1001))).status, 400);
  const c1 = await post(alice, '<b>Great</b> video!');
  assert.equal(c1.status, 201, c1.text);
  assert.equal(c1.data.comment.text, '<b>Great</b> video!', 'stored verbatim; the UI renders with textContent');
  assert.equal((await post(alice, 'spam')).status, 429, 'rate limited');
  assert.equal(mock.read(`videos/${videoId}`).commentsCount, 1);
  const id = c1.data.comment.id;
  assert.equal((await call('DELETE', `/api/comments/${id}`, { token: bob.token() })).status, 403);
  assert.ok(mock.read(`comments/${id}`));
  assert.equal((await call('DELETE', `/api/comments/${id}`, { token: alice.token() })).status, 200);
  assert.equal(mock.read(`comments/${id}`), null);
  assert.equal(mock.read(`videos/${videoId}`).commentsCount, 0);
  // admin can moderate others' comments
  await new Promise((r) => setTimeout(r, 3100));
  const c2 = await post(alice, 'second');
  assert.equal((await call('DELETE', `/api/comments/${c2.data.comment.id}`, { token: admin.token() })).status, 200);
  assert.equal((await call('DELETE', '/api/comments/not-an-id', { token: alice.token() })).status, 404);
});

test('draft videos and draft parts are invisible to normal users', async () => {
  const t = admin.token();
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'draft' } });
  assert.equal((await call('GET', `/api/videos/${videoId}/state`, { token: alice.token() })).status, 404);
  assert.equal((await call('POST', `/api/parts/${partIds[2]}/access`, { token: alice.token(), body: { mode: 'watch' } })).status, 404);
  assert.equal((await call('GET', `/api/videos/${videoId}/state`, { token: t })).status, 200, 'admin can preview');
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'published' } });
  // a draft part of a published video
  await call('PATCH', `/api/admin/parts/${partIds[2]}`, { token: t, body: { status: 'draft' } });
  assert.equal((await call('POST', `/api/parts/${partIds[2]}/access`, { token: alice.token(), body: { mode: 'watch' } })).status, 404);
  assert.equal(mock.read(`videos/${videoId}`).partsCount, 2);
  await call('PATCH', `/api/admin/parts/${partIds[2]}`, { token: t, body: { status: 'published' } });
  assert.equal(mock.read(`videos/${videoId}`).partsCount, 3);
});

// ------------------------------------------------------------------------------------------------ admin
test('admin: dashboard, user management, suspension, no self-demotion', async () => {
  const t = admin.token();
  const d = await call('GET', '/api/admin/dashboard', { token: t });
  assert.equal(d.status, 200, d.text);
  assert.equal(d.data.totals.users, 4);
  assert.equal(d.data.totals.videos, 1);
  assert.equal(d.data.totals.views, 2, 'one view each from alice and bob (counted on the server)');
  assert.ok(d.data.recentUsers.length > 0);

  assert.equal((await call('PATCH', `/api/admin/users/${admin.u.uid}`, { token: t, body: { role: 'user' } })).status, 400);
  assert.equal((await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'superuser' } })).status, 400);
  const sus = await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { status: 'suspended' } });
  assert.equal(sus.status, 200, sus.text);
  assert.equal(sus.data.authSync, true);
  assert.equal(mock.users.get('bob@site.test').disabled, true, 'Firebase Auth account disabled as well');
  assert.equal((await call('POST', `/api/videos/${videoId}/like`, { token: bob.token(), body: { liked: true } })).data.error.code, 'account_suspended');
  assert.equal((await call('POST', '/api/session', { token: bob.token() })).status, 403);
  await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { status: 'active' } });
  assert.equal((await call('POST', '/api/session', { token: bob.token() })).status, 200);

  // role management
  assert.equal((await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'admin' } })).status, 200);
  assert.equal((await call('GET', '/api/admin/users', { token: bob.token() })).status, 200);
  await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'user' } });
  assert.equal((await call('GET', '/api/admin/users', { token: bob.token() })).status, 403, 'demotion takes effect immediately');

  const list = await call('GET', '/api/admin/users?q=ali', { token: t });
  assert.equal(list.data.users.length, 1);
  const an = await call('GET', '/api/admin/analytics', { token: t });
  assert.equal(an.status, 200, an.text);
  assert.ok(an.data.auditLog.length > 0);
});

test('a second video (kept for the avatar test)', async () => {
  const t = admin.token();
  const v = await call('POST', '/api/admin/videos', { token: t, body: { title: 'Second Clip' } });
  assert.equal(v.status, 201, v.text);
  videoId2 = v.data.id;
  const up = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  assert.equal((await addPart(t, videoId2, { videoFileId: up.body.fileId, locked: false, status: 'published' })).status, 201);
  assert.equal((await call('PATCH', `/api/admin/videos/${videoId2}`, { token: t, body: { status: 'published' } })).status, 200);
});

test('admin: media list protects files in use; only this app\'s folder can be touched; delete video cascades', async () => {
  const t = admin.token();
  const list = await call('GET', '/api/admin/media?prefix=videos', { token: t });
  assert.equal(list.status, 200, list.text);
  const mine = list.data.objects.find((o) => o.fileId === globalThis.partFileId);
  assert.equal(mine.usedBy.id, videoId);
  assert.match(mine.usedBy.title, /^Part 1/);
  assert.equal(mine.url, '', 'private files expose no URL');
  const thumbs = await call('GET', '/api/admin/media?prefix=thumbs', { token: t });
  const myThumb = thumbs.data.objects.find((o) => o.fileId === globalThis.thumbFileId);
  assert.equal(myThumb.usedBy.id, videoId);
  assert.match(myThumb.url, /\/provalut\/thumbs\//);
  assert.equal((await call('GET', '/api/admin/media?prefix=etc', { token: t })).status, 400);

  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: globalThis.partFileId } })).data.error.code, 'in_use');
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: '../x' } })).status, 400);
  mock.imagekit.files.set('outsider0000000001', { fileId: 'outsider0000000001', name: 'logo.png', filePath: '/company/logo.png', size: 3, mime: 'image/png', isPrivateFile: false, bytes: Buffer.from([1, 2, 3]), createdAt: new Date().toISOString() });
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: 'outsider0000000001' } })).data.error.code, 'media_wrong_folder');
  assert.ok(mock.imagekit.files.has('outsider0000000001'));
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: 'neverexisted000000001' } })).status, 404);

  const partFiles = mock.ids('parts').map((k) => mock.read(`parts/${k}`)).filter((p) => p.videoId === videoId).map((p) => p.videoFileId).filter(Boolean);
  assert.ok(partFiles.length >= 2);
  const del = await call('DELETE', `/api/admin/videos/${videoId}?deleteMedia=1`, { token: t });
  assert.equal(del.status, 200, del.text);
  assert.equal(del.data.cleanupPending, false);
  assert.equal(mock.read(`videos/${videoId}`), null);
  assert.equal(mock.ids('parts').filter((k) => mock.read(`parts/${k}`).videoId === videoId).length, 0, 'parts removed');
  for (const f of partFiles) assert.equal(mock.imagekit.files.has(f), false, 'part file removed from ImageKit');
  assert.equal(mock.imagekit.files.has(globalThis.thumbFileId), false, 'cover removed from ImageKit');
  for (const col of ['likes', 'saves', 'comments', 'views', 'unlocks', 'adSessions', 'history']) {
    assert.equal(mock.ids(col).filter((k) => mock.read(`${col}/${k}`)?.videoId === videoId).length, 0, `${col} cleaned up`);
  }
  const orphan = await uploadToImageKit(t, 'thumbnail', PNG, 'image/png');
  const listed = await call('GET', '/api/admin/media?prefix=thumbs', { token: t });
  assert.equal(listed.data.objects[0].usedBy, null);
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: orphan.body.fileId } })).status, 200);
  assert.equal(mock.imagekit.files.has(orphan.body.fileId), false);
});

test('profile photo: validated on the server, stored in ImageKit, replaced and removed cleanly', async () => {
  const t = alice.token();
  const post = (bytes, type) => call('POST', '/api/me/avatar', { token: t, raw: bytes, headers: { 'Content-Type': type } });
  assert.equal((await post(PNG, 'image/gif')).status, 400);
  assert.equal((await post(new Uint8Array([1, 2, 3, 4, 5, 6]), 'image/png')).data.error.code, 'bad_content', 'bytes must match the declared type');
  assert.equal((await post(new Uint8Array(2 * 1024 * 1024 + 1), 'image/png')).status, 413);
  assert.equal((await call('POST', '/api/me/avatar', { raw: PNG, headers: { 'Content-Type': 'image/png' } })).status, 401);

  const ok = await post(PNG, 'image/png');
  assert.equal(ok.status, 200, ok.text);
  const first = mock.read(`users/${alice.u.uid}`);
  assert.match(first.photoURL, new RegExp(`^${mock.url}/ik/media/${IK.id}/provalut/avatars/${alice.u.uid}`));
  assert.equal(ok.data.user.photoURL, first.photoURL);
  assert.equal(mock.imagekit.files.get(first.photoFileId).isPrivateFile, false);
  assert.equal((await fetch(first.photoURL)).status, 200);
  assert.equal((await post(PNG, 'image/png')).status, 429, 'cooldown between changes');

  await new Promise((r) => setTimeout(r, 3100));
  const second = await post(PNG, 'image/png');
  assert.equal(second.status, 200, second.text);
  assert.equal(mock.imagekit.files.has(first.photoFileId), false, 'previous photo deleted from ImageKit');
  const now = mock.read(`users/${alice.u.uid}`);
  assert.notEqual(now.photoFileId, first.photoFileId);

  // admin sees it in the media manager; it is in use so it cannot be deleted
  const list = await call('GET', '/api/admin/media?prefix=avatars', { token: admin.token() });
  assert.equal(list.data.objects.find((o) => o.fileId === now.photoFileId).usedBy.type, 'user');
  assert.equal((await call('DELETE', '/api/admin/media', { token: admin.token(), body: { fileId: now.photoFileId } })).data.error.code, 'in_use');

  // the session payload and new comments carry the photo
  assert.equal((await call('POST', '/api/session', { token: t })).data.user.photoURL, now.photoURL);
  const c = await call('POST', `/api/videos/${videoId2}/comments`, { token: t, body: { text: 'with photo' } });
  assert.equal(c.data.comment.authorPhoto, now.photoURL);
  await call('DELETE', `/api/comments/${c.data.comment.id}`, { token: t });

  await new Promise((r) => setTimeout(r, 3100));
  const gone = await post(PNG, 'image/png');
  assert.equal(gone.status, 200);
  const rm = await call('DELETE', '/api/me/avatar', { token: t });
  assert.equal(rm.status, 200);
  assert.equal(rm.data.user.photoURL, '');
  assert.equal(mock.read(`users/${alice.u.uid}`).photoFileId, '');
  assert.equal([...mock.imagekit.files.values()].filter((f) => f.filePath.startsWith('/provalut/avatars/')).length, 0);
  // leave one in place so account deletion has something to clean up
  await new Promise((r) => setTimeout(r, 3100));
  assert.equal((await post(PNG, 'image/png')).status, 200);
});

test('account deletion needs a recent login and removes user data', async () => {
  const stale = mock.signIdToken(alice.u, { auth_time: Math.floor(Date.now() / 1000) - 3600 });
  assert.equal((await call('DELETE', '/api/me', { token: stale, body: { confirm: true } })).data.error.code, 'reauth_required');
  assert.equal((await call('DELETE', '/api/me', { token: alice.token(), body: {} })).status, 400);
  const adminDel = await call('DELETE', '/api/me', { token: admin.token(), body: { confirm: true } });
  assert.equal(adminDel.data.error.code, 'admin_self_delete');
  const del = await call('DELETE', '/api/me', { token: alice.token(), body: { confirm: true } });
  assert.equal(del.data.done, true, del.text);
  assert.equal(mock.read(`users/${alice.u.uid}`), null);
  assert.equal(mock.users.has('alice@site.test'), false);
  assert.equal([...mock.imagekit.files.values()].filter((f) => f.filePath.startsWith('/provalut/avatars/')).length, 0, 'avatar removed with the account');
});

test('closed sign-ups block new profiles', async () => {
  await call('PUT', '/api/admin/settings', { token: admin.token(), body: { allowSignups: false } });
  const carol = person('carol@site.test');
  const r = await call('POST', '/api/session', { token: carol.token() });
  assert.equal(r.data.error.code, 'signups_closed');
  await call('PUT', '/api/admin/settings', { token: admin.token(), body: { allowSignups: true } });
});

test('unknown routes and methods', async () => {
  assert.equal((await call('GET', '/api/nope')).status, 404);
  assert.equal((await call('DELETE', '/api/health')).status, 405);
  const big = await call('POST', '/api/session', { token: admin.token(), raw: 'x'.repeat(10) });
  assert.equal(big.status, 200);
});
