// Runs firestore.rules and storage.rules against the real Firebase emulator. NOT part of `npm test` (needs the emulator).
//   npm install --no-save firebase-tools @firebase/rules-unit-testing firebase
//   npx firebase emulators:exec --only firestore --project demo-provalut "node test/rules.emulator.mjs"
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import { doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, collection, query, where, orderBy, limit } from 'firebase/firestore';

const env = await initializeTestEnvironment({
  projectId: 'demo-provalut',
  firestore: { rules: fs.readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8') },
});

// Seed with rules disabled (this is what the API's service account does).
await env.withSecurityRulesDisabled(async (ctx) => {
  const db = ctx.firestore();
  const put = (p, d) => setDoc(doc(db, p), d);
  await put('users/admin1', { role: 'admin', status: 'active', email: 'boss@site.test' });
  await put('users/alice', { role: 'user', status: 'active', email: 'alice@site.test' });
  await put('users/bob', { role: 'user', status: 'active' });
  await put('users/mallory', { role: 'user', status: 'suspended' });
  await put('videos/pub', { title: 'Public', status: 'published', createdAt: new Date(), views: 1, category: 'Movies', searchTokens: ['public'] });
  await put('videos/draft', { title: 'Draft', status: 'draft', createdAt: new Date() });
  await put('parts/p1', { videoId: 'pub', number: 1, unlockUrl: 'https://ads.example.com/offer', videoUrl: 'https://x' });
  await put('unlocks/alice_p1', { uid: 'alice', partId: 'p1', videoId: 'pub', verification: 'timer' });
  await put('adSessions/s1', { uid: 'alice', partId: 'p1' });
  await put('views/v1', { uid: 'alice' });
  await put('likes/alice_pub', { uid: 'alice', videoId: 'pub' });
  await put('stats/2026-01-01', { views: 1 });
  await put('auditLogs/a1', { action: 'x' });
  await put('saves/alice_pub', { uid: 'alice', videoId: 'pub', createdAt: new Date() });
  await put('saves/bob_pub', { uid: 'bob', videoId: 'pub', createdAt: new Date() });
  await put('history/alice_pub', { uid: 'alice', videoId: 'pub', updatedAt: new Date() });
  await put('history/bob_pub', { uid: 'bob', videoId: 'pub', updatedAt: new Date() });
  await put('notifications/pub_pub', { type: 'video_published', videoId: 'pub', createdAt: new Date() });
  await put('comments/c1', { videoId: 'pub', uid: 'alice', text: 'hi', createdAt: new Date() });
  await put('settings/public', { siteName: 'Provalut' });
});

const anon = env.unauthenticatedContext().firestore();
const alice = env.authenticatedContext('alice').firestore();
const admin = env.authenticatedContext('admin1').firestore();
const mallory = env.authenticatedContext('mallory').firestore();
const noProfile = env.authenticatedContext('ghost').firestore();

let n = 0;
const ok = (name) => console.log(`  ${String(++n).padStart(2, '0')} ${name}`);

// ---- reads the app really performs
await assertSucceeds(getDocs(query(collection(anon, 'videos'), where('status', '==', 'published'), orderBy('createdAt', 'desc'), limit(10)))); ok('anyone lists published videos');
await assertSucceeds(getDoc(doc(anon, 'videos/pub'))); ok('anyone reads a published video');
await assertFails(getDoc(doc(anon, 'videos/draft'))); ok('anyone is refused a draft');
await assertFails(getDoc(doc(alice, 'videos/draft'))); ok('a normal user is refused a draft');
await assertFails(getDocs(collection(alice, 'videos'))); ok('listing videos without the published filter is refused');
await assertSucceeds(getDoc(doc(admin, 'videos/draft'))); ok('an active admin reads a draft (editor)');
await assertFails(getDoc(doc(noProfile, 'videos/draft'))); ok('a signed-in user without a server profile is not admin');
await assertSucceeds(getDocs(query(collection(anon, 'comments'), where('videoId', '==', 'pub'), orderBy('createdAt', 'desc'), limit(50)))); ok('comments are public');
await assertSucceeds(getDoc(doc(anon, 'settings/public'))); ok('public settings are readable');
await assertSucceeds(getDocs(query(collection(alice, 'saves'), where('uid', '==', 'alice'), orderBy('createdAt', 'desc')))); ok('a user lists their own saves');
await assertFails(getDocs(query(collection(alice, 'saves'), where('uid', '==', 'bob')))); ok("a user cannot list someone else's saves");
await assertFails(getDocs(collection(alice, 'saves'))); ok('an unfiltered saves query is refused');
await assertFails(getDoc(doc(alice, 'saves/bob_pub'))); ok("a user cannot read another user's save");
await assertSucceeds(getDocs(query(collection(alice, 'history'), where('uid', '==', 'alice'), orderBy('updatedAt', 'desc'), limit(40)))); ok('a user lists their own history');
await assertFails(getDoc(doc(alice, 'history/bob_pub'))); ok("a user cannot read another user's history");
await assertFails(getDocs(query(collection(anon, 'history'), where('uid', '==', 'alice')))); ok('history needs sign-in');
await assertSucceeds(getDocs(query(collection(alice, 'notifications'), orderBy('createdAt', 'desc'), limit(40)))); ok('signed-in users read notifications');
await assertFails(getDocs(collection(anon, 'notifications'))); ok('visitors cannot read notifications');
await assertFails(getDocs(query(collection(mallory, 'saves'), where('uid', '==', 'mallory')))); ok('a suspended user loses their reads');
await assertFails(getDocs(collection(mallory, 'notifications'))); ok('a suspended user cannot read notifications');

// ---- everything that must stay server-only
for (const [who, db] of [['visitor', anon], ['user', alice], ['admin', admin]]) {
  for (const p of ['users/alice', 'parts/p1', 'unlocks/alice_p1', 'adSessions/s1', 'views/v1', 'likes/alice_pub', 'stats/2026-01-01', 'auditLogs/a1']) {
    await assertFails(getDoc(doc(db, p)));
  }
  await assertFails(getDocs(collection(db, 'users')));
  await assertFails(getDocs(collection(db, 'parts')));
  await assertFails(getDocs(collection(db, 'unlocks')));
}
ok('users, parts (unlock links and media), unlocks, adSessions, views, likes, stats, auditLogs are unreadable even for admins in the browser');

// ---- no browser write, ever
for (const [who, db] of [['visitor', anon], ['user', alice], ['admin', admin]]) {
  await assertFails(setDoc(doc(db, 'users/alice'), { role: 'admin', status: 'active' }));
  await assertFails(updateDoc(doc(db, 'users/alice'), { role: 'admin' }));
  await assertFails(setDoc(doc(db, 'users/newuser'), { role: 'admin' }));
  await assertFails(setDoc(doc(db, 'unlocks/alice_p2'), { uid: 'alice', partId: 'p2', verification: 'postback' }));
  await assertFails(updateDoc(doc(db, 'unlocks/alice_p1'), { verification: 'postback' }));
  await assertFails(deleteDoc(doc(db, 'unlocks/alice_p1')));
  await assertFails(setDoc(doc(db, 'parts/p9'), { videoId: 'pub', unlockUrl: 'https://evil.test' }));
  await assertFails(updateDoc(doc(db, 'videos/pub'), { views: 999999 }));
  await assertFails(setDoc(doc(db, 'videos/new'), { title: 'x', status: 'published' }));
  await assertFails(setDoc(doc(db, 'saves/alice_x'), { uid: 'alice', videoId: 'x' }));
  await assertFails(setDoc(doc(db, 'history/alice_x'), { uid: 'alice', videoId: 'x' }));
  await assertFails(setDoc(doc(db, 'comments/c9'), { videoId: 'pub', uid: 'alice', text: 'spam' }));
  await assertFails(deleteDoc(doc(db, 'comments/c1')));
  await assertFails(setDoc(doc(db, 'notifications/pub_fake'), { title: 'fake' }));
  await assertFails(setDoc(doc(db, 'settings/public'), { siteName: 'hacked' }));
  await assertFails(setDoc(doc(db, 'adSessions/s2'), { uid: 'alice' }));
}
ok('no visitor, user or admin can create, update or delete anything from the browser');

await env.cleanup();
console.log('\nAll Firestore rule checks passed.');
