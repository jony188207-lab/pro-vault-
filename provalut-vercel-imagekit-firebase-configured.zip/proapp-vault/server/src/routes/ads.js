// Provider postback (server-to-server confirmation for part unlocks) and the sandboxed banner frames.
// The unlock flow itself lives in routes/parts.js. Banner placements never unlock anything.
//
// What the unlock flow can and cannot prove:
//   * verification "sponsor_opened": the server issued the sponsor link, the browser asked for it, and at least
//     `minAwaySeconds` passed (measured on the server) before the viewer asked to unlock. It does NOT prove that
//     an advertisement was displayed or watched - no ad network exposes that for a plain link.
//   * verification "postback": the unlock additionally waits for a server-to-server confirmation from the ad
//     provider (POST/GET /api/ads/postback with AD_POSTBACK_SECRET). Use this with providers that offer it.
// The wording shown to viewers is admin-editable, so admins must not claim "ad viewed" unless the provider confirmed it.
import { W, FirestoreError } from '../lib/firestore.js';
import { badRequest, forbidden, json, notFound, readJson } from '../lib/http.js';
import { safeEqual } from '../lib/signing.js';
import { BANNER_FRAME_CSP, bannerFrameDocument } from '../lib/sanitize.js';
import { allowedOrigins } from '../lib/http.js';
import { BANNER_PLACEMENTS } from '../lib/settings.js';

/** GET|POST /api/ads/postback?sid=...&secret=... - server-to-server confirmation from an ad provider. */
export async function postback(c) {
  const secret = c.env.AD_POSTBACK_SECRET;
  if (!secret || secret.length < 16) throw notFound();
  let sid = c.url.searchParams.get('sid');
  let provided = c.url.searchParams.get('secret') || c.request.headers.get('X-Postback-Secret');
  if (c.request.method === 'POST' && !sid) {
    const body = await readJson(c.request).catch(() => ({}));
    sid = body.sid;
    provided = provided || body.secret;
  }
  if (!provided || !(await safeEqual(provided, secret))) throw forbidden('Invalid secret', 'bad_secret');
  if (!sid || !/^[0-9a-f-]{36}$/.test(sid)) throw badRequest('Invalid sid', 'invalid_session');
  const doc = await c.fs.get(`adSessions/${sid}`);
  if (!doc) throw notFound('Unknown session', 'invalid_session');
  if (doc.data.status === 'opened' && doc.data.expiresAt instanceof Date && doc.data.expiresAt.getTime() > Date.now()) {
    try {
      await c.fs.commit([W.update(`adSessions/${sid}`, { status: 'confirmed' }, { updateTime: doc.updateTime, transforms: [{ field: 'confirmedAt', serverTime: true }] })]);
    } catch (e) {
      if (!(e instanceof FirestoreError && e.isPrecondition)) throw e;
    }
  }
  return json({ ok: true });
}

/** GET /api/ads/banner-frame?p=<placement> - one admin banner, served as its own sandboxed document. */
export async function bannerFrame(c) {
  const settings = await c.settings();
  const key = c.url.searchParams.get('p') || 'home';
  if (!Object.hasOwn(BANNER_PLACEMENTS, key)) throw badRequest('Unknown banner placement', 'invalid_field');
  const b = settings.banners[key];
  const html = b.enabled && b.html ? bannerFrameDocument(b.html) : bannerFrameDocument('');
  const ancestors = ["'self'", ...allowedOrigins(c.env)].join(' ');
  return new Response(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Security-Policy': `${BANNER_FRAME_CSP}; frame-ancestors ${ancestors}`,
      'Cache-Control': 'public, max-age=60',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
