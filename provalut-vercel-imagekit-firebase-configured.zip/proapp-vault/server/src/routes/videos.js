// Viewer actions on a video: state, like, save, comment (watching and downloading are in routes/parts.js). All counters are changed here, never by the client.
import { W, FirestoreError } from '../lib/firestore.js';
import { forbidden, json, notFound, readJson, badRequest } from '../lib/http.js';
import { cleanText } from '../lib/sanitize.js';
import { statsWrite, tooMany } from '../lib/context.js';
import { uuid } from '../lib/ids.js';

/** GET /api/videos/:id/state - like/save state. (Which parts are unlocked: GET /api/videos/:id/unlocks.) */
export async function videoState(c) {
  const id = c.params.id;
  await c.loadPublishedVideo(id);
  const [like, save] = await c.fs.getMany([`likes/${c.uid}_${id}`, `saves/${c.uid}_${id}`]);
  return json({ liked: !!like, saved: !!save });
}

/** POST /api/videos/:id/like { liked: boolean } - idempotent; one like per user per video. */
export async function setLike(c) {
  const id = c.params.id;
  const body = await readJson(c.request);
  if (typeof body.liked !== 'boolean') throw badRequest('liked must be true or false');
  const video = await c.loadPublishedVideo(id);
  const likePath = `likes/${c.uid}_${id}`;
  const videoPath = `videos/${id}`;
  try {
    if (body.liked) {
      await c.fs.commit([
        W.set(likePath, { uid: c.uid, videoId: id }, { exists: false, transforms: [{ field: 'createdAt', serverTime: true }] }),
        W.update(videoPath, {}, { exists: true, transforms: [{ field: 'likes', increment: 1 }] }),
        statsWrite({ likes: 1 }),
      ]);
    } else {
      await c.fs.commit([
        W.del(likePath, { exists: true }),
        W.update(videoPath, {}, { exists: true, transforms: [{ field: 'likes', increment: -1 }] }),
        statsWrite({ likes: -1 }),
      ]);
    }
  } catch (e) {
    if (!(e instanceof FirestoreError && e.isPrecondition)) throw e; // already liked / already unliked: nothing to do
  }
  const fresh = await c.fs.get(videoPath);
  return json({ liked: body.liked, likes: fresh?.data.likes ?? video.data.likes ?? 0 });
}

/** POST /api/videos/:id/save { saved: boolean } */
export async function setSave(c) {
  const id = c.params.id;
  const body = await readJson(c.request);
  if (typeof body.saved !== 'boolean') throw badRequest('saved must be true or false');
  await c.loadPublishedVideo(id);
  const savePath = `saves/${c.uid}_${id}`;
  const videoPath = `videos/${id}`;
  try {
    if (body.saved) {
      await c.fs.commit([
        W.set(savePath, { uid: c.uid, videoId: id }, { exists: false, transforms: [{ field: 'createdAt', serverTime: true }] }),
        W.update(videoPath, {}, { exists: true, transforms: [{ field: 'savesCount', increment: 1 }] }),
      ]);
    } else {
      await c.fs.commit([
        W.del(savePath, { exists: true }),
        W.update(videoPath, {}, { exists: true, transforms: [{ field: 'savesCount', increment: -1 }] }),
      ]);
    }
  } catch (e) {
    if (!(e instanceof FirestoreError && e.isPrecondition)) throw e;
  }
  return json({ saved: body.saved });
}

/** POST /api/videos/:id/comments { text } */
export async function addComment(c) {
  const id = c.params.id;
  const [body, settings] = await Promise.all([readJson(c.request), c.settings()]);
  if (!settings.commentsEnabled) throw forbidden('Comments are turned off', 'comments_disabled');
  const text = cleanText(body.text, { field: 'Comment', min: 1, max: 1000, multiline: true });
  await c.loadPublishedVideo(id);
  const last = c.user.lastCommentAt instanceof Date ? c.user.lastCommentAt.getTime() : 0;
  if (Date.now() - last < 3000) throw tooMany('You are commenting too fast. Wait a few seconds.');
  const commentId = uuid();
  await c.fs.commit([
    W.set(
      `comments/${commentId}`,
      { videoId: id, uid: c.uid, authorName: c.user.displayName, authorPhoto: c.user.photoURL || '', text },
      { exists: false, transforms: [{ field: 'createdAt', serverTime: true }] },
    ),
    W.update(`videos/${id}`, {}, { exists: true, transforms: [{ field: 'commentsCount', increment: 1 }] }),
    W.update(`users/${c.uid}`, {}, { exists: true, transforms: [{ field: 'lastCommentAt', serverTime: true }] }),
    statsWrite({ comments: 1 }),
  ]);
  return json({ comment: { id: commentId, videoId: id, uid: c.uid, authorName: c.user.displayName, authorPhoto: c.user.photoURL || '', text, createdAt: new Date().toISOString() } }, 201);
}

/** DELETE /api/comments/:id - the author or an admin. */
export async function deleteComment(c) {
  const id = c.params.id;
  if (!/^[0-9a-f-]{36}$/.test(id)) throw notFound('Comment not found');
  const doc = await c.fs.get(`comments/${id}`);
  if (!doc) throw notFound('Comment not found');
  if (doc.data.uid !== c.uid && c.user.role !== 'admin') throw forbidden('You can only delete your own comments', 'not_owner');
  const video = await c.fs.get(`videos/${doc.data.videoId}`);
  const writes = [W.del(`comments/${id}`, { exists: true })];
  if (video) writes.push(W.update(`videos/${doc.data.videoId}`, {}, { exists: true, transforms: [{ field: 'commentsCount', increment: -1 }] }));
  try {
    await c.fs.commit(writes);
  } catch (e) {
    if (!(e instanceof FirestoreError && e.isPrecondition)) throw e;
  }
  if (doc.data.uid !== c.uid) await c.audit('comment.delete', id, { videoId: doc.data.videoId });
  return json({ deleted: true });
}
