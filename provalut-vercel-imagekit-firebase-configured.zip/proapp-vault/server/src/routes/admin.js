// Administrator endpoints. Every handler here is reached only after Ctx.authenticate('admin'), which re-reads the
// caller's role from Firestore on each request.
import { W, identityAdmin } from '../lib/firestore.js';
import { badRequest, conflict, HttpError, intParam, json, notFound, readJson } from '../lib/http.js';
import { cleanText, intInRange, oneOf } from '../lib/sanitize.js';
import { applySettingsPatch, SETTINGS_PATH } from '../lib/settings.js';
import { invalidateSettingsCache, publicUser } from '../lib/context.js';
import { searchTokens, uuid } from '../lib/ids.js';
import { cleanupVideoRound } from '../lib/cleanup.js';
import { IMAGE_TYPES, MAX_THUMB_BYTES, VIDEO_TYPES, maxVideoBytes } from '../storage/index.js';
import { MEDIA_REFS, resolveMedia } from '../lib/media.js';
import { notifyIfNewlyPublished, telegramConfigured } from '../lib/notify.js';
import { isFileId } from '../storage/imagekit.js';

// ------------------------------------------------------------------ dashboard & analytics
export async function dashboard(c) {
  const [users, suspended, videos, recent, daily] = await Promise.all([
    c.fs.aggregate({ collection: 'users', aggregations: [{ op: 'count', alias: 'total' }] }),
    c.fs.aggregate({ collection: 'users', where: [['status', '==', 'suspended']], aggregations: [{ op: 'count', alias: 'total' }] }),
    c.fs.aggregate({
      collection: 'videos',
      aggregations: [
        { op: 'count', alias: 'videos' },
        { op: 'sum', field: 'views', alias: 'views' },
        { op: 'sum', field: 'likes', alias: 'likes' },
        { op: 'sum', field: 'commentsCount', alias: 'comments' },
        { op: 'sum', field: 'savesCount', alias: 'saves' },
        { op: 'sum', field: 'downloads', alias: 'downloads' },
      ],
    }),
    c.fs.query({ collection: 'users', orderBy: [['lastActiveAt', 'desc']], limit: 8 }),
    c.fs.query({ collection: 'stats', orderBy: [['day', 'desc']], limit: 14 }),
  ]);
  return json({
    totals: { users: users.total, suspendedUsers: suspended.total, ...videos },
    recentUsers: recent.map((d) => publicUser({ ...d.data, uid: d.id })),
    daily: daily.map((d) => d.data).reverse(),
  });
}

export async function analytics(c) {
  const [topViews, topLikes, daily, logs] = await Promise.all([
    c.fs.query({ collection: 'videos', orderBy: [['views', 'desc']], limit: 10 }),
    c.fs.query({ collection: 'videos', orderBy: [['likes', 'desc']], limit: 10 }),
    c.fs.query({ collection: 'stats', orderBy: [['day', 'desc']], limit: 30 }),
    c.fs.query({ collection: 'auditLogs', orderBy: [['createdAt', 'desc']], limit: 25 }),
  ]);
  const slim = (d) => ({ id: d.id, title: d.data.title, views: d.data.views || 0, likes: d.data.likes || 0, comments: d.data.commentsCount || 0, saves: d.data.savesCount || 0, status: d.data.status });
  return json({
    topByViews: topViews.map(slim),
    topByLikes: topLikes.map(slim),
    daily: daily.map((d) => d.data).reverse(),
    auditLog: logs.map((d) => ({ id: d.id, ...d.data })),
  });
}

// ------------------------------------------------------------------ users
export async function listUsers(c) {
  const limit = intParam(c.url.searchParams.get('limit'), { min: 1, max: 50, def: 25 });
  const offset = intParam(c.url.searchParams.get('offset'), { min: 0, max: 5000, def: 0 });
  const q = (c.url.searchParams.get('q') || '').trim().toLowerCase().slice(0, 80);
  const spec = q
    ? { collection: 'users', where: [['email', '>=', q], ['email', '<', `${q}`]], orderBy: [['email', 'asc']] }
    : { collection: 'users', orderBy: [['createdAt', 'desc']] };
  const docs = await c.fs.query({ ...spec, limit: limit + 1, offset });
  return json({ users: docs.slice(0, limit).map((d) => publicUser({ ...d.data, uid: d.id })), hasMore: docs.length > limit });
}

export async function updateUser(c) {
  const uid = c.params.uid;
  if (!/^[A-Za-z0-9]{6,128}$/.test(uid)) throw notFound('User not found');
  if (uid === c.uid) throw badRequest('You cannot change your own role or status', 'self_change');
  const body = await readJson(c.request);
  const target = await c.fs.get(`users/${uid}`);
  if (!target) throw notFound('User not found');
  const changes = {};
  if ('role' in body) changes.role = oneOf(body.role, ['user', 'admin'], { field: 'role' });
  if ('status' in body) changes.status = oneOf(body.status, ['active', 'suspended'], { field: 'status' });
  if (!Object.keys(changes).length) throw badRequest('Nothing to change');
  await c.fs.commit([W.update(`users/${uid}`, changes, { exists: true })]);
  let authSync = null;
  if (changes.status && changes.status !== target.data.status) {
    try {
      await identityAdmin(c.env, 'update', { localId: uid, disableUser: changes.status === 'suspended' });
      authSync = true;
    } catch (e) {
      authSync = false;
      console.error('Auth sync failed', e.message);
    }
  }
  await c.audit('user.update', uid, { ...changes, email: target.data.email });
  return json({ user: publicUser({ ...target.data, ...changes, uid }), authSync });
}

// ------------------------------------------------------------------ videos
function parseTags(tags) {
  if (!Array.isArray(tags)) throw badRequest('tags must be a list');
  if (tags.length > 10) throw badRequest('Use at most 10 tags', 'invalid_field', { field: 'tags' });
  return [...new Set(tags.map((t) => cleanText(t, { field: 'Tag', min: 1, max: 30 }).toLowerCase()))];
}

async function buildVideo(c, body, existing, id) {
  const out = {};
  const merged = { ...(existing || {}) };
  if (!existing || 'title' in body) merged.title = out.title = cleanText(body.title, { field: 'Title', min: 1, max: 120 });
  if ('description' in body || !existing) merged.description = out.description = cleanText(body.description ?? '', { field: 'Description', max: 2000, multiline: true });
  if ('tags' in body || !existing) merged.tags = out.tags = parseTags(body.tags ?? []);
  if ('category' in body || !existing) merged.category = out.category = cleanText(body.category ?? '', { field: 'Category', max: 30 });
  if ('status' in body || !existing) merged.status = out.status = oneOf(body.status, ['published', 'draft'], { field: 'status', def: 'draft' });
  // the cover image of the video (each part may also have its own thumbnail)
  if ('thumbnailFileId' in body) {
    if (body.thumbnailFileId) Object.assign(out, await resolveMedia(c, body.thumbnailFileId, 'thumbnail', 'thumbnailFileId', { collection: 'videos', id }));
    else Object.assign(out, { thumbnailFileId: '', thumbnailUrl: '', thumbnailPath: '' });
  }
  if (!existing) {
    out.thumbnailFileId ??= '';
    out.thumbnailUrl ??= '';
    out.thumbnailPath ??= '';
  }
  if (merged.status === 'published' && !((existing?.partsCount || 0) > 0)) {
    throw badRequest('Add at least one published part before publishing this video', 'no_parts', { field: 'status' });
  }
  if ('title' in out || 'tags' in out) out.searchTokens = searchTokens(merged.title, (merged.tags || []).join(' '));
  return out;
}

export async function listVideos(c) {
  const limit = intParam(c.url.searchParams.get('limit'), { min: 1, max: 50, def: 25 });
  const offset = intParam(c.url.searchParams.get('offset'), { min: 0, max: 5000, def: 0 });
  const docs = await c.fs.query({ collection: 'videos', orderBy: [['createdAt', 'desc']], limit: limit + 1, offset });
  return json({ videos: docs.slice(0, limit).map((d) => ({ id: d.id, ...d.data })), hasMore: docs.length > limit });
}

export async function createVideo(c) {
  const body = await readJson(c.request);
  const id = uuid();
  const data = await buildVideo(c, body, null, id);
  await c.fs.commit([
    W.set(
      `videos/${id}`,
      { ...data, views: 0, likes: 0, commentsCount: 0, savesCount: 0, downloads: 0, partsCount: 0, partsTotal: 0, partsSummary: [], createdBy: c.uid },
      { exists: false, transforms: [{ field: 'createdAt', serverTime: true }, { field: 'updatedAt', serverTime: true }] },
    ),
  ]);
  await c.audit('video.create', id, { title: data.title });
  return json({ id }, 201);
}

export async function updateVideo(c) {
  const id = c.params.id;
  const existing = await c.fs.get(`videos/${id}`);
  if (!existing) throw notFound('Video not found');
  const body = await readJson(c.request);
  const data = await buildVideo(c, body, existing.data, id);
  if (!Object.keys(data).length) throw badRequest('Nothing to change');
  const stale = 'thumbnailFileId' in data && existing.data.thumbnailFileId && data.thumbnailFileId !== existing.data.thumbnailFileId ? existing.data.thumbnailFileId : '';
  await c.fs.commit([W.update(`videos/${id}`, data, { exists: true, transforms: [{ field: 'updatedAt', serverTime: true }] })]);
  if (stale) await c.storage.deleteFile(stale).catch(() => {});
  await c.audit('video.update', id, { fields: Object.keys(data) });
  const n = await notifyIfNewlyPublished(c, id);
  return json({ id, notified: n.notified });
}

/** DELETE /api/admin/videos/:id[?deleteMedia=1] - safe to call repeatedly until cleanupPending is false. */
export async function deleteVideo(c) {
  const id = c.params.id;
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(id)) throw notFound('Video not found');
  const withMedia = c.url.searchParams.get('deleteMedia') === '1';
  const doc = await c.fs.get(`videos/${id}`);
  if (doc) {
    await c.fs.commit([W.del(`videos/${id}`, { exists: true })]);
    if (withMedia && doc.data.thumbnailFileId) await c.storage.deleteFile(doc.data.thumbnailFileId);
    await c.audit('video.delete', id, { title: doc.data.title, deleteMedia: withMedia });
  }
  // parts: remove their records (and, on request, their ImageKit files) in bounded batches
  const parts = await c.fs.query({ collection: 'parts', where: [['videoId', '==', id]], limit: 100 });
  if (parts.length) {
    if (withMedia) for (const p of parts) for (const f of [p.data.videoFileId, p.data.thumbnailFileId]) if (f) await c.storage.deleteFile(f).catch(() => {});
    await c.fs.commit(parts.map((p) => W.del(p.path)));
  }
  const { pending } = await cleanupVideoRound(c.fs, id);
  return json({ deleted: true, cleanupPending: pending || parts.length === 100 });
}

// ------------------------------------------------------------------ settings
export async function getSettings(c) {
  return json({ settings: await c.settings({ fresh: true }), adScriptHostsConfigured: !!String(c.env.AD_SCRIPT_HOSTS || '').trim(), telegramConfigured: telegramConfigured(c.env) });
}

export async function putSettings(c) {
  const body = await readJson(c.request, 128 * 1024);
  const current = await c.settings({ fresh: true });
  const { settings, warnings } = applySettingsPatch(current, body, { env: c.env, adminUid: c.uid });
  await c.fs.commit([W.set(SETTINGS_PATH, settings, { transforms: [{ field: 'updatedAt', serverTime: true }] })]);
  invalidateSettingsCache();
  await c.audit('settings.update', 'settings/public', { keys: Object.keys(body) });
  return json({ settings, warnings });
}

// ------------------------------------------------------------------ media (ImageKit uploads, listing, deletion)
/**
 * POST /api/admin/uploads/auth { kind, contentType, size }
 * Returns the ImageKit client-side upload parameters (token, expire, signature are generated here with the private key).
 * The browser then POSTs the file straight to ImageKit; the private key never leaves the server.
 */
export async function uploadAuth(c) {
  const body = await readJson(c.request);
  const kind = oneOf(body.kind, ['video', 'thumbnail'], { field: 'kind' }); // videos here are part files
  const size = intInRange(body.size, { field: 'size', min: 1, max: Number.MAX_SAFE_INTEGER });
  let ext;
  let maxBytes;
  if (kind === 'video') {
    ext = VIDEO_TYPES[body.contentType];
    if (!ext) throw badRequest(`Unsupported video type. Allowed: ${Object.keys(VIDEO_TYPES).join(', ')}`, 'unsupported_type');
    maxBytes = maxVideoBytes(c.env);
  } else {
    ext = IMAGE_TYPES[body.contentType];
    if (!ext) throw badRequest(`Unsupported image type. Allowed: ${Object.keys(IMAGE_TYPES).join(', ')}`, 'unsupported_type');
    maxBytes = MAX_THUMB_BYTES;
  }
  if (size > maxBytes) throw new HttpError(413, `File is larger than the allowed ${Math.round(maxBytes / 1048576)} MB`, 'too_large');
  const auth = await c.storage.uploadAuth();
  return json({
    ...auth,
    fileName: `${uuid()}.${ext}`,
    folder: c.storage.folderFor(kind),
    useUniqueFileName: true,
    isPrivateFile: kind === 'video' && c.storage.privateVideos,
    maxBytes,
  });
}

const MEDIA_PAGE = 50;
const KIND_BY_PREFIX = { videos: 'video', thumbs: 'thumbnail', avatars: 'avatar' };

async function usageMap(c, prefix, ids) {
  const used = new Map();
  const kind = KIND_BY_PREFIX[prefix];
  for (const [collection, field] of MEDIA_REFS[kind]) {
    for (let i = 0; i < ids.length; i += 30) {
      const docs = await c.fs.query({ collection, where: [[field, 'in', ids.slice(i, i + 30)]], limit: 30 });
      for (const d of docs) {
        if (used.has(d.data[field])) continue;
        if (collection === 'users') used.set(d.data[field], { id: d.id, title: d.data.displayName, type: 'user' });
        else if (collection === 'parts') used.set(d.data[field], { id: d.data.videoId, title: `Part ${d.data.number}${d.data.title ? ` - ${d.data.title}` : ''}`, type: 'video' });
        else used.set(d.data[field], { id: d.id, title: d.data.title, type: 'video' });
      }
    }
  }
  return used;
}

export async function listMedia(c) {
  const prefix = oneOf(c.url.searchParams.get('prefix') || 'videos', Object.keys(KIND_BY_PREFIX), { field: 'prefix' });
  const skip = intParam(c.url.searchParams.get('cursor'), { min: 0, max: 100000, def: 0 });
  const files = await c.storage.listFiles({ kind: KIND_BY_PREFIX[prefix], limit: MEDIA_PAGE, skip });
  const used = files.length ? await usageMap(c, prefix, files.map((f) => f.fileId)) : new Map();
  return json({
    objects: files.map((f) => ({
      fileId: f.fileId,
      name: f.name,
      size: f.size,
      contentType: f.mime,
      uploaded: f.createdAt,
      isPrivate: f.isPrivate,
      // private files have no public URL; everything else is shown through our endpoint-based URL
      url: f.isPrivate ? '' : c.storage.urlFor(f.filePath),
      usedBy: used.get(f.fileId) || null,
    })),
    cursor: files.length === MEDIA_PAGE ? String(skip + MEDIA_PAGE) : null,
  });
}

/** DELETE /api/admin/media { fileId } - only files inside this app's ImageKit folder, and only when nothing references them. */
export async function deleteMedia(c) {
  const body = await readJson(c.request);
  if (!isFileId(body.fileId)) throw badRequest('Invalid file id', 'invalid_field', { field: 'fileId' });
  const f = await c.storage.getFile(body.fileId);
  if (!f) throw notFound('File not found');
  if (!f.filePath.startsWith(`${c.storage.folder}/`)) throw badRequest('That file is not in this app\'s media folder', 'media_wrong_folder');
  const refs = [
    ['videos', 'thumbnailFileId', (d) => `the video "${d.data.title}"`],
    ['parts', 'videoFileId', (d) => `part ${d.data.number} of a video`],
    ['parts', 'thumbnailFileId', (d) => `part ${d.data.number} of a video`],
    ['users', 'photoFileId', (d) => `${d.data.displayName}'s profile photo`],
  ];
  for (const [collection, field, label] of refs) {
    const hit = await c.fs.query({ collection, where: [[field, '==', f.fileId]], limit: 1 });
    if (hit.length) throw conflict(`This file is used by ${label(hit[0])}. Remove it there first.`, 'in_use');
  }
  await c.storage.deleteFile(f.fileId);
  await c.audit('media.delete', f.fileId, { path: f.filePath });
  return json({ deleted: true });
}
