// Session bootstrap and account management for the signed-in user.
import { W, FirestoreError, identityAdmin } from '../lib/firestore.js';
import { forbidden, json, readJson, unauthorized, badRequest, HttpError } from '../lib/http.js';
import { cleanText, parseList } from '../lib/sanitize.js';
import { publicUser, statsWrite } from '../lib/context.js';
import { cleanupUserRound } from '../lib/cleanup.js';
import { IMAGE_TYPES, MAX_AVATAR_BYTES, sniffMatches } from '../storage/index.js';

const ACTIVE_TOUCH_MS = 5 * 60 * 1000;

function defaultName(claims) {
  const fromToken = typeof claims.name === 'string' ? claims.name : '';
  const fromEmail = (claims.email || '').split('@')[0];
  try {
    return cleanText(fromToken || fromEmail || 'Member', { field: 'Name', min: 1, max: 40 });
  } catch {
    return 'Member';
  }
}

/** POST /api/session - called right after sign-in. Creates the profile on first use. */
export async function session(c) {
  const { claims } = c.auth;
  let user = c.auth.user;
  const email = String(claims.email || '').toLowerCase();
  const settings = await c.settings();
  // Bootstrap admins: only trusted when Firebase says the e-mail address is verified.
  const bootstrap = claims.email_verified === true && email && parseList(c.env.BOOTSTRAP_ADMIN_EMAILS).includes(email);

  if (!user) {
    if (!settings.allowSignups) throw forbidden('New sign-ups are currently closed', 'signups_closed');
    const fresh = {
      email,
      displayName: defaultName(claims),
      photoURL: '',
      role: bootstrap ? 'admin' : 'user',
      status: 'active',
      emailVerified: claims.email_verified === true,
      photoURL: '',
      photoFileId: '',
    };
    try {
      await c.fs.commit([
        W.set(`users/${c.uid}`, fresh, {
          exists: false,
          transforms: [
            { field: 'createdAt', serverTime: true },
            { field: 'lastActiveAt', serverTime: true },
          ],
        }),
        statsWrite({ signups: 1 }),
      ]);
    } catch (e) {
      if (!(e instanceof FirestoreError && e.isPrecondition)) throw e; // concurrent first call: profile already exists
    }
    const doc = await c.fs.get(`users/${c.uid}`);
    user = { ...doc.data, uid: c.uid };
  } else {
    if (user.status !== 'active') throw forbidden('This account is suspended', 'account_suspended');
    const patch = {};
    if (user.emailVerified !== (claims.email_verified === true)) patch.emailVerified = claims.email_verified === true;
    if (email && user.email !== email) patch.email = email;
    if (bootstrap && user.role !== 'admin') patch.role = 'admin';
    const last = user.lastActiveAt instanceof Date ? user.lastActiveAt.getTime() : 0;
    const touch = Date.now() - last > ACTIVE_TOUCH_MS;
    if (touch || Object.keys(patch).length) {
      await c.fs.commit([W.update(`users/${c.uid}`, patch, { exists: true, transforms: touch ? [{ field: 'lastActiveAt', serverTime: true }] : [] })]);
      user = { ...user, ...patch };
    }
  }
  return json({ user: publicUser(user) });
}

/** PATCH /api/me - change display name. */
export async function updateMe(c) {
  const body = await readJson(c.request);
  const displayName = cleanText(body.displayName, { field: 'Display name', min: 2, max: 40 });
  await c.fs.commit([W.update(`users/${c.uid}`, { displayName }, { exists: true })]);
  return json({ user: publicUser({ ...c.user, displayName }) });
}

/**
 * DELETE /api/me - permanently delete the account and its data.
 * Requires a recent sign-in (auth_time within 5 minutes). Call repeatedly while { done: false }.
 */
export async function deleteMe(c) {
  const body = await readJson(c.request);
  if (body.confirm !== true) throw badRequest('Confirmation required', 'confirm_required');
  const authTime = Number(c.auth.claims.auth_time || 0);
  if (!authTime || Date.now() / 1000 - authTime > 300) throw unauthorized('Please sign in again to delete your account', 'reauth_required');
  if (c.user.role === 'admin') throw forbidden('Administrators cannot delete their own account. Ask another admin to remove the admin role first.', 'admin_self_delete');
  const { pending } = await cleanupUserRound(c.fs, c.uid);
  if (pending) return json({ done: false });
  await removeStoredAvatar(c, c.user.photoFileId);
  await c.fs.commit([W.del(`users/${c.uid}`)]);
  let authDeleted = true;
  try {
    await identityAdmin(c.env, 'delete', { localId: c.uid });
  } catch (e) {
    authDeleted = false;
    console.error('Auth user deletion failed', e.message);
  }
  return json({ done: true, authDeleted });
}

// ---------------------------------------------------------------- profile photo (stored in ImageKit)
async function removeStoredAvatar(c, fileId) {
  if (!fileId) return;
  try {
    await c.storage.deleteFile(fileId);
  } catch (e) {
    console.error('Could not delete old avatar', e.message); // the profile no longer points at it; an admin can remove leftovers in Media
  }
}

/**
 * POST /api/me/avatar - body is the raw image (JPEG, PNG or WebP, up to 2 MB). The server checks the bytes and uploads
 * to ImageKit itself, so no upload credentials are ever handed to ordinary users.
 */
export async function setAvatar(c) {
  const type = (c.request.headers.get('Content-Type') || '').split(';')[0].trim().toLowerCase();
  const ext = IMAGE_TYPES[type];
  if (!ext) throw badRequest('Use a JPG, PNG or WebP image', 'unsupported_type');
  if (Number(c.request.headers.get('Content-Length') || 0) > MAX_AVATAR_BYTES) throw new HttpError(413, 'Profile photos must be 2 MB or smaller', 'too_large');
  const last = c.user.lastAvatarAt instanceof Date ? c.user.lastAvatarAt.getTime() : 0;
  if (Date.now() - last < 3000) throw new HttpError(429, 'Please wait a few seconds before changing your photo again', 'slow_down');
  const bytes = new Uint8Array(await c.request.arrayBuffer());
  if (!bytes.length || bytes.length > MAX_AVATAR_BYTES) throw new HttpError(413, 'Profile photos must be 2 MB or smaller', 'too_large');
  if (!sniffMatches(type, bytes.subarray(0, 16))) throw badRequest('That file is not a valid image', 'bad_content');

  const file = await c.storage.uploadBytes({ bytes, fileName: `${c.uid}.${ext}`, kind: 'avatar', contentType: type });
  const photoURL = c.storage.urlFor(file.filePath);
  await c.fs.commit([W.update(`users/${c.uid}`, { photoURL, photoFileId: file.fileId }, { exists: true, transforms: [{ field: 'lastAvatarAt', serverTime: true }] })]);
  if (c.user.photoFileId && c.user.photoFileId !== file.fileId) await removeStoredAvatar(c, c.user.photoFileId);
  return json({ user: publicUser({ ...c.user, photoURL }) });
}

/** DELETE /api/me/avatar */
export async function removeAvatar(c) {
  const old = c.user.photoFileId;
  await c.fs.commit([W.update(`users/${c.uid}`, { photoURL: '', photoFileId: '' }, { exists: true })]);
  await removeStoredAvatar(c, old);
  return json({ user: publicUser({ ...c.user, photoURL: '' }) });
}

// ---------------------------------------------------------------- notifications and history
/** POST /api/me/notifications/seen - everything published so far counts as read for this user. */
export async function markNotificationsSeen(c) {
  await c.fs.commit([W.update(`users/${c.uid}`, {}, { exists: true, transforms: [{ field: 'notificationsSeenAt', serverTime: true }] })]);
  return json({ ok: true });
}

/** DELETE /api/me/history - clear the signed-in user's watch history. */
export async function clearHistory(c) {
  const n = await c.fs.deleteWhere('history', [['uid', '==', c.uid]], 400);
  return json({ cleared: n, more: n === 400 });
}
