// Multi-part videos: admin part management, per-part unlock (Smartlink) and watch/download access.
//
// Data: `videos/{id}` is public and holds only a summary of the published parts (no media URLs, no unlock links).
// `parts/{pid}` is server-only (no browser access in firestore.rules) and holds the media, download URL and unlock link.
//
// IMPORTANT - what the unlock flow can and cannot prove:
//   * verification "sponsor_opened": the server issued the unlock link to this user and at least `minAwaySeconds` passed
//     (measured on the server) before the user asked to unlock. It does NOT prove that an advertisement was shown or
//     completed - a plain Smartlink exposes no completion signal.
//   * verification "postback": the unlock also waits for a server-to-server confirmation from your provider
//     (/api/ads/postback with AD_POSTBACK_SECRET). Use it only with a provider that really sends one.
// Banner ads never unlock anything; they are rendered separately (routes/ads.js).
import { W, FirestoreError } from '../lib/firestore.js';
import { HttpError, badRequest, conflict, json, notFound, readJson } from '../lib/http.js';
import { bool, cleanText, httpsUrl, intInRange, oneOf } from '../lib/sanitize.js';
import { statsWrite, tooMany } from '../lib/context.js';
import { uuid } from '../lib/ids.js';
import { resolveMedia } from '../lib/media.js';
import { notifyIfNewlyPublished } from '../lib/notify.js';

const VIEW_WINDOW_MS = 30 * 60 * 1000;
const PLAYBACK_TTL_S = 6 * 3600;
const MAX_PARTS = 500;
const ID = /^[A-Za-z0-9_-]{6,64}$/;

// ------------------------------------------------------------------------------------------------ helpers
export function summaryOf(parts) {
  return parts
    .filter((p) => p.data.status === 'published')
    .map((p, i) => ({
      id: p.id,
      number: i + 1,
      title: p.data.title || '',
      quality: p.data.quality || 'HD',
      locked: !!p.data.locked,
      thumbnailUrl: p.data.thumbnailUrl || '',
      // how the viewer's browser must handle it: play/save from ImageKit in the page, or open another site in a new tab
      source: p.data.videoUrl ? 'imagekit' : 'external',
      downloadVia: p.data.downloadUrl || !p.data.videoUrl ? 'external' : 'file',
    }));
}

/**
 * Renumber the parts 1..n in their current order and refresh the public summary on the video.
 * Called after every part change so numbering is always consecutive.
 */
export async function syncVideoParts(c, videoId) {
  const parts = await c.fs.query({ collection: 'parts', where: [['videoId', '==', videoId]], orderBy: [['number', 'asc']], limit: MAX_PARTS });
  const writes = [];
  parts.forEach((p, i) => {
    if (p.data.number !== i + 1) {
      p.data.number = i + 1;
      writes.push(W.update(p.path, { number: i + 1 }, { exists: true }));
    }
  });
  const summary = summaryOf(parts);
  writes.push(
    W.update(`videos/${videoId}`, { partsSummary: summary, partsCount: summary.length, partsTotal: parts.length }, { exists: true, transforms: [{ field: 'updatedAt', serverTime: true }] }),
  );
  await c.fs.commit(writes);
  return parts;
}

async function loadVideoForAdmin(c, id) {
  if (!ID.test(String(id))) throw notFound('Video not found');
  const v = await c.fs.get(`videos/${id}`);
  if (!v) throw notFound('Video not found');
  return v;
}

async function loadPart(c, pid) {
  if (!ID.test(String(pid))) throw notFound('Part not found', 'part_not_found');
  const p = await c.fs.get(`parts/${pid}`);
  if (!p) throw notFound('Part not found', 'part_not_found');
  return p;
}

const PART_VIEW = ['id', 'videoId', 'number', 'title', 'quality', 'status', 'locked', 'unlockUrl', 'minAwaySeconds', 'verification', 'videoFileId', 'videoUrl', 'videoPrivate', 'externalUrl', 'downloadUrl', 'thumbnailFileId', 'thumbnailUrl', 'sizeBytes', 'contentType', 'durationSec'];
const adminView = (p) => Object.fromEntries(PART_VIEW.map((k) => [k, k === 'id' ? p.id : p.data[k] ?? (['title', 'unlockUrl', 'externalUrl', 'downloadUrl'].includes(k) ? '' : undefined)]).filter(([, v]) => v !== undefined));

async function buildPart(c, body, existing, id, videoId) {
  const merged = { ...(existing || {}) };
  const out = {};
  const settings = await c.settings();
  if (!existing || 'title' in body) merged.title = out.title = cleanText(body.title ?? '', { field: 'Part title', max: 80 });
  if (!existing || 'quality' in body) merged.quality = out.quality = cleanText(body.quality ?? 'HD', { field: 'Quality', min: 1, max: 12 });
  if (!existing || 'status' in body) merged.status = out.status = oneOf(body.status, ['published', 'draft'], { field: 'status', def: 'draft' });
  if ('durationSec' in body) merged.durationSec = out.durationSec = body.durationSec ? intInRange(body.durationSec, { field: 'Duration', min: 0, max: 86400 }) : 0;

  // media: an uploaded ImageKit file OR an external https link (never both)
  const hasFile = 'videoFileId' in body && body.videoFileId;
  const hasExternal = 'externalUrl' in body && body.externalUrl;
  if (hasFile && hasExternal) throw badRequest('Use either an uploaded file or an external video URL, not both', 'invalid_field', { field: 'externalUrl' });
  if (hasFile) {
    Object.assign(out, await resolveMedia(c, body.videoFileId, 'video', 'videoFileId', { collection: 'parts', id }));
    out.externalUrl = '';
    Object.assign(merged, out);
  } else if (hasExternal) {
    out.externalUrl = merged.externalUrl = httpsUrl(body.externalUrl, { field: 'Video URL' });
    Object.assign(out, { videoFileId: '', videoUrl: '', videoPath: '', videoPrivate: false, sizeBytes: 0, contentType: '' });
    Object.assign(merged, out);
  } else if (!existing) {
    Object.assign(out, { videoFileId: '', videoUrl: '', videoPath: '', videoPrivate: false, externalUrl: '', sizeBytes: 0, contentType: '' });
    Object.assign(merged, out);
  } else if (('videoFileId' in body && !body.videoFileId) && ('externalUrl' in body && !body.externalUrl)) {
    Object.assign(out, { videoFileId: '', videoUrl: '', videoPath: '', videoPrivate: false, externalUrl: '', sizeBytes: 0, contentType: '' });
    Object.assign(merged, out);
  }
  if ('downloadUrl' in body) merged.downloadUrl = out.downloadUrl = httpsUrl(body.downloadUrl ?? '', { field: 'Download URL', allowEmpty: true });
  else if (!existing) out.downloadUrl = merged.downloadUrl = '';

  if ('thumbnailFileId' in body) {
    if (body.thumbnailFileId) Object.assign(out, await resolveMedia(c, body.thumbnailFileId, 'thumbnail', 'thumbnailFileId', { collection: 'parts', id }));
    else Object.assign(out, { thumbnailFileId: '', thumbnailUrl: '', thumbnailPath: '' });
  } else if (!existing) Object.assign(out, { thumbnailFileId: '', thumbnailUrl: '', thumbnailPath: '' });

  // unlock configuration. Parts are locked unless the admin says otherwise.
  if (!existing || 'locked' in body) merged.locked = out.locked = bool(body.locked, true);
  if ('unlockUrl' in body) merged.unlockUrl = out.unlockUrl = httpsUrl(body.unlockUrl ?? '', { field: 'Unlock link', allowEmpty: true });
  else if (!existing) merged.unlockUrl = out.unlockUrl = '';
  if ('verification' in body) merged.verification = out.verification = oneOf(body.verification, ['sponsor_opened', 'postback'], { field: 'Verification' });
  else if (!existing) merged.verification = out.verification = 'sponsor_opened';
  if ('minAwaySeconds' in body) merged.minAwaySeconds = out.minAwaySeconds = body.minAwaySeconds ? intInRange(body.minAwaySeconds, { field: 'Seconds away', min: 1, max: 120 }) : 0;
  else if (!existing) merged.minAwaySeconds = out.minAwaySeconds = 0;

  if (merged.locked) {
    if (!merged.unlockUrl && !settings.gate.defaultUnlockUrl) {
      throw badRequest('A locked part needs an unlock link (Smartlink). Add one for this part, or set a default link in Settings, or turn the lock off.', 'unlock_url_required', { field: 'unlockUrl' });
    }
    if (!settings.gate.policyAcknowledged) {
      throw badRequest('Before locking parts, confirm in Settings -> Unlock that your ad network allows this flow (many networks prohibit incentivised or forced ad actions).', 'policy_ack_required');
    }
  }
  if (merged.status === 'published' && !(merged.videoUrl || merged.externalUrl)) {
    throw badRequest('Add a video file or video URL before publishing this part', 'media_required', { field: 'videoFileId' });
  }
  return out;
}

// ------------------------------------------------------------------------------------------------ admin
/** GET /api/admin/videos/:id/parts */
export async function listParts(c) {
  await loadVideoForAdmin(c, c.params.id);
  const parts = await c.fs.query({ collection: 'parts', where: [['videoId', '==', c.params.id]], orderBy: [['number', 'asc']], limit: MAX_PARTS });
  return json({ parts: parts.map(adminView) });
}

/** POST /api/admin/videos/:id/parts */
export async function createPart(c) {
  const videoId = c.params.id;
  const video = await loadVideoForAdmin(c, videoId);
  if ((video.data.partsTotal || 0) >= MAX_PARTS) throw badRequest(`A video can have at most ${MAX_PARTS} parts`, 'too_many_parts');
  const body = await readJson(c.request);
  const id = uuid();
  const data = await buildPart(c, body, null, id, videoId);
  await c.fs.commit([
    W.set(`parts/${id}`, { ...data, videoId, number: (video.data.partsTotal || 0) + 1, createdBy: c.uid }, { exists: false, transforms: [{ field: 'createdAt', serverTime: true }, { field: 'updatedAt', serverTime: true }] }),
  ]);
  await syncVideoParts(c, videoId);
  await c.audit('part.create', id, { videoId });
  const n = await notifyIfNewlyPublished(c, videoId);
  return json({ id, notified: n.notified }, 201);
}

/** PATCH /api/admin/parts/:pid */
export async function updatePart(c) {
  const part = await loadPart(c, c.params.pid);
  const body = await readJson(c.request);
  const data = await buildPart(c, body, part.data, part.id, part.data.videoId);
  if (!Object.keys(data).length) throw badRequest('Nothing to change');
  // replaced media files are removed from ImageKit once the new values are saved
  const stale = [];
  if ('videoFileId' in data && part.data.videoFileId && data.videoFileId !== part.data.videoFileId) stale.push(part.data.videoFileId);
  if ('thumbnailFileId' in data && part.data.thumbnailFileId && data.thumbnailFileId !== part.data.thumbnailFileId) stale.push(part.data.thumbnailFileId);
  await c.fs.commit([W.update(part.path, data, { exists: true, transforms: [{ field: 'updatedAt', serverTime: true }] })]);
  for (const f of stale) await c.storage.deleteFile(f).catch(() => {});
  await syncVideoParts(c, part.data.videoId);
  await c.audit('part.update', part.id, { videoId: part.data.videoId, fields: Object.keys(data) });
  const n = await notifyIfNewlyPublished(c, part.data.videoId);
  return json({ id: part.id, notified: n.notified });
}

/** DELETE /api/admin/parts/:pid[?deleteMedia=1] */
export async function deletePart(c) {
  const part = await loadPart(c, c.params.pid);
  const videoId = part.data.videoId;
  await c.fs.commit([W.del(part.path, { exists: true })]);
  if (c.url.searchParams.get('deleteMedia') === '1') {
    for (const f of [part.data.videoFileId, part.data.thumbnailFileId]) if (f) await c.storage.deleteFile(f).catch(() => {});
  }
  await c.fs.deleteWhere('unlocks', [['partId', '==', part.id]], 400);
  await c.fs.deleteWhere('adSessions', [['partId', '==', part.id]], 400);
  await syncVideoParts(c, videoId);
  await c.audit('part.delete', part.id, { videoId });
  return json({ deleted: true });
}

/** PUT /api/admin/videos/:id/parts/order { order: [partId, ...] } - must list every part exactly once. */
export async function reorderParts(c) {
  const videoId = c.params.id;
  await loadVideoForAdmin(c, videoId);
  const body = await readJson(c.request);
  const parts = await c.fs.query({ collection: 'parts', where: [['videoId', '==', videoId]], limit: MAX_PARTS });
  const ids = new Set(parts.map((p) => p.id));
  const order = body.order;
  if (!Array.isArray(order) || order.length !== ids.size || new Set(order).size !== order.length || !order.every((x) => ids.has(x))) {
    throw badRequest('The new order must list every part of this video exactly once', 'invalid_order');
  }
  await c.fs.commit(order.map((pid, i) => W.update(`parts/${pid}`, { number: i + 1 }, { exists: true })));
  await syncVideoParts(c, videoId);
  await c.audit('part.reorder', videoId, { count: order.length });
  return json({ ok: true });
}

// ------------------------------------------------------------------------------------------------ viewer: unlock
const unlockIsValid = (u) => !!u && (u.data.expiresAt === null || u.data.expiresAt === undefined || (u.data.expiresAt instanceof Date && u.data.expiresAt.getTime() > Date.now()));

async function loadViewablePart(c, pid) {
  const part = await loadPart(c, pid);
  const video = await c.loadPublishedVideo(part.data.videoId);
  if (part.data.status !== 'published' && c.user.role !== 'admin') throw notFound('Part not found', 'part_not_found');
  return { part, video };
}

/** POST /api/parts/:pid/unlock/start - issues this part's unlock link. */
export async function startUnlock(c) {
  const { part } = await loadViewablePart(c, c.params.pid);
  const settings = await c.settings();
  if (!part.data.locked) throw badRequest('This part is not locked', 'unlock_not_required');
  const existing = await c.fs.get(`unlocks/${c.uid}_${part.id}`);
  if (unlockIsValid(existing)) return json({ alreadyUnlocked: true });
  const link = part.data.unlockUrl || settings.gate.defaultUnlockUrl;
  if (!link) throw new HttpError(503, 'This part has no unlock link yet. Please tell the site admin.', 'unlock_url_missing');

  const lastStart = c.user.lastAdStartAt instanceof Date ? c.user.lastAdStartAt.getTime() : 0;
  if (Date.now() - lastStart < 2000) throw tooMany();
  const minAway = part.data.minAwaySeconds || settings.gate.minAwaySeconds;
  const verification = part.data.verification === 'postback' ? 'postback' : 'sponsor_opened';
  const sid = uuid();
  const expiresAt = new Date(Date.now() + settings.gate.sessionTtlMinutes * 60_000);
  await c.fs.commit([
    W.set(
      `adSessions/${sid}`,
      { uid: c.uid, videoId: part.data.videoId, partId: part.id, status: 'opened', verification, minAwaySeconds: minAway, expiresAt },
      { exists: false, transforms: [{ field: 'openedAt', serverTime: true }] },
    ),
    W.update(`users/${c.uid}`, {}, { exists: true, transforms: [{ field: 'lastAdStartAt', serverTime: true }] }),
  ]);
  return json({ sessionId: sid, unlockUrl: link.split('{sid}').join(sid), minAwaySeconds: minAway, verification, expiresAt: expiresAt.toISOString() });
}

/** POST /api/parts/unlock/complete { sessionId } - unlocks exactly the part the session was issued for. */
export async function completeUnlock(c) {
  const body = await readJson(c.request);
  const sid = String(body.sessionId || '');
  if (!/^[0-9a-f-]{36}$/.test(sid)) throw badRequest('Invalid session', 'invalid_session');
  const doc = await c.fs.get(`adSessions/${sid}`);
  if (!doc || doc.data.uid !== c.uid || !doc.data.partId) throw notFound('Unlock session not found', 'invalid_session');
  const s = doc.data;
  const settings = await c.settings();
  const now = Date.now();
  const unlockPath = `unlocks/${c.uid}_${s.partId}`;

  if (s.status === 'completed') {
    const u = await c.fs.get(unlockPath);
    return json({ unlocked: true, partId: s.partId, videoId: s.videoId, expiresAt: u?.data.expiresAt instanceof Date ? u.data.expiresAt.toISOString() : null });
  }
  if (!(s.expiresAt instanceof Date) || s.expiresAt.getTime() < now) throw new HttpError(410, 'This unlock step expired. Please start again.', 'session_expired');
  const opened = s.openedAt instanceof Date ? s.openedAt.getTime() : now;
  const waitMs = s.minAwaySeconds * 1000 - (now - opened);
  if (waitMs > 0) throw new HttpError(409, 'Please give the sponsor page a little more time.', 'too_early', { retryAfterSeconds: Math.ceil(waitMs / 1000) });
  if (s.verification === 'postback' && s.status !== 'confirmed') throw new HttpError(409, 'Waiting for confirmation from the ad provider. Try again in a moment.', 'not_confirmed');
  const part = await c.fs.get(`parts/${s.partId}`);
  if (!part) throw notFound('This part no longer exists', 'part_not_found');

  const expiresAt = settings.gate.unlockHours > 0 ? new Date(now + settings.gate.unlockHours * 3600_000) : null;
  try {
    await c.fs.commit([
      // the updateTime precondition lets exactly one request win when the button is pressed repeatedly
      W.update(`adSessions/${sid}`, { status: 'completed' }, { updateTime: doc.updateTime, transforms: [{ field: 'completedAt', serverTime: true }] }),
      W.set(unlockPath, { uid: c.uid, videoId: s.videoId, partId: s.partId, sessionId: sid, verification: s.verification === 'postback' ? 'postback' : 'timer', expiresAt }, { transforms: [{ field: 'unlockedAt', serverTime: true }] }),
    ]);
  } catch (e) {
    if (!(e instanceof FirestoreError && e.isPrecondition)) throw e; // another request already completed it: same result
  }
  return json({ unlocked: true, partId: s.partId, videoId: s.videoId, expiresAt: expiresAt ? expiresAt.toISOString() : null });
}

// ------------------------------------------------------------------------------------------------ viewer: watch / download
/**
 * POST /api/parts/:pid/access { mode: 'watch' | 'download' }
 * Returns the URL only when the part is unlocked for this user (or does not need unlocking).
 * kind "imagekit": play it in the page. kind "external": the admin gave a link to another site, open it in a new tab.
 */
export async function accessPart(c) {
  const body = await readJson(c.request);
  const mode = oneOf(body.mode, ['watch', 'download'], { field: 'mode' });
  const { part, video } = await loadViewablePart(c, c.params.pid);
  const p = part.data;
  const videoId = part.data.videoId;
  if (p.locked) {
    const u = await c.fs.get(`unlocks/${c.uid}_${part.id}`);
    if (!unlockIsValid(u)) throw new HttpError(403, 'Unlock this part first', 'locked');
  }
  if (!p.videoUrl && !p.externalUrl) throw notFound('This part has no media yet', 'no_media');

  let url;
  let kind;
  let expiresAt = null;
  if (mode === 'download' && p.downloadUrl) {
    url = p.downloadUrl;
    kind = 'external';
  } else if (p.videoUrl) {
    const r = await c.storage.playbackUrl(p, PLAYBACK_TTL_S, { attachment: mode === 'download' });
    url = r.url;
    expiresAt = r.expiresAt.toISOString();
    kind = 'imagekit';
  } else {
    url = p.externalUrl;
    kind = 'external';
  }

  let counted = false;
  if (mode === 'watch') {
    const viewDoc = await c.fs.get(`views/${c.uid}_${videoId}`);
    const last = viewDoc?.data.lastViewAt instanceof Date ? viewDoc.data.lastViewAt.getTime() : 0;
    if (Date.now() - last >= VIEW_WINDOW_MS) {
      try {
        await c.fs.commit([
          W.set(`views/${c.uid}_${videoId}`, { uid: c.uid, videoId }, { ...(viewDoc ? { updateTime: viewDoc.updateTime } : { exists: false }), transforms: [{ field: 'lastViewAt', serverTime: true }] }),
          W.update(`videos/${videoId}`, {}, { exists: true, transforms: [{ field: 'views', increment: 1 }] }),
          statsWrite({ views: 1 }),
        ]);
        counted = true;
      } catch (e) {
        if (!(e instanceof FirestoreError && e.isPrecondition)) throw e;
      }
    }
    await c.fs.commit([
      W.set(`history/${c.uid}_${videoId}`, { uid: c.uid, videoId, partId: part.id, partNumber: video.data.partsSummary?.find((x) => x.id === part.id)?.number || p.number }, { transforms: [{ field: 'updatedAt', serverTime: true }] }),
    ]);
  } else {
    const dlDoc = await c.fs.get(`views/dl_${c.uid}_${part.id}`);
    const last = dlDoc?.data.lastViewAt instanceof Date ? dlDoc.data.lastViewAt.getTime() : 0;
    if (Date.now() - last >= VIEW_WINDOW_MS) {
      try {
        await c.fs.commit([
          W.set(`views/dl_${c.uid}_${part.id}`, { uid: c.uid, videoId, partId: part.id }, { ...(dlDoc ? { updateTime: dlDoc.updateTime } : { exists: false }), transforms: [{ field: 'lastViewAt', serverTime: true }] }),
          W.update(`videos/${videoId}`, {}, { exists: true, transforms: [{ field: 'downloads', increment: 1 }] }),
        ]);
        counted = true;
      } catch (e) {
        if (!(e instanceof FirestoreError && e.isPrecondition)) throw e;
      }
    }
  }
  return json({ url, kind, mode, expiresAt, counted });
}

/** GET /api/videos/:id/unlocks - which parts of this video the signed-in user has unlocked. */
export async function myUnlocks(c) {
  await c.loadPublishedVideo(c.params.id);
  const docs = await c.fs.query({ collection: 'unlocks', where: [['uid', '==', c.uid], ['videoId', '==', c.params.id]], limit: MAX_PARTS });
  const unlocked = {};
  for (const d of docs) if (unlockIsValid(d)) unlocked[d.data.partId] = d.data.expiresAt instanceof Date ? d.data.expiresAt.toISOString() : null;
  return json({ unlocked });
}
