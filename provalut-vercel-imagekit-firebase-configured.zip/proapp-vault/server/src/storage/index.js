// Storage Adapter factory.
//
// Contract every provider must implement (all methods async unless noted):
//   folderFor(kind)                    (sync) kind: video | thumbnail | avatar
//   urlFor(filePath)                   (sync) public URL for a stored path
//   ownsUrl(url)                       (sync)
//   uploadAuth()                       -> { token, expire, signature, publicKey, uploadUrl }   (browser-side upload)
//   uploadBytes({ bytes, fileName, kind, contentType, isPrivate })  -> file   (server-side upload)
//   getFile(fileId)                    -> file | null
//   deleteFile(fileId)
//   listFiles({ kind, limit, skip })   -> [file]
//   playbackUrl(video, ttlSeconds)     -> { url, expiresAt }
//   file = { fileId, name, filePath, size, mime, fileType, isPrivate, createdAt }
//
// To change provider later, add a class with the same methods, register it below and set STORAGE_PROVIDER.
// Firestore stores the provider's file id and URL on each video, so only this folder needs to change.
import { ImageKitStorage } from './imagekit.js';

const PROVIDERS = {
  imagekit: (env) => new ImageKitStorage(env),
};

export function createStorage(env) {
  const name = (env.STORAGE_PROVIDER || 'imagekit').toLowerCase();
  const factory = PROVIDERS[name];
  if (!factory) throw new Error(`Unknown STORAGE_PROVIDER "${name}". Available: ${Object.keys(PROVIDERS).join(', ')}`);
  return factory(env);
}

// ---------- provider-independent media rules ----------
export const VIDEO_TYPES = { 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov' };
export const IMAGE_TYPES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
export const MAX_THUMB_BYTES = 5 * 1024 * 1024;
export const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
// ImageKit's free plan accepts videos up to 100 MB (paid plans more); raise MAX_VIDEO_BYTES to match your plan.
export const DEFAULT_MAX_VIDEO_BYTES = 100 * 1024 * 1024;

export function maxVideoBytes(env) {
  const n = Number(env.MAX_VIDEO_BYTES);
  return Number.isFinite(n) && n > 0 ? n : DEFAULT_MAX_VIDEO_BYTES;
}

/** Check the first bytes of an upload against its declared type. */
export function sniffMatches(contentType, b) {
  const at = (i, ...bytes) => bytes.every((v, k) => b[i + k] === v);
  if (contentType === 'image/jpeg') return at(0, 0xff, 0xd8, 0xff);
  if (contentType === 'image/png') return at(0, 0x89, 0x50, 0x4e, 0x47);
  if (contentType === 'image/webp') return at(0, 0x52, 0x49, 0x46, 0x46) && at(8, 0x57, 0x45, 0x42, 0x50);
  if (contentType === 'video/webm') return at(0, 0x1a, 0x45, 0xdf, 0xa3);
  if (contentType === 'video/mp4' || contentType === 'video/quicktime') return at(4, 0x66, 0x74, 0x79, 0x70); // "ftyp"
  return false;
}
