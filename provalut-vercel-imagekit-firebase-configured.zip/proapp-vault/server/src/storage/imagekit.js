// ImageKit implementation of the Storage Adapter contract (see storage/index.js).
//
// Where each secret is used (all server-side, read from environment variables, never sent to the browser):
//   IMAGEKIT_PRIVATE_KEY  - signs upload tokens, signs private playback URLs, authenticates Media API calls
//   IMAGEKIT_PUBLIC_KEY   - returned to the admin's browser together with a signed token (it is public by design)
//   IMAGEKIT_URL_ENDPOINT - the base of every media URL, e.g. https://ik.imagekit.io/your_imagekit_id
//
// ImageKit references used here:
//   * client-side upload: POST <uploadUrl> multipart with file, fileName, publicKey, token, expire, signature
//       signature = HMAC-SHA1(privateKey, token + expire) as lowercase hex; expire is a unix time less than 1 hour ahead
//   * private files: uploaded with isPrivateFile=true, then reachable only through a signed URL:
//       ?ik-t=<unix expiry>&ik-s=HMAC-SHA1(privateKey, <path relative to the URL endpoint, no leading slash> + <expiry>) as hex
//   * Media API (HTTP Basic auth, private key as user name, empty password): files list / details / delete
import { utf8 } from '../lib/ids.js';

const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

export async function hmacSha1Hex(secret, message) {
  const key = await crypto.subtle.importKey('raw', utf8(secret), { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', key, utf8(message)));
}

export class StorageError extends Error {
  constructor(status, message) {
    super(message);
    this.name = 'StorageError';
    this.status = status;
  }
}

const FILE_ID = /^[A-Za-z0-9_-]{8,64}$/;
export const isFileId = (v) => typeof v === 'string' && FILE_ID.test(v);

const UPLOAD_AUTH_TTL_S = 30 * 60; // ImageKit requires less than one hour

export class ImageKitStorage {
  constructor(env) {
    const need = ['IMAGEKIT_PUBLIC_KEY', 'IMAGEKIT_PRIVATE_KEY', 'IMAGEKIT_URL_ENDPOINT'].filter((k) => !String(env[k] || '').trim());
    if (need.length) throw new Error(`Missing environment variable(s): ${need.join(', ')}`);
    this.name = 'imagekit';
    this.publicKey = env.IMAGEKIT_PUBLIC_KEY.trim();
    this.privateKey = env.IMAGEKIT_PRIVATE_KEY.trim();
    const endpoint = new URL(env.IMAGEKIT_URL_ENDPOINT.trim());
    const local = ['127.0.0.1', 'localhost'].includes(endpoint.hostname);
    if (endpoint.protocol !== 'https:' && !local) throw new Error('IMAGEKIT_URL_ENDPOINT must start with https://');
    this.endpoint = endpoint.toString().replace(/\/+$/, '');
    const folder = String(env.IMAGEKIT_FOLDER || 'provalut').replace(/^\/+|\/+$/g, '');
    if (!/^[A-Za-z0-9_-]+(\/[A-Za-z0-9_-]+)*$/.test(folder)) throw new Error('IMAGEKIT_FOLDER may only contain letters, digits, "-", "_" and "/"');
    this.folder = `/${folder}`;
    this.privateVideos = String(env.IMAGEKIT_PRIVATE_VIDEOS ?? 'true').trim().toLowerCase() !== 'false';
    this.apiBase = (env.IMAGEKIT_API_BASE || 'https://api.imagekit.io/v1').replace(/\/$/, '');
    this.uploadUrl = env.IMAGEKIT_UPLOAD_URL || 'https://upload.imagekit.io/api/v1/files/upload';
  }

  folderFor(kind) {
    const sub = { video: 'videos', thumbnail: 'thumbs', avatar: 'avatars' }[kind];
    if (!sub) throw new Error(`Unknown media kind "${kind}"`);
    return `${this.folder}/${sub}`;
  }

  /** The URL we store for a file: built from our own endpoint + the file's path, never copied from client input. */
  urlFor(filePath) {
    return this.endpoint + filePath.split('/').map((s) => (s ? encodeURIComponent(s) : s)).join('/');
  }

  ownsUrl(url) {
    return typeof url === 'string' && url.startsWith(`${this.endpoint}/`);
  }

  // ---------------------------------------------------------------- upload authentication (browser uploads directly to ImageKit)
  async uploadAuth() {
    const token = crypto.randomUUID();
    const expire = Math.floor(Date.now() / 1000) + UPLOAD_AUTH_TTL_S;
    const signature = await hmacSha1Hex(this.privateKey, `${token}${expire}`);
    return { token, expire, signature, publicKey: this.publicKey, uploadUrl: this.uploadUrl };
  }

  // ---------------------------------------------------------------- signed URLs for private files
  // `attachment` adds ImageKit's ik-attachment=true parameter so the browser saves the file instead of playing it.
  // The signature covers the path plus that query string, which is how I understand ImageKit signs URLs with query
  // parameters; this has NOT been confirmed against the live service (see README).
  async signUrl(url, ttlSeconds, { attachment = false } = {}) {
    if (!this.ownsUrl(url)) throw new Error('Refusing to sign a URL outside IMAGEKIT_URL_ENDPOINT');
    const query = attachment ? '?ik-attachment=true' : '';
    const relative = url.slice(this.endpoint.length + 1) + query; // path after the endpoint, no leading slash
    const expiry = Math.floor(Date.now() / 1000) + ttlSeconds;
    const signature = await hmacSha1Hex(this.privateKey, `${relative}${expiry}`);
    return { url: `${url}${query}${query ? '&' : '?'}ik-t=${expiry}&ik-s=${signature}`, expiresAt: new Date(expiry * 1000) };
  }

  /** URL a signed-in viewer may use for a part (or video record). Private files get a short-lived signed URL; public ones are returned as stored. */
  async playbackUrl(video, ttlSeconds, { attachment = false } = {}) {
    if (!this.ownsUrl(video.videoUrl)) throw new StorageError(500, 'Stored video URL does not belong to this ImageKit account');
    if (video.videoPrivate) return this.signUrl(video.videoUrl, ttlSeconds, { attachment });
    const url = attachment ? `${video.videoUrl}?ik-attachment=true` : video.videoUrl;
    return { url, expiresAt: new Date(Date.now() + ttlSeconds * 1000) };
  }

  // ---------------------------------------------------------------- Media API
  async #api(path, init = {}) {
    let res;
    try {
      res = await fetch(`${this.apiBase}${path}`, {
        ...init,
        headers: { Authorization: `Basic ${btoa(`${this.privateKey}:`)}`, ...(init.headers || {}) },
      });
    } catch {
      throw new StorageError(502, 'Could not reach ImageKit');
    }
    if (res.status === 404) return null;
    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      /* not JSON */
    }
    if (!res.ok) throw new StorageError(res.status === 401 || res.status === 403 ? 502 : res.status, `ImageKit: ${data?.message || `request failed (${res.status})`}`);
    return data ?? {};
  }

  static normalize(f) {
    return {
      fileId: f.fileId,
      name: f.name,
      filePath: f.filePath,
      size: Number(f.size) || 0,
      mime: f.mime || '',
      fileType: f.fileType || '',
      isPrivate: f.isPrivateFile === true,
      createdAt: f.createdAt || null,
    };
  }

  async getFile(fileId) {
    if (!isFileId(fileId)) return null;
    const f = await this.#api(`/files/${fileId}/details`);
    return f && f.fileId ? ImageKitStorage.normalize(f) : null;
  }

  async deleteFile(fileId) {
    if (!isFileId(fileId)) return;
    await this.#api(`/files/${fileId}`, { method: 'DELETE' }); // 404 (already gone) is fine
  }

  async listFiles({ kind, limit = 50, skip = 0 }) {
    const q = new URLSearchParams({ path: this.folderFor(kind), type: 'file', limit: String(limit), skip: String(skip), sort: 'DESC_CREATED' });
    const rows = await this.#api(`/files?${q}`);
    return (Array.isArray(rows) ? rows : []).map(ImageKitStorage.normalize);
  }

  /** Server-side upload (used for small files that must be validated first, such as avatars). */
  async uploadBytes({ bytes, fileName, kind, contentType, isPrivate = false }) {
    const form = new FormData();
    form.append('file', new Blob([bytes], { type: contentType }), fileName);
    form.append('fileName', fileName);
    form.append('folder', this.folderFor(kind));
    form.append('useUniqueFileName', 'true');
    form.append('isPrivateFile', String(isPrivate));
    let res;
    try {
      res = await fetch(this.uploadUrl, { method: 'POST', headers: { Authorization: `Basic ${btoa(`${this.privateKey}:`)}` }, body: form });
    } catch {
      throw new StorageError(502, 'Could not reach ImageKit');
    }
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.fileId) throw new StorageError(502, `ImageKit: ${data?.message || `upload failed (${res.status})`}`);
    return ImageKitStorage.normalize(data);
  }
}
