// Vercel build step: write public/js/config.js from Environment Variables.
//
//   FIREBASE_API_KEY       Firebase web API key (public)
//   FIREBASE_PROJECT_ID    Firebase project id   (also read by the API)
//   IMAGEKIT_URL_ENDPOINT  ImageKit URL endpoint (also read by the API)
//
// FIREBASE_API_KEY is the switch: if it is not set, config.js is left exactly as committed (a hand-edited file keeps
// working; the other two variables are also needed by the API, so they are normally set anyway). If it IS set but
// another value is missing, the build fails with a clear message instead of publishing a half-configured site.
// Only these three PUBLIC values are ever read: no secret can end up in the generated file.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const target = path.join(root, 'public', 'js', 'config.js');

export function buildConfig(env) {
  const apiKey = (env.FIREBASE_API_KEY || '').trim();
  const projectId = (env.FIREBASE_PROJECT_ID || '').trim();
  const urlEndpoint = (env.IMAGEKIT_URL_ENDPOINT || '').trim().replace(/\/+$/, '');
  if (!apiKey) return null;
  const missing = [['FIREBASE_API_KEY', apiKey], ['FIREBASE_PROJECT_ID', projectId], ['IMAGEKIT_URL_ENDPOINT', urlEndpoint]].filter(([, v]) => !v).map(([k]) => k);
  if (missing.length) throw new Error(`Missing Environment Variable(s): ${missing.join(', ')}. Set all three, or remove FIREBASE_API_KEY to keep public/js/config.js as it is.`);
  if (!/^[A-Za-z0-9_-]{20,80}$/.test(apiKey)) throw new Error('FIREBASE_API_KEY does not look like a Firebase web API key (copy "Web API Key" from Firebase project settings).');
  if (!/^[a-z0-9][a-z0-9-]{3,38}[a-z0-9]$/.test(projectId)) throw new Error('FIREBASE_PROJECT_ID does not look like a Firebase project id.');
  let url;
  try {
    url = new URL(urlEndpoint);
  } catch {
    throw new Error('IMAGEKIT_URL_ENDPOINT must be a full URL such as https://ik.imagekit.io/your_imagekit_id');
  }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) throw new Error('IMAGEKIT_URL_ENDPOINT must be a plain https:// URL.');
  const cfg = {
    firebase: { apiKey, projectId },
    apiBase: '',
    imagekit: { urlEndpoint },
    overrides: { authBase: '', tokenBase: '', firestoreBase: '' },
  };
  return `// Generated at build time by scripts/generate-config.mjs from Vercel Environment Variables. PUBLIC values only.\nwindow.PROVALUT_CONFIG = ${JSON.stringify(cfg, null, 2)};\n`;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const out = buildConfig(process.env);
    if (out === null) console.log('generate-config: FIREBASE_API_KEY not set - keeping public/js/config.js as committed.');
    else {
      fs.writeFileSync(target, out);
      console.log('generate-config: wrote public/js/config.js from environment variables.');
    }
  } catch (e) {
    console.error(`generate-config: ${e.message}`);
    process.exit(1);
  }
}
