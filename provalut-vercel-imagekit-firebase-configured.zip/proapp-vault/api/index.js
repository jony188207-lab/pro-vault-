// Vercel Function entry point. One function serves every /api/* route (vercel.json rewrites /api/* to this file);
// the routing itself lives in server/src/index.js.
import { handle } from '../server/src/index.js';

export default {
  async fetch(request) {
    return handle(request, process.env, {});
  },
};
