// Shared UI components.
import { h, icon, compact, duration } from './lib/dom.js';
import { apiBase } from './lib/api.js';
import { avatarSrc, thumbSrc } from './lib/media.js';
import { state } from './state.js';

/** Wordmark: "PRO" + a red "VALUT" tab, like the reference's two-tone logo. */
export function logoMark() {
  return h('span', { class: 'wordmark', 'aria-hidden': 'true' }, h('span', { class: 'wm-a' }, 'PRO'), h('span', { class: 'wm-b' }, 'VALUT'));
}

/** Small square mark used on empty/error states. */
export function logoGlyph(size = 44) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 32 32');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('aria-hidden', 'true');
  svg.innerHTML = '<rect x="3" y="3" width="26" height="26" rx="6.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M13 10.5v11l9-5.5z" fill="currentColor"/>';
  return svg;
}

/** Round avatar: shows the ImageKit photo when there is one, otherwise (or if it fails to load) the first letter of the name. */
export function avatar(name, photoUrl, attrs = {}, tag = 'div') {
  const el = h(tag, { ...attrs, class: `${attrs.class || ''} avatar`.trim() }, Array.from(name || '?')[0].toUpperCase());
  const src = avatarSrc(photoUrl, 160);
  if (src) el.append(h('img', { src, alt: '', loading: 'lazy', decoding: 'async', onerror: (e) => e.target.remove() }));
  return el;
}

export function thumb(video, { eager = false, width = 640 } = {}) {
  const wrap = h('div', { class: 'thumb' });
  const url = thumbSrc(video.thumbnailUrl, width);
  const letter = Array.from(video.title || '?')[0].toUpperCase();
  wrap.append(h('span', { class: 'thumb-fallback', 'aria-hidden': 'true' }, letter));
  if (url) wrap.append(h('img', { src: url, alt: '', loading: eager ? 'eager' : 'lazy', decoding: 'async', onerror: (e) => e.target.remove() }));
  return wrap;
}

const partsLabel = (n) => `${n} ${n === 1 ? 'Part' : 'Parts'}`;

/** Card used in "Recently Added", search results and saved/history lists. Large thumbnail, parts badge, views chip, title row. */
export function videoCard(video, { extra = null } = {}) {
  const n = video.partsCount || 0;
  return h(
    'a',
    { class: 'vcard', href: `#/v/${video.id}` },
    h('div', { class: 'vcard-media' }, thumb(video), n ? h('span', { class: 'chip chip-parts' }, icon('list', 12), partsLabel(n)) : null, h('span', { class: 'chip chip-views' }, icon('eye', 12), compact(video.views))),
    h('div', { class: 'vcard-row' }, h('span', { class: 'brand-dot', 'aria-hidden': 'true' }, 'PV'), h('h3', { class: 'vcard-title' }, video.title)),
    extra,
  );
}

/** Compact card for the horizontal "Trending Now" strip. */
export function trendCard(video, { top = true } = {}) {
  const n = video.partsCount || 0;
  return h(
    'a',
    { class: 'tcard', href: `#/v/${video.id}` },
    h('div', { class: 'vcard-media' }, thumb(video, { width: 480 }), top ? h('span', { class: 'chip chip-top' }, icon('flame', 12), 'TOP') : null, n ? h('span', { class: 'chip chip-parts' }, icon('list', 12), partsLabel(n)) : null, h('span', { class: 'chip chip-views' }, icon('eye', 12), compact(video.views))),
    h('div', { class: 'vcard-row' }, h('span', { class: 'brand-dot', 'aria-hidden': 'true' }, 'PV'), h('h3', { class: 'vcard-title' }, video.title)),
  );
}

export function skeletonGrid(n = 6) {
  return h('div', { class: 'grid', 'aria-busy': 'true', 'aria-label': 'Loading' }, Array.from({ length: n }, () => h('div', { class: 'vcard skeleton' }, h('div', { class: 'thumb' }), h('div', { class: 'vcard-body' }, h('div', { class: 'sk-line' }), h('div', { class: 'sk-line short' })))));
}

export function emptyState({ title, text, action }) {
  return h('div', { class: 'state' }, h('div', { class: 'state-art', 'aria-hidden': 'true' }, logoGlyph(44)), h('h2', null, title), text ? h('p', null, text) : null, action || null);
}

export function errorState(message, onRetry) {
  return h(
    'div',
    { class: 'state state-error', role: 'alert' },
    h('div', { class: 'state-art', 'aria-hidden': 'true' }, icon('alert', 36)),
    h('h2', null, 'Something went wrong'),
    h('p', null, message),
    onRetry ? h('button', { class: 'btn primary', type: 'button', onclick: onRetry }, 'Try again') : null,
  );
}

const PLACEMENT_LABELS = { home: 'Home, below trending', homeBottom: 'Home, bottom', listCard: 'Below each video card', detailsBelow: 'Video details', partsBottom: 'Parts screen' };

/**
 * One banner placement (home | homeBottom | listCard | detailsBelow | partsBottom). Banners are independent of unlocking:
 * they are only ever shown, never read by any unlock code. The admin's Adsterra code is served by the API in a sandboxed
 * iframe. A placement that is switched off renders nothing for visitors; admins see a dashed placeholder so they can
 * find where it would appear.
 */
export function bannerSlot(placement) {
  const b = state.settings.banners?.[placement];
  const isAdmin = state.user?.role === 'admin';
  if (!b?.enabled || !b.html) {
    if (!isAdmin) return document.createDocumentFragment(); // empty, so a native append() never prints "null"
    return h('aside', { class: 'banner banner-empty', 'aria-label': 'Ad placement (no code configured)' }, h('span', null, `Ad space · ${PLACEMENT_LABELS[placement] || placement} · no code configured (only admins see this)`));
  }
  const frame = h('iframe', {
    class: 'banner-frame',
    title: 'Sponsored banner',
    src: `${apiBase()}/api/ads/banner-frame?p=${encodeURIComponent(placement)}`,
    width: b.width,
    height: b.height,
    loading: 'lazy',
    // The API also sends a CSP `sandbox` header; both layers keep the banner away from the app and the user's session.
    sandbox: 'allow-scripts allow-popups allow-popups-to-escape-sandbox',
    referrerpolicy: 'no-referrer',
    scrolling: 'no',
  });
  const slot = h('div', { class: 'banner-slot' }, frame);
  const wrap = h('aside', { class: `banner banner-${placement}`, 'aria-label': 'Advertisement' }, h('span', { class: 'banner-tag' }, 'Sponsored'), slot);
  slot.style.height = `${b.height}px`; // CSSOM, not a style attribute: the CSP forbids inline styles
  const fit = () => {
    const avail = wrap.clientWidth - 2;
    const scale = avail > 0 && b.width > avail ? avail / b.width : 1;
    frame.style.transform = scale < 1 ? `scale(${scale})` : '';
    frame.style.transformOrigin = 'top left';
    slot.style.height = `${Math.ceil(b.height * scale)}px`;
  };
  new ResizeObserver(fit).observe(wrap);
  return wrap;
}

/** Put a listCard banner after every Nth card (N from the admin settings). Returns an array of nodes. */
export function withListBanners(cards) {
  const every = Math.max(1, state.settings.banners?.listCard?.every || 1);
  const out = [];
  cards.forEach((c, i) => {
    out.push(c);
    if ((i + 1) % every === 0) {
      const b = bannerSlot('listCard');
      if (b.childNodes.length) out.push(b);
    }
  });
  return out;
}
