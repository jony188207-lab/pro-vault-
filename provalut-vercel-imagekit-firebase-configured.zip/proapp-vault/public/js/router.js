// Hash router. Each route lazily imports its view; a view is `export async function render(ctx)`.
const routes = [];
let current = 0;

export function route(pattern, loader, opts = {}) {
  const names = [];
  const src = pattern.replace(/:([a-zA-Z]+)/g, (_, n) => (names.push(n), '([^/]+)'));
  routes.push({ regex: new RegExp(`^${src}/?$`), names, loader, opts });
}

export function parseHash(hash = location.hash) {
  const raw = hash.replace(/^#/, '') || '/';
  const [path, qs = ''] = raw.split('?');
  return { path, query: Object.fromEntries(new URLSearchParams(qs)) };
}

export function navigate(hash, { replace = false } = {}) {
  if (replace) location.replace(hash);
  else location.hash = hash;
}

export function startRouter({ root, onRoute, guard, notFound }) {
  async function run() {
    const id = ++current;
    const { path, query } = parseHash();
    let match = null;
    for (const r of routes) {
      const m = r.regex.exec(path);
      if (m) {
        const params = {};
        r.names.forEach((n, i) => (params[n] = decodeURIComponent(m[i + 1])));
        match = { r, params };
        break;
      }
    }
    const redirect = guard?.(match?.r.opts || {}, path);
    if (redirect) return navigate(redirect, { replace: true });
    onRoute?.(path, match?.r.opts || {});
    root.replaceChildren();
    root.scrollTop = 0;
    window.scrollTo(0, 0);
    if (!match) return notFound(root);
    try {
      const mod = await match.r.loader();
      if (id !== current) return;
      await mod.render({ root, params: match.params, query, isCurrent: () => id === current });
    } catch (e) {
      if (id !== current) return;
      console.error(e);
      notFound(root, e);
    }
  }
  window.addEventListener('hashchange', run);
  return run;
}
