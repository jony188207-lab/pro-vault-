// Shared application state: signed-in profile and public settings.
import { api, ApiError } from './lib/api.js';
import * as fb from './lib/firebase.js';
import { getDoc, query } from './lib/firebase.js';

const emptyBanner = () => ({ enabled: false, html: '', width: 320, height: 100 });

export const DEFAULT_SETTINGS = {
  siteName: 'Provalut',
  tagline: 'Videos in your pocket',
  popularCount: 8,
  homeListLimit: 12,
  allowSignups: true,
  commentsEnabled: true,
  categories: [],
  banners: { home: emptyBanner(), homeBottom: emptyBanner(), listCard: { ...emptyBanner(), every: 1 }, detailsBelow: emptyBanner(), partsBottom: emptyBanner() },
  gate: { minAwaySeconds: 10 },
  notifications: { inApp: true, telegram: true },
  texts: {
    partsTitle: 'Select Quality / Part',
    howToTitle: 'How to Download?',
    howToText: 'যেকোনো পার্ট বাছাই করুন, স্পনসর লিংক খুলে {seconds} সেকেন্ড থাকুন, তারপর এই পেজে ফিরে আসুন।',
    unlockTitle: 'Unlock Your Video',
    unlockSubtitle: 'ভিডিও আনলক করুন',
    unlockStep1: 'স্পনসর পেজে {seconds} সেকেন্ড থাকুন।',
    unlockStep2: 'তারপর এই পেজে ফিরে এসে আনলক বাটনে চাপুন।',
    unlockWarning: '{seconds} সেকেন্ডের আগে ফিরে এলে আনলক হবে না, আবার চেষ্টা করতে হবে।',
    openLinkButton: 'স্পনসর লিংক খুলুন',
    verifyButton: 'আমি ফিরে এসেছি — আনলক করুন',
    waitingText: 'স্পনসর পেজ দেখে এই পেজে ফিরে আসুন',
    unlockedText: 'আনলক হয়েছে! এখন দেখতে বা ডাউনলোড করতে পারেন।',
    watchButton: 'Watch',
    downloadButton: 'Download',
  },
};

export const state = {
  user: null, // profile from the API (role/status come from the server, never from the browser)
  settings: DEFAULT_SETTINGS,
  unread: 0, // notifications newer than the user's last visit to the inbox
  ready: false,
};

const subs = new Set();
export const subscribe = (fn) => (subs.add(fn), () => subs.delete(fn));
const notify = () => subs.forEach((fn) => fn(state));

function merge(base, patch) {
  const out = { ...base };
  for (const [k, v] of Object.entries(patch || {})) out[k] = v && typeof v === 'object' && !Array.isArray(v) && !(v instanceof Date) && typeof base[k] === 'object' ? merge(base[k], v) : v;
  return out;
}

export async function loadSettings() {
  try {
    const doc = await getDoc('settings/public');
    state.settings = merge(DEFAULT_SETTINGS, doc || {});
  } catch {
    state.settings = state.settings || DEFAULT_SETTINGS;
  }
  document.title = state.settings.siteName;
  notify();
  return state.settings;
}

/** Create/refresh the server-side profile after Firebase sign-in. Signs out again if the server refuses. */
export async function establishSession() {
  try {
    const { user } = await api.post('/api/session', {});
    state.user = user;
    notify();
    refreshUnread();
    return user;
  } catch (e) {
    if (e instanceof ApiError && e.status === 0) {
      notify();
      throw e; // network problem: keep the Firebase session, tell the user
    }
    state.user = null;
    await fb.signOut();
    notify();
    throw e;
  }
}

/** Count notifications newer than the user's last inbox visit. Failures are silent: the badge is only a convenience. */
export async function refreshUnread() {
  if (!state.user) {
    state.unread = 0;
    return notify();
  }
  try {
    const items = await query({ collection: 'notifications', orderBy: [['createdAt', 'desc']], limit: 30 });
    const seen = state.user.notificationsSeenAt ? new Date(state.user.notificationsSeenAt).getTime() : 0;
    state.unread = items.filter((n) => n.createdAt instanceof Date && n.createdAt.getTime() > seen).length;
  } catch {
    state.unread = 0;
  }
  notify();
}

export function markSeen() {
  if (!state.user) return;
  state.user.notificationsSeenAt = new Date().toISOString();
  state.unread = 0;
  notify();
  api.post('/api/me/notifications/seen', {}).catch(() => {});
}

export async function logout() {
  // Clear the profile first: signOut() fires the auth-change listener, which must not see a signed-in user (it would call logout() again).
  state.user = null;
  state.unread = 0;
  await fb.signOut();
  notify();
}

export function setUser(user) {
  state.user = user;
  notify();
}

export const isAdmin = () => state.user?.role === 'admin';

// where to go after login
const RETURN = 'provalut.returnTo';
export const rememberReturn = (hash) => {
  try {
    sessionStorage.setItem(RETURN, hash);
  } catch {
    /* ignore */
  }
};
export const takeReturn = () => {
  try {
    const v = sessionStorage.getItem(RETURN);
    sessionStorage.removeItem(RETURN);
    return v && v.startsWith('#/') && !v.startsWith('#/login') ? v : '#/';
  } catch {
    return '#/';
  }
};
