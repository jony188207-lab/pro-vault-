import { h, icon, toast, confirmDialog, timeAgo } from '../lib/dom.js';
import { query, getDocs } from '../lib/firebase.js';
import { api } from '../lib/api.js';
import { state } from '../state.js';
import { emptyState, errorState, skeletonGrid, videoCard } from '../components.js';

export async function render({ root, isCurrent }) {
  const clearBtn = h('button', { class: 'btn small', type: 'button' }, icon('trash', 14), 'Clear');
  const page = h('div', { class: 'page' }, h('div', { class: 'block-head' }, h('h1', { class: 'sec-title big' }, icon('history', 20), 'Recently Watched'), clearBtn));
  root.append(page);
  const host = h('section', { class: 'block' }, skeletonGrid(2));
  page.append(host);
  const load = async () => {
    try {
      const rows = await query({ collection: 'history', where: [['uid', '==', state.user.uid]], orderBy: [['updatedAt', 'desc']], limit: 40 });
      const docs = await getDocs(rows.map((r) => `videos/${r.videoId}`));
      if (!isCurrent()) return;
      const items = rows.map((r, i) => ({ r, v: docs[i] })).filter((x) => x.v && x.v.status === 'published');
      host.replaceChildren();
      clearBtn.hidden = !items.length;
      if (!items.length) return host.append(emptyState({ title: 'No watch history', text: 'Videos you watch will be listed here.', action: h('a', { class: 'btn primary', href: '#/' }, 'Browse videos') }));
      host.append(h('div', { class: 'vlist' }, items.map(({ r, v }) => videoCard(v, { extra: h('p', { class: 'muted small-text hist-line' }, `Part ${r.partNumber || 1} · ${timeAgo(r.updatedAt)}`) }))));
    } catch (e) {
      host.replaceChildren(errorState(e.message, load));
    }
  };
  clearBtn.addEventListener('click', async () => {
    if (!(await confirmDialog({ title: 'Clear watch history?', message: 'This removes the list of videos you watched. It does not change your unlocked parts.', confirmLabel: 'Clear', danger: true }))) return;
    try {
      await api.del('/api/me/history');
      toast('History cleared', 'success');
      host.replaceChildren(skeletonGrid(1));
      await load();
    } catch (e) {
      toast(e.message, 'error');
    }
  });
  await load();
}
