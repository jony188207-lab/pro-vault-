import { h, clear, icon } from '../lib/dom.js';
import { query } from '../lib/firebase.js';
import { state } from '../state.js';
import { queryToken, queryWords } from '../lib/search.js';
import { bannerSlot, emptyState, errorState, skeletonGrid, trendCard, videoCard, withListBanners, thumb } from '../components.js';
import { navigate } from '../router.js';
import { dialog } from '../lib/dom.js';

const PUBLISHED = ['status', '==', 'published'];

export async function render({ root, query: qs, isCurrent }) {
  const q = (qs.q || '').trim();
  const category = (qs.cat || '').trim();
  const s = state.settings;
  const page = h('div', { class: 'page home' });
  root.append(page);

  // search + categories (as in the reference header area)
  const input = h('input', { class: 'search-input', type: 'search', name: 'q', placeholder: 'Search Movies, Series, Videos...', 'aria-label': 'Search videos', autocomplete: 'off', enterkeyhint: 'search', maxlength: 80, value: q });
  const form = h('form', { class: 'search', role: 'search' }, icon('search', 18), input);
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const v = input.value.trim();
    navigate(v ? `#/?q=${encodeURIComponent(v)}` : '#/');
  });
  const catLabel = category || 'All Categories (সকল ভিডিও)';
  const catBtn = h('button', { class: 'cat-btn', type: 'button', 'aria-haspopup': 'dialog' }, icon('flame', 16), catLabel);
  catBtn.addEventListener('click', () => openCategories(category));
  page.append(form, catBtn);

  if (q) return renderSearch(page, q, isCurrent);
  if (category) return renderCategory(page, category, isCurrent);

  const stateUser = state.user;
  const continueHost = h('section', { class: 'block' });
  const trendHost = h('section', { class: 'block', 'aria-labelledby': 'tr-h' });
  const listHost = h('section', { class: 'block', 'aria-labelledby': 'new-h' }, h('h2', { class: 'sec-title', id: 'new-h' }, icon('film', 18), 'Recently Added'));
  page.append(continueHost, trendHost, bannerSlot('home'), listHost);

  if (stateUser) loadContinue(continueHost, isCurrent);

  trendHost.append(h('h2', { class: 'sec-title', id: 'tr-h' }, icon('bolt', 18), 'Trending Now'), h('div', { class: 'strip skeleton-strip' }, [1, 2, 3].map(() => h('div', { class: 'tcard skeleton' }, h('div', { class: 'vcard-media' }, h('div', { class: 'thumb' }))))));
  query({ collection: 'videos', where: [PUBLISHED], orderBy: [['views', 'desc']], limit: s.popularCount })
    .then((vids) => {
      if (!isCurrent()) return;
      trendHost.querySelector('.skeleton-strip')?.remove();
      const shown = vids.filter((v) => (v.views || 0) > 0);
      if (shown.length) trendHost.append(h('div', { class: 'strip' }, shown.map((v) => trendCard(v))));
      else trendHost.remove();
    })
    .catch(() => trendHost.remove());

  await loadList(listHost, s.homeListLimit, isCurrent);
  page.append(bannerSlot('homeBottom'));
}

/** "Continue Watching": the last video the user watched, with the part they were on. */
async function loadContinue(host, isCurrent) {
  try {
    const rows = await query({ collection: 'history', where: [['uid', '==', state.user.uid]], orderBy: [['updatedAt', 'desc']], limit: 1 });
    if (!rows.length || !isCurrent()) return;
    const [{ getDoc }] = await Promise.all([import('../lib/firebase.js')]);
    const v = await getDoc(`videos/${rows[0].videoId}`);
    if (!v || v.status !== 'published' || !isCurrent()) return;
    host.append(
      h('h2', { class: 'sec-title warm' }, icon('flame', 18), 'Continue Watching (দ্রুত পরবর্তী পার্ট দেখুন)'),
      h('a', { class: 'continue', href: `#/v/${v.id}` }, thumb(v, { width: 240 }), h('div', { class: 'continue-body' }, h('strong', null, v.title), h('span', { class: 'muted' }, `Last watched: Part ${rows[0].partNumber || 1} of ${v.partsCount || 1}`), h('span', { class: 'btn small primary' }, icon('chevron', 14), 'Open Parts'))),
    );
  } catch {
    /* the strip is a convenience; ignore failures */
  }
}

function openCategories(active) {
  const cats = state.settings.categories || [];
  const list = h('div', { class: 'cat-list' },
    h('button', { class: `cat-item ${!active ? 'on' : ''}`, type: 'button', onclick: () => pick('') }, 'All Categories (সকল ভিডিও)'),
    cats.map((c) => h('button', { class: `cat-item ${c === active ? 'on' : ''}`, type: 'button', onclick: () => pick(c) }, c)),
    cats.length ? null : h('p', { class: 'muted' }, 'No categories have been added yet.'),
  );
  const d = dialog({ title: 'Categories', body: list });
  function pick(c) {
    d.close();
    navigate(c ? `#/?cat=${encodeURIComponent(c)}` : '#/');
  }
}

async function loadList(host, pageSize, isCurrent, extraWhere = []) {
  let offset = 0;
  const grid = h('div', { class: 'vlist' });
  const footer = h('div', { class: 'more' });
  const first = skeletonGrid(Math.min(pageSize, 3));
  host.append(first);

  async function loadPage() {
    const vids = await query({ collection: 'videos', where: [PUBLISHED, ...extraWhere], orderBy: [['createdAt', 'desc']], limit: pageSize + 1, offset });
    if (!isCurrent()) return;
    const more = vids.length > pageSize;
    grid.append(...withListBanners(vids.slice(0, pageSize).map((v) => videoCard(v))));
    offset += pageSize;
    clear(footer);
    if (more) {
      const btn = h('button', { class: 'btn', type: 'button' }, 'Show more videos');
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        btn.textContent = 'Loading…';
        try {
          await loadPage();
        } catch (e) {
          btn.disabled = false;
          btn.textContent = 'Show more videos';
          footer.append(h('p', { class: 'form-error', role: 'alert' }, e.message));
        }
      });
      footer.append(btn);
    }
    return vids.length;
  }

  try {
    const n = await loadPage();
    first.remove();
    if (!isCurrent()) return;
    if (!n) {
      host.append(emptyState({ title: 'No videos yet', text: 'New videos will appear here as soon as they are published.' }));
      return;
    }
    host.append(grid, footer);
  } catch (e) {
    first.remove();
    host.append(errorState(e.message, () => {
      host.querySelector('.state')?.remove();
      loadList(host, pageSize, isCurrent, extraWhere);
    }));
  }
}

async function renderCategory(page, category, isCurrent) {
  const host = h('section', { class: 'block' }, h('h2', { class: 'sec-title' }, icon('film', 18), category));
  page.append(host);
  await loadList(host, state.settings.homeListLimit, isCurrent, [['category', '==', category]]);
  page.append(bannerSlot('homeBottom'));
}

async function renderSearch(page, q, isCurrent) {
  const words = queryWords(q);
  const token = queryToken(q);
  page.append(h('div', { class: 'block-head search-head' }, h('h1', { class: 'sec-title' }, `Results for “${q}”`), h('a', { class: 'btn small', href: '#/' }, 'Clear search')));
  const host = h('section', { class: 'block' });
  page.append(host);
  if (!token) {
    host.append(emptyState({ title: 'Type a word to search', text: 'Search matches video titles and tags.' }));
    return;
  }
  host.append(skeletonGrid(2));
  const run = async () => {
    try {
      const found = await query({ collection: 'videos', where: [PUBLISHED, ['searchTokens', 'array-contains', token]], orderBy: [['createdAt', 'desc']], limit: 40 });
      if (!isCurrent()) return;
      const results = found.filter((v) => words.every((w) => (v.searchTokens || []).includes(Array.from(w).slice(0, 20).join(''))));
      clear(host);
      if (!results.length) {
        host.append(emptyState({ title: 'No matches', text: `Nothing matched “${q}”. Check the spelling or try a shorter word.`, action: h('a', { class: 'btn primary', href: '#/' }, 'Back to home') }));
        return;
      }
      host.append(h('p', { class: 'muted result-count', role: 'status' }, `${results.length} ${results.length === 1 ? 'video' : 'videos'}`), h('div', { class: 'vlist' }, withListBanners(results.map((v) => videoCard(v)))));
    } catch (e) {
      clear(host);
      host.append(errorState(e.message, run));
    }
  };
  await run();
}
