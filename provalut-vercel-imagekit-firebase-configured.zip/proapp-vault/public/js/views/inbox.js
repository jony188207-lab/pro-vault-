import { h, icon, timeAgo, fullDate } from '../lib/dom.js';
import { query } from '../lib/firebase.js';
import { markSeen, state } from '../state.js';
import { emptyState, errorState, thumb } from '../components.js';

export async function render({ root, isCurrent }) {
  const page = h('div', { class: 'page' }, h('h1', { class: 'sec-title big' }, icon('bell', 20), 'Inbox'));
  root.append(page);
  const host = h('section', { class: 'block' }, h('p', { class: 'muted' }, 'Loading…'));
  page.append(host);
  const load = async () => {
    try {
      const items = await query({ collection: 'notifications', orderBy: [['createdAt', 'desc']], limit: 40 });
      if (!isCurrent()) return;
      const seen = state.user.notificationsSeenAt ? new Date(state.user.notificationsSeenAt).getTime() : 0;
      host.replaceChildren();
      if (!items.length) host.append(emptyState({ title: 'No notifications yet', text: 'You will see new videos here as soon as they are published.' }));
      else {
        host.append(h('ul', { class: 'inbox' }, items.map((n) => {
          const fresh = n.createdAt instanceof Date && n.createdAt.getTime() > seen;
          return h('li', null, h('a', { class: `inbox-item ${fresh ? 'fresh' : ''}`, href: `#/v/${n.videoId}` },
            h('div', { class: 'inbox-thumb' }, thumb({ title: n.title, thumbnailUrl: n.thumbnailUrl }, { width: 160 })),
            h('div', { class: 'inbox-body' }, h('strong', null, n.title), h('span', { class: 'muted small-text', title: fullDate(n.createdAt) }, `New video · ${timeAgo(n.createdAt)}`)),
            fresh ? h('span', { class: 'dot', 'aria-label': 'New' }) : null));
        })));
      }
      markSeen();
    } catch (e) {
      host.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}
