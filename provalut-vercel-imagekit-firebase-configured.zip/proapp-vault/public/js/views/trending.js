import { h, icon } from '../lib/dom.js';
import { query } from '../lib/firebase.js';
import { bannerSlot, emptyState, errorState, skeletonGrid, videoCard, withListBanners } from '../components.js';

export async function render({ root, isCurrent }) {
  const page = h('div', { class: 'page' }, h('h1', { class: 'sec-title big' }, icon('flame', 20), 'Trending'));
  root.append(page);
  const host = h('section', { class: 'block' }, skeletonGrid(2));
  page.append(host);
  const load = async () => {
    try {
      const vids = (await query({ collection: 'videos', where: [['status', '==', 'published']], orderBy: [['views', 'desc']], limit: 30 })).filter((v) => (v.views || 0) > 0);
      if (!isCurrent()) return;
      host.replaceChildren();
      if (!vids.length) return host.append(emptyState({ title: 'Nothing is trending yet', text: 'Videos show up here once people start watching them.', action: h('a', { class: 'btn primary', href: '#/' }, 'Browse videos') }));
      host.append(h('div', { class: 'vlist' }, withListBanners(vids.map((v) => videoCard(v)))));
    } catch (e) {
      host.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
  page.append(bannerSlot('homeBottom'));
}
