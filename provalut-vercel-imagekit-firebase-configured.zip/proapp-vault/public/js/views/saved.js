import { h, icon } from '../lib/dom.js';
import { query, getDocs } from '../lib/firebase.js';
import { state } from '../state.js';
import { emptyState, errorState, skeletonGrid, videoCard, withListBanners } from '../components.js';

export async function render({ root, isCurrent }) {
  const page = h('div', { class: 'page' }, h('h1', { class: 'sec-title big' }, icon('bookmark', 20), 'My Watchlist'));
  root.append(page);
  const host = h('section', { class: 'block' }, skeletonGrid(2));
  page.append(host);
  const load = async () => {
    try {
      const saves = await query({ collection: 'saves', where: [['uid', '==', state.user.uid]], orderBy: [['createdAt', 'desc']], limit: 60 });
      const docs = await getDocs(saves.map((s) => `videos/${s.videoId}`));
      if (!isCurrent()) return;
      const videos = docs.filter((v) => v && v.status === 'published');
      host.replaceChildren();
      if (!videos.length) {
        host.append(emptyState({ title: 'Your Watchlist is empty', text: 'Tap “Save Later” on any video to keep it here.', action: h('a', { class: 'btn primary', href: '#/' }, 'Browse videos') }));
        return;
      }
      host.append(h('div', { class: 'vlist' }, withListBanners(videos.map((v) => videoCard(v)))));
    } catch (e) {
      host.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}
