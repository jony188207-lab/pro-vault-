// Video details: cover, like / download / share tiles, parts list with a separate unlock per part, comments.
import { h, icon, compact, timeAgo, fullDate, toast, confirmDialog, busy, clear, dialog } from '../lib/dom.js';
import { getDoc, query } from '../lib/firebase.js';
import { api, ApiError } from '../lib/api.js';
import { state, isAdmin, rememberReturn } from '../state.js';
import { thumb, errorState, emptyState, avatar, bannerSlot } from '../components.js';
import { thumbSrc } from '../lib/media.js';

const fill = (text, seconds) => String(text || '').split('{seconds}').join(String(seconds));
const partName = (p) => `${p.title || `Video Part ${p.number}`} [${p.quality}]`;

export async function render({ root, params, isCurrent }) {
  const id = params.id;
  const page = h('div', { class: 'page details' });
  root.append(page);
  page.append(h('div', { class: 'dhero skeleton' }), h('div', { class: 'sk-line' }), h('div', { class: 'sk-line short' }));

  let video;
  try {
    video = await getDoc(`videos/${id}`);
  } catch (e) {
    clear(page);
    return page.append(errorState(e.message, () => (clear(root), render({ root, params, isCurrent }))));
  }
  if (!isCurrent()) return;
  clear(page);
  if (!video || (video.status !== 'published' && !isAdmin())) {
    return page.append(emptyState({ title: 'Video not found', text: 'It may have been removed or is not published yet.', action: h('a', { class: 'btn primary', href: '#/' }, 'Back to home') }));
  }
  document.title = `${video.title} · ${state.settings.siteName}`;
  const texts = state.settings.texts;
  const parts = Array.isArray(video.partsSummary) ? video.partsSummary : [];
  const ui = { liked: false, saved: false, unlocked: {}, loaded: false };

  // ---------------------------------------------------------------- header + hero
  const hero = h('div', { class: 'dhero' });
  const poster = thumbSrc(video.thumbnailUrl, 960) || thumbSrc(parts.find((p) => p.thumbnailUrl)?.thumbnailUrl, 960);
  if (poster) hero.append(h('img', { class: 'dhero-bg', src: poster, alt: '', 'aria-hidden': 'true' }), h('img', { class: 'dhero-img', src: poster, alt: '', decoding: 'async', onerror: (e) => e.target.remove() }));
  else hero.append(thumb(video, { eager: true, width: 960 }));
  if (parts[0]) hero.append(h('span', { class: 'hd-tag' }, parts[0].quality));

  const title = h('h1', { class: 'dtitle' }, video.title);
  const meta = h('p', { class: 'meta' });
  const tiles = h('div', { class: 'dstats' });
  const likeBtn = h('button', { class: 'btn dlike', type: 'button', 'aria-pressed': 'false' });
  const downloadBtn = h('button', { class: 'btn dpill', type: 'button' }, icon('download', 18), texts.downloadButton);
  const saveBtn = h('button', { class: 'savelater', type: 'button', 'aria-pressed': 'false' });
  const desc = h('div', { class: 'desc' });
  const partsHost = h('section', { class: 'parts-inline', 'aria-labelledby': 'parts-h' });
  const comments = h('section', { class: 'comments', 'aria-labelledby': 'cm-h' });

  page.append(
    h('div', { class: 'dtop' }, h('a', { class: 'round-btn', href: '#/', 'aria-label': 'Back' }, icon('back', 18)), h('span', null, 'Video Details')),
    hero, title, meta, tiles,
    h('div', { class: 'dbtns' }, likeBtn, downloadBtn),
    saveBtn,
    bannerSlot('detailsBelow'),
    partsHost, desc, comments,
  );

  const tile = (ic, count, label, onclick, attrs = {}) =>
    h('button', { class: 'tile', type: 'button', onclick, ...attrs }, icon(ic, 22), h('strong', null, count === null ? '' : compact(count)), h('span', null, label));

  function paintMeta() {
    clear(meta);
    meta.append(h('span', null, icon('eye', 14), `${compact(video.views)} views`), video.category ? h('span', null, video.category) : null, video.createdAt ? h('span', { title: fullDate(video.createdAt) }, timeAgo(video.createdAt)) : null);
  }
  function paintTiles() {
    clear(tiles);
    tiles.append(
      tile('heart', video.likes || 0, 'LIKE', () => likeBtn.click(), { class: `tile ${ui.liked ? 'on' : ''}` }),
      tile('download', video.downloads || 0, 'DOWNLOAD', () => openPartsModal()),
      tile('comment', video.commentsCount || 0, 'COMMENTS', () => comments.scrollIntoView?.({ behavior: 'smooth', block: 'start' })),
      tile('share', null, 'SHARE', share),
    );
  }
  function paintActions() {
    likeBtn.classList.toggle('on', ui.liked);
    likeBtn.setAttribute('aria-pressed', String(ui.liked));
    clear(likeBtn);
    likeBtn.append(icon('heart', 18), ui.liked ? 'Liked' : 'Like');
    saveBtn.classList.toggle('on', ui.saved);
    saveBtn.setAttribute('aria-pressed', String(ui.saved));
    clear(saveBtn);
    saveBtn.append(icon(ui.saved ? 'check' : 'bookmark', 14), ui.saved ? 'Saved' : 'Save Later');
    paintTiles();
  }
  function paintDesc() {
    clear(desc);
    if (video.description) desc.append(...video.description.split(/\n{2,}/).map((p) => h('p', null, p)));
    if (video.tags?.length) desc.append(h('p', { class: 'tags' }, video.tags.map((t) => h('a', { class: 'tag', href: `#/?q=${encodeURIComponent(t)}` }, `#${t}`))));
  }
  paintMeta();
  paintActions();
  paintDesc();

  function requireLogin() {
    if (state.user) return true;
    rememberReturn(`#/v/${id}`);
    toast('Log in to do that.', 'info');
    location.hash = '#/login';
    return false;
  }

  async function share() {
    const url = `${location.origin}${location.pathname}#/v/${id}`;
    try {
      if (navigator.share) return await navigator.share({ title: video.title, url });
      await navigator.clipboard.writeText(url);
      toast('Link copied', 'success');
    } catch (e) {
      if (e?.name !== 'AbortError') toast(`Copy this link: ${url}`, 'info', 9000);
    }
  }

  // ---------------------------------------------------------------- like / save
  likeBtn.addEventListener('click', async () => {
    if (!requireLogin()) return;
    const next = !ui.liked;
    ui.liked = next;
    video.likes = Math.max(0, (video.likes || 0) + (next ? 1 : -1));
    paintActions();
    try {
      const res = await api.post(`/api/videos/${id}/like`, { liked: next });
      ui.liked = res.liked;
      video.likes = res.likes;
    } catch (e) {
      ui.liked = !next;
      video.likes = Math.max(0, (video.likes || 0) + (next ? -1 : 1));
      toast(e.message, 'error');
    }
    paintActions();
  });
  saveBtn.addEventListener('click', async () => {
    if (!requireLogin()) return;
    const next = !ui.saved;
    await busy(saveBtn, async () => {
      try {
        await api.post(`/api/videos/${id}/save`, { saved: next });
        ui.saved = next;
        toast(next ? 'Saved to your watchlist' : 'Removed from your watchlist', 'success');
      } catch (e) {
        toast(e.message, 'error');
      }
    });
    paintActions();
  });
  downloadBtn.addEventListener('click', () => openPartsModal());

  // ---------------------------------------------------------------- parts
  /** One gradient row per part: download icon + name on the left, lock / unlocked icon on the right. */
  function partRows(onRowsChanged) {
    const list = h('div', { class: 'part-list' });
    if (!parts.length) return list.append(h('p', { class: 'muted center' }, 'No parts have been published for this video yet.')), list;
    let openId = null;
    const paint = () => {
      clear(list);
      for (const p of parts) {
        const locked = p.locked && !(p.id in ui.unlocked);
        const row = h('button', { class: `part-row ${locked ? 'locked' : 'open'}`, type: 'button', 'aria-expanded': String(openId === p.id) },
          h('span', { class: 'part-in' }, icon('download', 20), h('span', { class: 'part-name' }, partName(p)), icon(locked ? 'lock' : 'unlock', 20)));
        row.addEventListener('click', () => {
          if (!requireLogin()) return;
          if (locked) return openUnlock(p, () => { openId = p.id; paint(); onRowsChanged?.(); });
          openId = openId === p.id ? null : p.id;
          paint();
        });
        const wrap = h('div', { class: 'part-wrap' }, row);
        if (openId === p.id && !locked) {
          wrap.append(h('div', { class: 'part-actions' },
            h('button', { class: 'btn primary', type: 'button', onclick: (e) => access(p, 'watch', e.currentTarget) }, icon('play', 18), texts.watchButton),
            h('button', { class: 'btn', type: 'button', onclick: (e) => access(p, 'download', e.currentTarget) }, icon('download', 18), texts.downloadButton)));
        }
        list.append(wrap);
      }
    };
    paint();
    list.repaint = paint;
    return list;
  }

  let inlineList = null;
  function paintInlineParts() {
    clear(partsHost);
    partsHost.append(h('h2', { class: 'sec-title', id: 'parts-h' }, icon('list', 18), `Parts (${parts.length})`));
    inlineList = partRows();
    partsHost.append(inlineList);
  }
  paintInlineParts();

  function openPartsModal() {
    if (!requireLogin()) return;
    const howTo = h('div', { class: 'howto' }, h('strong', null, icon('info', 14), texts.howToTitle), h('p', null, fill(texts.howToText, state.settings.gate.minAwaySeconds)));
    const list = partRows(() => inlineList?.repaint?.());
    const body = h('div', { class: 'parts-modal' }, howTo, list, bannerSlot('partsBottom'));
    dialog({ title: texts.partsTitle, body, wide: true });
  }

  // ---------------------------------------------------------------- unlocking one part
  /**
   * The unlock step for ONE part. Opens that part's own link, then asks the server to unlock exactly this part.
   * Honest by design: the server only knows the link was issued, that enough time passed and (with a postback-capable
   * provider) that the provider confirmed. The panel says so and never claims an ad was watched.
   */
  function openUnlock(part, onDone) {
    let sessionId = null;
    let minAway = state.settings.gate.minAwaySeconds;
    let verification = 'sponsor_opened';
    let timer = null;
    let fallbackLink = null;
    const body = h('div', { class: 'unlock' });
    const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const showErr = (m) => {
      err.textContent = m;
      err.hidden = false;
    };
    const d = dialog({ title: partName(part), body, onClose: () => clearTimeout(timer) });
    d.el.querySelector('.dialog')?.classList.add('unlock-dialog');

    const frame = (...content) => h('div', null, h('div', { class: 'unlock-lock' }, icon('lock', 34)), h('h3', { class: 'unlock-title' }, texts.unlockTitle), h('p', { class: 'unlock-sub' }, texts.unlockSubtitle), ...content);
    const disclosure = () => h('p', { class: 'disclosure' }, verification === 'postback' ? 'Your unlock is confirmed by the ad provider.' : 'Unlocking is based on you returning after the wait time. It does not verify that an advertisement was shown or completed.');

    function paintIdle() {
      clear(body);
      const open = h('button', { class: 'btn primary block', type: 'button' }, icon('external', 18), texts.openLinkButton);
      open.addEventListener('click', () => start(open));
      body.append(frame(
        h('ul', { class: 'steps' }, h('li', null, fill(texts.unlockStep1, minAway)), h('li', null, fill(texts.unlockStep2, minAway))),
        h('div', { class: 'warn' }, icon('alert', 16), fill(texts.unlockWarning, minAway)),
        open, err, disclosure()));
    }

    function paintAway() {
      clear(body);
      const verify = h('button', { class: 'btn primary block', type: 'button', disabled: true }, texts.verifyButton);
      const hint = h('p', { class: 'hint', role: 'timer' });
      verify.addEventListener('click', () => complete(verify));
      let left = minAway;
      const tick = () => {
        hint.textContent = left > 0 ? `You can continue in ${left}s` : verification === 'postback' ? 'Waiting for the provider to confirm. This can take a moment.' : 'Ready when you are.';
        verify.disabled = left > 0;
        if (left-- > 0) timer = setTimeout(tick, 1000);
      };
      clearTimeout(timer);
      tick();
      const fallback = fallbackLink ? h('p', { class: 'hint' }, 'Pop-up blocked? ', h('a', { href: fallbackLink, target: '_blank', rel: 'noopener noreferrer sponsored' }, 'Open the link here')) : null;
      body.append(frame(h('p', { class: 'unlock-wait' }, texts.waitingText), hint, verify, fallback, err, disclosure()));
    }

    async function start(btn) {
      err.hidden = true;
      // Open the tab inside the click so pop-up blockers allow it, then point it at this part's link.
      const tab = window.open('about:blank', '_blank');
      try {
        const res = await busy(btn, () => api.post(`/api/parts/${part.id}/unlock/start`, {}), 'Opening…');
        if (res.alreadyUnlocked) {
          tab?.close();
          return finish();
        }
        sessionId = res.sessionId;
        minAway = res.minAwaySeconds;
        verification = res.verification;
        if (tab) {
          try {
            tab.opener = null;
          } catch {
            /* ignore */
          }
          tab.location.href = res.unlockUrl;
        } else fallbackLink = res.unlockUrl;
        paintAway();
      } catch (e) {
        tab?.close();
        showErr(e.message);
      }
    }

    async function complete(btn) {
      err.hidden = true;
      await busy(btn, async () => {
        try {
          await api.post('/api/parts/unlock/complete', { sessionId });
          finish();
        } catch (e) {
          if (e.code === 'session_expired' || e.code === 'invalid_session') {
            sessionId = null;
            paintIdle();
            showErr('That step expired. Please start again.');
          } else if (e.code === 'too_early') showErr(`Not quite yet. Try again in ${e.extra?.retryAfterSeconds || 2}s.`);
          else showErr(e.message);
        }
      }, 'Checking…');
    }

    function finish() {
      clearTimeout(timer);
      ui.unlocked[part.id] = null;
      d.close();
      toast(texts.unlockedText, 'success');
      inlineList?.repaint?.();
      onDone?.();
    }
    paintIdle();
  }

  /** Watch or download an unlocked part. The server re-checks the unlock and returns the real URL. */
  async function access(part, mode, btn) {
    // Pre-open a tab for links that live on another site (a pop-up opened after an await would be blocked).
    const needsTab = part.source === 'external' || (mode === 'download' && part.downloadVia === 'external');
    const tab = needsTab ? window.open('about:blank', '_blank') : null;
    try {
      const res = await busy(btn, () => api.post(`/api/parts/${part.id}/access`, { mode }), mode === 'watch' ? 'Starting…' : 'Preparing…');
      if (res.counted && mode === 'watch') video.views = (video.views || 0) + 1;
      if (res.counted && mode === 'download') video.downloads = (video.downloads || 0) + 1;
      paintMeta();
      paintTiles();
      if (res.kind === 'external') {
        if (tab) {
          try {
            tab.opener = null;
          } catch {
            /* ignore */
          }
          tab.location.href = res.url;
        } else window.open(res.url, '_blank', 'noopener');
        return;
      }
      tab?.close();
      if (mode === 'download') {
        const a = h('a', { href: res.url, rel: 'noopener', download: '' });
        document.body.append(a);
        a.click();
        a.remove();
        toast('Download started', 'success');
      } else playInPage(part, res.url);
    } catch (e) {
      tab?.close();
      if (e instanceof ApiError && e.code === 'locked') {
        delete ui.unlocked[part.id];
        inlineList?.repaint?.();
      }
      toast(e.message, 'error');
    }
  }

  function playInPage(part, url, retried = false) {
    const el = h('video', { class: 'video-el', controls: true, playsinline: true, autoplay: true, controlsList: 'nodownload', poster: poster || undefined, preload: 'metadata' });
    const d = dialog({ title: partName(part), body: h('div', { class: 'player-box' }, el), wide: true, onClose: () => el.pause?.() });
    el.addEventListener('error', async () => {
      if (retried) return toast('This video could not be played. Try again later.', 'error');
      retried = true; // the signed link may have expired: get a fresh one once
      try {
        const res = await api.post(`/api/parts/${part.id}/access`, { mode: 'watch' });
        el.src = res.url;
        el.play?.().catch(() => {});
      } catch (e) {
        toast(e.message, 'error');
        d.close();
      }
    });
    el.src = url;
    el.play?.().catch(() => {});
  }

  // ---------------------------------------------------------------- viewer state, comments
  loadViewerState();
  await renderComments();

  async function loadViewerState() {
    if (!state.user) return;
    try {
      const [s, u] = await Promise.all([api.get(`/api/videos/${id}/state`), api.get(`/api/videos/${id}/unlocks`)]);
      if (!isCurrent()) return;
      ui.liked = s.liked;
      ui.saved = s.saved;
      ui.unlocked = u.unlocked || {};
      ui.loaded = true;
    } catch (e) {
      toast(e.message, 'error');
    }
    paintActions();
    inlineList?.repaint?.();
  }

  async function renderComments() {
    clear(comments);
    const head = h('h2', { id: 'cm-h', class: 'cm-head' });
    const paintHead = () => (head.textContent = `Comments (${video.commentsCount || 0})`);
    paintHead();
    comments.append(head);
    if (state.settings.commentsEnabled === false) return comments.append(h('p', { class: 'muted' }, 'Comments are turned off.'));
    const list = h('ul', { class: 'comment-list' });
    comments.append(list);
    list.append(h('li', { class: 'muted' }, 'Loading comments…'));
    const empty = () => h('li', { class: 'empty-line' }, 'No comments yet. Be the first to say something.');
    const load = async () => {
      try {
        const items = await query({ collection: 'comments', where: [['videoId', '==', id]], orderBy: [['createdAt', 'desc']], limit: 50 });
        if (!isCurrent()) return;
        clear(list);
        if (!items.length) list.append(empty());
        items.forEach((c) => list.append(commentItem(c)));
      } catch (e) {
        clear(list);
        list.append(h('li', null, h('span', { class: 'form-error' }, e.message), ' ', h('button', { class: 'btn small', type: 'button', onclick: load }, 'Retry')));
      }
    };
    function commentItem(c) {
      const mine = state.user && c.uid === state.user.uid;
      const li = h('li', { class: 'comment', dataset: { id: c.id } },
        avatar(c.authorName, c.authorPhoto, { 'aria-hidden': 'true' }),
        h('div', { class: 'comment-main' },
          h('p', { class: 'comment-head' }, h('strong', null, c.authorName || 'Member'), h('time', { datetime: c.createdAt?.toISOString?.(), title: fullDate(c.createdAt) }, timeAgo(c.createdAt))),
          h('p', { class: 'comment-text' }, c.text)),
        mine || isAdmin()
          ? h('button', { class: 'icon-btn danger', type: 'button', 'aria-label': 'Delete comment', onclick: async () => {
              if (!(await confirmDialog({ title: 'Delete comment?', message: 'This can not be undone.', confirmLabel: 'Delete', danger: true }))) return;
              try {
                await api.del(`/api/comments/${c.id}`);
                li.remove();
                video.commentsCount = Math.max(0, (video.commentsCount || 0) - 1);
                paintHead();
                paintTiles();
                if (!list.children.length) list.append(empty());
              } catch (e) {
                toast(e.message, 'error');
              }
            } }, icon('trash', 18))
          : null);
      return li;
    }
    // sticky bar at the bottom of the screen, like the reference
    const bar = commentBar();
    page.append(bar);
    function commentBar() {
      if (!state.user) {
        return h('a', { class: 'cbar cbar-login', href: '#/login', onclick: () => rememberReturn(`#/v/${id}`) }, h('span', null, 'Log in to add a comment'), h('span', { class: 'send' }, icon('send', 18)));
      }
      const input = h('input', { class: 'cinput', type: 'text', maxlength: 1000, placeholder: 'Add a public comment...', 'aria-label': 'Add a comment', autocomplete: 'off' });
      const btn = h('button', { class: 'send', type: 'submit', 'aria-label': 'Post comment' }, icon('send', 18));
      const f = h('form', { class: 'cbar' }, input, btn);
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const text = input.value.trim();
        if (!text) return;
        await busy(btn, async () => {
          try {
            const { comment } = await api.post(`/api/videos/${id}/comments`, { text });
            comment.createdAt = new Date(comment.createdAt);
            input.value = '';
            list.querySelector('.empty-line, .muted')?.closest('li')?.remove();
            list.prepend(commentItem(comment));
            video.commentsCount = (video.commentsCount || 0) + 1;
            paintHead();
            paintTiles();
          } catch (ex) {
            toast(ex.message, 'error');
          }
        });
      });
      return f;
    }
    await load();
  }
}
