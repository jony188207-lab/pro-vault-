// The account sheet that slides up from the bottom when "Profile" is tapped (like the reference app).
import { h, icon, toast } from '../lib/dom.js';
import { state, isAdmin, logout } from '../state.js';
import { avatar } from '../components.js';
import { navigate } from '../router.js';

let open = null;

export function openMenu() {
  if (open) return;
  const previouslyFocused = document.activeElement;
  const close = () => {
    overlay.remove();
    document.removeEventListener('keydown', onKey);
    document.body.classList.remove('no-scroll');
    previouslyFocused?.focus?.();
    open = null;
  };
  const onKey = (e) => e.key === 'Escape' && close();
  const go = (hash) => () => {
    close();
    navigate(hash);
  };
  const tile = (ic, title, sub, hash, badge) =>
    h('a', { class: 'menu-tile', href: hash, onclick: close }, h('span', { class: 'menu-ic' }, icon(ic, 20), badge ? h('span', { class: 'hbadge' }, badge > 9 ? '9+' : String(badge)) : null), h('span', { class: 'menu-t' }, h('strong', null, title), h('small', null, sub)));

  const u = state.user;
  const body = h('div', { class: 'sheet-body' });
  if (u) {
    body.append(
      h('div', { class: 'user-card' }, avatar(u.displayName, u.photoURL, { class: 'lg', 'aria-hidden': 'true' }), h('div', null, h('strong', { class: 'user-name' }, u.displayName), h('p', { class: 'muted small-text' }, u.email), h('span', { class: `chip-role ${isAdmin() ? 'admin' : ''}` }, isAdmin() ? 'Admin' : 'Member'))),
      h('div', { class: 'menu-grid' },
        tile('bookmark', 'My Saved', 'Watchlist videos', '#/saved'),
        tile('history', 'History', 'Recently watched', '#/history'),
        tile('bell', 'Notifications', 'New video alerts', '#/inbox', state.unread),
        tile('user', 'Account', 'Name, photo, password', '#/profile'),
        isAdmin() ? tile('shield', 'Admin Panel', 'Manage videos & ads', '#/admin') : null,
      ),
      h('button', { class: 'btn block ghost-danger', type: 'button', onclick: async () => {
        close();
        await logout();
        toast('You are logged out.', 'info');
        navigate('#/');
      } }, icon('logout', 18), 'Log out'),
    );
  } else {
    body.append(
      h('div', { class: 'user-card' }, h('div', { class: 'avatar lg', 'aria-hidden': 'true' }, icon('user', 26)), h('div', null, h('strong', { class: 'user-name' }, 'Welcome to Provalut'), h('p', { class: 'muted small-text' }, 'Log in to save videos, comment and unlock parts.'))),
      h('div', { class: 'row' }, h('a', { class: 'btn primary grow', href: '#/login', onclick: close }, 'Log in'), h('a', { class: 'btn grow', href: '#/signup', onclick: close }, 'Create account')),
    );
  }
  body.append(h('button', { class: 'btn block close-menu', type: 'button', onclick: close }, 'Close Menu'));
  const overlay = h('div', { class: 'overlay sheet-overlay', onclick: (e) => e.target === overlay && close() }, h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Account menu' }, h('div', { class: 'grabber', 'aria-hidden': 'true' }), body));
  document.body.append(overlay);
  document.body.classList.add('no-scroll');
  document.addEventListener('keydown', onKey);
  open = { close };
  overlay.querySelector('a,button')?.focus();
}
