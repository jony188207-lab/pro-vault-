import { h, icon } from '../lib/dom.js';

const LINKS = [
  ['/admin', 'chart', 'Dashboard'],
  ['/admin/videos', 'film', 'Videos'],
  ['/admin/media', 'image', 'Media'],
  ['/admin/users', 'users', 'Users'],
  ['/admin/ads', 'megaphone', 'Ads'],
  ['/admin/analytics', 'chart', 'Analytics'],
  ['/admin/settings', 'cog', 'Settings'],
];

/** Admin page frame with a scrollable sub-navigation. Returns the content element. */
export function adminPage(root, title, active, actions) {
  const sub = h('nav', { class: 'subnav', 'aria-label': 'Admin' }, LINKS.map(([to, ic, label]) => h('a', { href: `#${to}`, class: to === active ? 'active' : '', 'aria-current': to === active ? 'page' : undefined }, icon(ic, 16), label)));
  const body = h('div', { class: 'admin-body' });
  const page = h('div', { class: 'page wide admin' }, sub, h('div', { class: 'block-head' }, h('h1', { class: 'h2' }, title), actions || null), body);
  root.append(page);
  return body;
}

export function loading() {
  return h('div', { class: 'boot' }, h('div', { class: 'spinner', role: 'status', 'aria-label': 'Loading' }));
}

export function stat(label, value, iconName, sub) {
  return h('div', { class: 'stat' }, h('div', { class: 'stat-icon' }, icon(iconName, 18)), h('p', { class: 'stat-value' }, String(value)), h('p', { class: 'stat-label' }, label), sub ? h('p', { class: 'stat-sub' }, sub) : null);
}

/** Accessible bar chart (SVG). data: [{ label, value }] */
export function barChart(data, { title, color = 'var(--brass)', height = 120 } = {}) {
  const ns = 'http://www.w3.org/2000/svg';
  const w = 300;
  const max = Math.max(1, ...data.map((d) => d.value));
  const gap = 3;
  const bw = Math.max(2, (w - gap * (data.length - 1)) / Math.max(1, data.length));
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', `0 0 ${w} ${height}`);
  svg.setAttribute('class', 'chart');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', `${title}: ${data.map((d) => `${d.label} ${d.value}`).join(', ')}`);
  data.forEach((d, i) => {
    const bh = Math.max(d.value ? 2 : 0.5, (d.value / max) * (height - 8));
    const r = document.createElementNS(ns, 'rect');
    r.setAttribute('x', i * (bw + gap));
    r.setAttribute('y', height - bh);
    r.setAttribute('width', bw);
    r.setAttribute('height', bh);
    r.setAttribute('rx', 2);
    r.setAttribute('fill', d.value ? color : 'var(--line)');
    const t = document.createElementNS(ns, 'title');
    t.textContent = `${d.label}: ${d.value}`;
    r.append(t);
    svg.append(r);
  });
  return h('figure', { class: 'chart-card' }, h('figcaption', null, h('span', null, title), h('strong', null, String(data.reduce((s, d) => s + d.value, 0)))), svg, data.length ? h('p', { class: 'chart-axis' }, h('span', null, data[0].label), h('span', null, data[data.length - 1].label)) : null);
}
