// Create / edit a video, and (when editing) manage its parts: add, edit, delete, reorder, publish.
import { h, icon, toast, busy, bytes, confirmDialog } from '../lib/dom.js';
import { api, ApiError } from '../lib/api.js';
import { thumbSrc } from '../lib/media.js';
import { getDoc } from '../lib/firebase.js';
import { state } from '../state.js';
import { navigate } from '../router.js';
import { adminPage, loading } from './layout.js';
import { errorState, emptyState } from '../components.js';
import { uploadVideo, uploadThumbnail, describeFile, readDuration } from './upload.js';

const fieldRow = (label, id, input, hint, cls = '') => h('div', { class: `field ${cls}` }, h('label', { for: id }, label), input, hint ? h('p', { class: 'hint' }, hint) : null);

export async function render({ root, params, isCurrent }) {
  const editing = !!params.id;
  const body = adminPage(root, editing ? 'Edit video' : 'Add video', '/admin/videos', h('a', { class: 'btn', href: '#/admin/videos' }, icon('back', 18), 'All videos'));
  body.append(loading());
  let video = null;
  if (editing) {
    try {
      video = await getDoc(`videos/${params.id}`);
    } catch (e) {
      return body.replaceChildren(errorState(e.message, () => location.reload()));
    }
    if (!isCurrent()) return;
    if (!video) return body.replaceChildren(emptyState({ title: 'Video not found', action: h('a', { class: 'btn primary', href: '#/admin/videos' }, 'Back to videos') }));
  }
  const v = video || { title: '', description: '', tags: [], category: '', status: 'draft' };

  const f = {
    title: h('input', { class: 'input', id: 'f-title', value: v.title, maxlength: 120, required: true }),
    description: h('textarea', { class: 'input', id: 'f-desc', rows: 5, maxlength: 2000 }, v.description || ''),
    category: h('input', { class: 'input', id: 'f-cat', value: v.category || '', maxlength: 30, list: 'cat-options', placeholder: 'e.g. Movies' }),
    tags: h('input', { class: 'input', id: 'f-tags', value: (v.tags || []).join(', '), placeholder: 'comma, separated, tags' }),
    status: h('select', { class: 'input', id: 'f-status' }, ['draft', 'published'].map((s) => h('option', { value: s, selected: v.status === s }, s === 'draft' ? 'Draft (hidden)' : 'Published'))),
  };
  const catList = h('datalist', { id: 'cat-options' }, (state.settings.categories || []).map((c) => h('option', { value: c })));

  // cover thumbnail
  let thumbFile = null;
  const thumbPreview = h('img', { class: 'thumb-preview', alt: 'Cover preview', hidden: !v.thumbnailUrl });
  if (v.thumbnailUrl) thumbPreview.src = thumbSrc(v.thumbnailUrl, 480);
  const thumbInput = h('input', { class: 'input', id: 'f-thumb', type: 'file', accept: 'image/jpeg,image/png,image/webp' });
  thumbInput.addEventListener('change', () => {
    thumbFile = thumbInput.files[0] || null;
    if (!thumbFile) return;
    const problem = describeFile(thumbFile, 'image');
    if (problem) {
      thumbFile = null;
      thumbInput.value = '';
      return toast(problem, 'error');
    }
    thumbPreview.src = URL.createObjectURL(thumbFile);
    thumbPreview.hidden = false;
  });

  const progress = h('progress', { max: 1, value: 0, hidden: true, 'aria-label': 'Upload progress' });
  const progressText = h('p', { class: 'hint', role: 'status', 'aria-live': 'polite' });
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const save = h('button', { class: 'btn primary', type: 'submit' }, editing ? 'Save details' : 'Create video');
  const cancel = new AbortController();

  const form = h('form', { class: 'form admin-form', novalidate: true },
    h('section', { class: 'card' },
      h('h2', null, 'Details'),
      fieldRow('Title', 'f-title', f.title),
      fieldRow('Description', 'f-desc', f.description),
      fieldRow('Category', 'f-cat', f.category, 'Pick one from the list or type a new one. Manage the list in Settings.'),
      catList,
      fieldRow('Tags', 'f-tags', f.tags, 'Up to 10. Tags are searchable.'),
      fieldRow('Visibility', 'f-status', f.status, 'A video can be published once it has at least one published part.')),
    h('section', { class: 'card' },
      h('h2', null, 'Cover image'),
      fieldRow('Thumbnail', 'f-thumb', thumbInput, 'JPG, PNG or WebP, up to 5 MB.'),
      thumbPreview, progress, progressText),
    err,
    h('div', { class: 'sticky-actions' }, h('a', { class: 'btn', href: '#/admin/videos' }, 'Cancel'), save));

  body.replaceChildren(form);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.hidden = true;
    const show = (m) => ((err.textContent = m), (err.hidden = false), err.scrollIntoView?.({ block: 'center' }));
    const title = f.title.value.trim();
    if (!title) return show('Enter a title.');
    await busy(save, async () => {
      try {
        const payload = { title, description: f.description.value, category: f.category.value, tags: f.tags.value.split(',').map((t) => t.trim()).filter(Boolean), status: f.status.value };
        if (thumbFile) {
          progress.hidden = false;
          progressText.textContent = 'Uploading cover…';
          payload.thumbnailFileId = await uploadThumbnail(thumbFile, (p) => (progress.value = p));
          thumbFile = null;
        }
        progressText.textContent = 'Saving…';
        if (editing) {
          const res = await api.patch(`/api/admin/videos/${params.id}`, payload);
          toast(res.notified ? 'Video updated and published. Notification sent.' : 'Video updated', 'success');
          progress.hidden = true;
          progressText.textContent = '';
        } else {
          payload.status = 'draft'; // parts are added next; publish once there is at least one
          const res = await api.post('/api/admin/videos', payload);
          toast('Video created. Now add its parts.', 'success');
          navigate(`#/admin/videos/${res.id}`);
        }
      } catch (ex) {
        progress.hidden = true;
        progressText.textContent = '';
        show(ex instanceof ApiError || ex.message ? ex.message : 'Could not save. Try again.');
      }
    }, 'Saving…');
  });
  window.addEventListener('hashchange', () => cancel.abort(), { once: true });

  if (editing) body.append(partsEditor(params.id, isCurrent, cancel.signal));
  else body.append(h('p', { class: 'muted' }, 'After you create the video you can add as many parts as you need (Part 1, Part 2, …), each with its own file, quality, download link and unlock link.'));
}

// ---------------------------------------------------------------------------------------------------- parts
function partsEditor(videoId, isCurrent, signal) {
  const host = h('section', { class: 'card' });
  const list = h('div', { class: 'parts-admin' });
  const addBtn = h('button', { class: 'btn primary', type: 'button' }, icon('plus', 18), 'Add part');
  host.append(h('div', { class: 'block-head' }, h('h2', null, 'Parts'), addBtn), h('p', { class: 'muted' }, 'Parts are numbered automatically in the order shown. Each locked part opens its own unlock link; banner ads never unlock anything.'), list);
  let parts = [];

  async function load() {
    list.replaceChildren(loading());
    try {
      const res = await api.get(`/api/admin/videos/${videoId}/parts`);
      if (!isCurrent()) return;
      parts = res.parts;
      paint();
    } catch (e) {
      list.replaceChildren(errorState(e.message, load));
    }
  }

  function paint() {
    list.replaceChildren();
    if (!parts.length) list.append(h('p', { class: 'muted' }, 'No parts yet. Add Part 1 to get started.'));
    parts.forEach((p, i) => list.append(partCard(p, i)));
  }

  async function move(i, dir) {
    const order = parts.map((p) => p.id);
    [order[i], order[i + dir]] = [order[i + dir], order[i]];
    try {
      await api.put(`/api/admin/videos/${videoId}/parts/order`, { order });
      await load();
    } catch (e) {
      toast(e.message, 'error');
    }
  }

  function partCard(p, i) {
    const card = h('div', { class: 'part-card' });
    const name = `Part ${p.number}${p.title ? ` – ${p.title}` : ''} [${p.quality}]`;
    const toggle = h('button', { class: 'btn small', type: 'button' }, p.status === 'published' ? 'Unpublish' : 'Publish');
    toggle.addEventListener('click', () => busy(toggle, async () => {
      try {
        const res = await api.patch(`/api/admin/parts/${p.id}`, { status: p.status === 'published' ? 'draft' : 'published' });
        toast(res.notified ? 'Published. Notification created.' : p.status === 'published' ? 'Part unpublished' : 'Part published', 'success');
        await load();
      } catch (e) {
        toast(e.message, 'error');
      }
    }));
    card.append(h('div', { class: 'part-card-head' },
      h('strong', null, name),
      h('span', { class: `chip ${p.status === 'published' ? 'ok' : 'mute'}` }, p.status),
      h('span', { class: 'chip' }, p.locked ? 'locked' : 'free'),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Move up', disabled: i === 0, onclick: () => move(i, -1) }, icon('up', 16)),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Move down', disabled: i === parts.length - 1, onclick: () => move(i, 1) }, icon('down', 16)),
      toggle,
      h('button', { class: 'btn small', type: 'button', onclick: () => card.replaceWith(partForm(p)) }, icon('edit', 14), 'Edit'),
      h('button', { class: 'btn small danger', type: 'button', onclick: () => remove(p) }, icon('trash', 14))));
    card.append(h('p', { class: 'muted small-text' }, [p.videoFileId ? `Uploaded file · ${bytes(p.sizeBytes)}` : p.externalUrl ? `External link · ${p.externalUrl}` : 'No media yet', p.downloadUrl ? 'custom download link' : null, p.locked ? (p.unlockUrl ? 'own unlock link' : 'default unlock link') : null].filter(Boolean).join(' · ')));
    return card;
  }

  async function remove(p) {
    if (!(await confirmDialog({ title: `Delete Part ${p.number}?`, message: 'Its unlock records are removed and the remaining parts are renumbered. The uploaded file is removed from ImageKit too.', confirmLabel: 'Delete part', danger: true }))) return;
    try {
      await api.del(`/api/admin/parts/${p.id}?deleteMedia=1`);
      toast('Part deleted', 'success');
      await load();
    } catch (e) {
      toast(e.message, 'error');
    }
  }

  function partForm(p) {
    const editingPart = !!p;
    const x = p || { title: '', quality: 'HD', status: 'draft', locked: true, unlockUrl: '', minAwaySeconds: 0, verification: 'sponsor_opened', externalUrl: '', downloadUrl: '' };
    const uid = `pf${Math.random().toString(36).slice(2, 7)}`;
    const id = (n) => `${uid}-${n}`;
    const title = h('input', { class: 'input', id: id('title'), value: x.title || '', maxlength: 80, placeholder: `Video Part ${editingPart ? p.number : parts.length + 1}` });
    const quality = h('input', { class: 'input', id: id('q'), value: x.quality || 'HD', maxlength: 12 });
    const status = h('select', { class: 'input', id: id('st') }, ['draft', 'published'].map((s) => h('option', { value: s, selected: x.status === s }, s === 'draft' ? 'Draft (hidden)' : 'Published')));
    const source = h('select', { class: 'input', id: id('src') }, [['upload', 'Upload a video file (ImageKit)'], ['url', 'Link to a video on another site (https)']].map(([val, l]) => h('option', { value: val, selected: (x.externalUrl ? 'url' : 'upload') === val }, l)));
    const fileInput = h('input', { class: 'input', id: id('file'), type: 'file', accept: 'video/mp4,video/webm,video/quicktime' });
    const fileInfo = h('p', { class: 'hint' }, x.videoFileId ? `Current file: ${x.contentType || 'video'} · ${bytes(x.sizeBytes)}. Choose a file to replace it.` : 'MP4, WebM or MOV.');
    const ext = h('input', { class: 'input', id: id('ext'), type: 'url', value: x.externalUrl || '', placeholder: 'https://…', maxlength: 1000 });
    const dl = h('input', { class: 'input', id: id('dl'), type: 'url', value: x.downloadUrl || '', placeholder: 'https://… (optional; otherwise the video file is downloaded)', maxlength: 1000 });
    const partThumb = h('input', { class: 'input', id: id('th'), type: 'file', accept: 'image/jpeg,image/png,image/webp' });
    const locked = h('input', { type: 'checkbox', id: id('lock'), checked: x.locked !== false });
    const unlockUrl = h('input', { class: 'input', id: id('ul'), type: 'url', value: x.unlockUrl || '', placeholder: 'https://… Smartlink for THIS part ({sid} = session id)', maxlength: 1000 });
    const away = h('input', { class: 'input', id: id('away'), type: 'number', min: 0, max: 120, value: x.minAwaySeconds || '', placeholder: 'Use default' });
    const verif = h('select', { class: 'input', id: id('vf') }, [['sponsor_opened', 'Link opened + time away (default)'], ['postback', 'Also wait for the provider’s server confirmation']].map(([val, l]) => h('option', { value: val, selected: x.verification === val }, l)));
    const progress = h('progress', { max: 1, value: 0, hidden: true });
    const info = h('p', { class: 'hint', role: 'status' });
    const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const saveBtn = h('button', { class: 'btn primary', type: 'submit' }, editingPart ? 'Save part' : 'Add part');
    const cancelBtn = h('button', { class: 'btn', type: 'button' }, 'Cancel');
    const fileRow = fieldRow('Video file', id('file'), fileInput, null, 'wide-field');
    const extRow = fieldRow('Video URL', id('ext'), ext, 'A direct link opens in a new tab for viewers.', 'wide-field');
    const sync = () => {
      const up = source.value === 'upload';
      fileRow.hidden = !up;
      fileInfo.hidden = !up;
      extRow.hidden = up;
    };
    source.addEventListener('change', sync);
    sync();
    const form = h('form', { class: 'part-card form', novalidate: true },
      h('strong', null, editingPart ? `Edit Part ${p.number}` : 'New part'),
      h('div', { class: 'part-fields' },
        fieldRow('Title (optional)', id('title'), title, 'Leave empty to show “Video Part N”.'),
        fieldRow('Quality', id('q'), quality, 'For example HD, 720p, 4K.'),
        fieldRow('Source', id('src'), source, null, 'wide-field'),
        fileRow, fileInfo, extRow,
        fieldRow('Download URL', id('dl'), dl, null, 'wide-field'),
        fieldRow('Thumbnail (optional)', id('th'), partThumb),
        fieldRow('Visibility', id('st'), status),
        h('div', { class: 'field wide-field' }, h('label', { class: 'check', for: id('lock') }, locked, 'Locked: viewers must unlock this part with its own link'), h('p', { class: 'hint indent' }, 'A locked part needs an unlock link here, or a default link in Ads → Unlock settings.')),
        fieldRow('Unlock link (Smartlink)', id('ul'), unlockUrl, 'Not the banner code. Opens in a new tab when a viewer unlocks this part.', 'wide-field'),
        fieldRow('Seconds away (optional)', id('away'), away),
        fieldRow('Verification', id('vf'), verif, 'Choose the server-confirmation option only if your provider really sends postbacks to /api/ads/postback.')),
      progress, info, err,
      h('div', { class: 'row' }, cancelBtn, saveBtn));
    cancelBtn.addEventListener('click', () => (editingPart ? paint() : form.remove()));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.hidden = true;
      const show = (m) => ((err.textContent = m), (err.hidden = false));
      const up = source.value === 'upload';
      const file = up ? fileInput.files[0] : null;
      if (file) {
        const problem = describeFile(file, 'video');
        if (problem) return show(problem);
      }
      if (!up && !/^https:\/\//i.test(ext.value.trim())) return show('The video URL must start with https://');
      if (dl.value.trim() && !/^https:\/\//i.test(dl.value.trim())) return show('The download URL must start with https://');
      if (unlockUrl.value.trim() && !/^https:\/\//i.test(unlockUrl.value.trim())) return show('The unlock link must start with https://');
      await busy(saveBtn, async () => {
        try {
          const payload = { title: title.value, quality: quality.value, status: status.value, downloadUrl: dl.value.trim(), locked: locked.checked, unlockUrl: unlockUrl.value.trim(), minAwaySeconds: Number(away.value) || 0, verification: verif.value };
          progress.hidden = false;
          if (up && file) {
            info.textContent = 'Uploading video…';
            payload.videoFileId = await uploadVideo(file, (pr) => ((progress.value = pr), (info.textContent = `Uploading video… ${Math.round(pr * 100)}%`)), signal);
            const secs = await readDuration(file);
            if (secs) payload.durationSec = secs;
          } else if (!up) {
            payload.externalUrl = ext.value.trim();
          }
          if (partThumb.files[0]) {
            const problem = describeFile(partThumb.files[0], 'image');
            if (problem) throw new Error(problem);
            info.textContent = 'Uploading thumbnail…';
            progress.value = 0;
            payload.thumbnailFileId = await uploadThumbnail(partThumb.files[0], (pr) => (progress.value = pr));
          }
          info.textContent = 'Saving…';
          const res = editingPart ? await api.patch(`/api/admin/parts/${p.id}`, payload) : await api.post(`/api/admin/videos/${videoId}/parts`, payload);
          toast(res.notified ? 'Part saved. Video published and notification created.' : 'Part saved', 'success');
          await load();
        } catch (ex) {
          progress.hidden = true;
          info.textContent = '';
          show(ex instanceof ApiError || ex.message ? ex.message : 'Could not save this part.');
        }
      }, 'Saving…');
    });
    return form;
  }

  addBtn.addEventListener('click', () => {
    if (list.querySelector('form')) return;
    const f = partForm(null);
    list.append(f);
    f.scrollIntoView?.({ block: 'center' });
    f.querySelector('input')?.focus();
  });
  load();
  return host;
}
