import { h, toast, busy } from '../lib/dom.js';
import { api } from '../lib/api.js';
import { loadSettings } from '../state.js';
import { adminPage, loading } from './layout.js';
import { errorState } from '../components.js';
import { field, check } from './settings-shared.js';

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'App settings', '/admin/settings');
  body.append(loading());
  const load = async () => {
    try {
      const { settings: s } = await api.get('/api/admin/settings');
      if (!isCurrent()) return;
      const name = h('input', { class: 'input', id: 's-name', value: s.siteName, maxlength: 40, required: true });
      const tag = h('input', { class: 'input', id: 's-tag', value: s.tagline, maxlength: 100 });
      const pop = h('input', { class: 'input', id: 's-pop', type: 'number', min: 1, max: 20, value: s.popularCount });
      const list = h('input', { class: 'input', id: 's-list', type: 'number', min: 1, max: 60, value: s.homeListLimit });
      const signups = h('input', { type: 'checkbox', id: 's-signups', checked: s.allowSignups });
      const comments = h('input', { type: 'checkbox', id: 's-comments', checked: s.commentsEnabled });
      const cats = h('textarea', { class: 'input', id: 's-cats', rows: 6, maxlength: 800 }, (s.categories || []).join('\n'));
      const btn = h('button', { class: 'btn primary', type: 'submit' }, 'Save settings');
      const form = h('form', { class: 'card form', novalidate: true },
        h('h2', null, 'Site'),
        field('Site name', 's-name', name),
        field('Tagline', 's-tag', tag),
        h('h2', null, 'Home screen'),
        h('div', { class: 'two' }, field('Trending shown', 's-pop', pop, '1 to 20'), field('Recently added per page', 's-list', list, '1 to 60 per page')),
        h('h2', null, 'Categories'),
        field('Category list', 's-cats', cats, 'One per line, up to 20. Shown in the Categories picker on Home.'),
        h('h2', null, 'Community'),
        check('s-signups', signups, 'Allow new sign-ups'),
        check('s-comments', comments, 'Allow comments'),
        h('div', { class: 'row' }, btn));
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          await busy(btn, () => api.put('/api/admin/settings', { siteName: name.value, tagline: tag.value, popularCount: Number(pop.value), categories: cats.value.split('\n').map((x) => x.trim()).filter(Boolean), homeListLimit: Number(list.value), allowSignups: signups.checked, commentsEnabled: comments.checked }), 'Saving…');
          await loadSettings();
          toast('Settings saved', 'success');
        } catch (ex) {
          toast(ex.message, 'error');
        }
      });
      body.replaceChildren(form);
    } catch (e) {
      body.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}
