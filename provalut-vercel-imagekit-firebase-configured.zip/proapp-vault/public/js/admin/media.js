import { h, icon, toast, confirmDialog, bytes, timeAgo } from '../lib/dom.js';
import { api } from '../lib/api.js';
import { thumbSrc } from '../lib/media.js';
import { adminPage, loading } from './layout.js';
import { emptyState, errorState } from '../components.js';

const TABS = [['videos', 'Videos'], ['thumbs', 'Thumbnails'], ['avatars', 'Profile photos']];

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Media', '/admin/media', h('a', { class: 'btn primary', href: '#/admin/videos/new' }, icon('upload', 18), 'Upload with a new video'));
  let prefix = 'videos';
  const tabs = h('div', { class: 'seg', role: 'tablist' });
  const list = h('ul', { class: 'rows' });
  const more = h('div', { class: 'more' });
  body.append(tabs, h('p', { class: 'muted' }, 'Files in your ImageKit media library (this app’s folder). A file that is in use can not be deleted until it is removed from its video or profile.'), list, more);

  const paintTabs = () => {
    tabs.replaceChildren(...TABS.map(([p, label]) => h('button', { type: 'button', role: 'tab', class: p === prefix ? 'on' : '', 'aria-selected': String(p === prefix), onclick: () => { prefix = p; paintTabs(); load(true); } }, label)));
  };
  let cursor = null;

  async function load(reset) {
    if (reset) {
      cursor = null;
      list.replaceChildren(h('li', null, loading()));
      more.replaceChildren();
    }
    try {
      const res = await api.get(`/api/admin/media?prefix=${encodeURIComponent(prefix)}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
      if (!isCurrent()) return;
      if (reset) list.replaceChildren();
      if (reset && !res.objects.length) {
        list.append(h('li', null, emptyState({ title: 'No files here', text: 'Uploaded files appear in this list.' })));
        return;
      }
      res.objects.forEach((o) => list.append(row(o)));
      cursor = res.cursor;
      more.replaceChildren(cursor ? h('button', { class: 'btn', type: 'button', onclick: () => load(false) }, 'Load more') : '');
    } catch (e) {
      list.replaceChildren(h('li', null, errorState(e.message, () => load(true))));
    }
  }

  function usedBy(o) {
    if (!o.usedBy) return h('p', { class: 'muted warn-text' }, 'Not used by anything');
    if (o.usedBy.type === 'user') return h('p', { class: 'muted' }, 'Used by ', h('a', { href: '#/admin/users' }, o.usedBy.title || 'a user'), '’s profile');
    return h('p', { class: 'muted' }, 'Used by ', h('a', { href: `#/admin/videos/${o.usedBy.id}` }, o.usedBy.title));
  }

  function row(o) {
    const preview = prefix !== 'videos' && thumbSrc(o.url, 120);
    const li = h('li', { class: 'row-item wrap' },
      preview ? h('img', { class: 'row-img', src: preview, alt: '', loading: 'lazy' }) : h('div', { class: 'row-img icon-tile' }, icon('film', 22)),
      h('div', { class: 'grow' },
        h('p', { class: 'strong mono' }, o.name),
        h('p', { class: 'muted' }, `${bytes(o.size)} · ${o.contentType || 'unknown type'}${o.isPrivate ? ' · private' : ''} · ${o.uploaded ? timeAgo(new Date(o.uploaded)) : ''}`),
        usedBy(o)),
      h('div', { class: 'row-actions' }, h('button', { class: 'btn small danger', type: 'button', disabled: !!o.usedBy, title: o.usedBy ? 'In use' : 'Delete file', onclick: async () => {
        if (!(await confirmDialog({ title: 'Delete this file?', message: 'It will be permanently removed from ImageKit.', confirmLabel: 'Delete file', danger: true }))) return;
        try {
          await api.del('/api/admin/media', { fileId: o.fileId });
          li.remove();
          toast('File deleted', 'success');
        } catch (e) {
          toast(e.message, 'error');
        }
      } }, icon('trash', 16), 'Delete')));
    return li;
  }
  paintTabs();
  await load(true);
}
