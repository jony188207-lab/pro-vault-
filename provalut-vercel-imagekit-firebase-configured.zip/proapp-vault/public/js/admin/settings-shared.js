import { h } from '../lib/dom.js';
export const field = (label, id, input, hint) => h('div', { class: 'field' }, h('label', { for: id }, label), input, hint ? h('p', { class: 'hint' }, hint) : null);
export const check = (id, input, text, hint) => h('div', { class: 'field' }, h('label', { class: 'check', for: id }, input, text), hint ? h('p', { class: 'hint indent' }, hint) : null);
