// Ads: five independent banner placements, per-part unlock settings, unlock texts, notifications.
import { h, icon, toast, busy } from '../lib/dom.js';
import { api, apiBase } from '../lib/api.js';
import { loadSettings, DEFAULT_SETTINGS } from '../state.js';
import { adminPage, loading } from './layout.js';
import { errorState } from '../components.js';
import { field, check } from './settings-shared.js';

const PLACEMENTS = [
  ['home', 'Home: below the trending strip', 'Shown on the home page under Trending.'],
  ['homeBottom', 'Home: bottom of the page', 'Shown at the very end of the home page.'],
  ['listCard', 'Below video cards in lists', 'Shown between cards in Recently Added, search, categories and Saved.'],
  ['detailsBelow', 'Video details: below the content', 'Shown under the description and parts list.'],
  ['partsBottom', 'Parts / unlock screen: bottom', 'Shown at the bottom of the Select Quality / Part popup.'],
];

const TEXT_FIELDS = [
  ['partsTitle', 'Parts popup title', '', 60],
  ['howToTitle', 'How-to box title', '', 60],
  ['howToText', 'How-to box text', 'Use {seconds} for the waiting time.', 300, true],
  ['unlockTitle', 'Unlock dialog title', '', 60],
  ['unlockSubtitle', 'Unlock dialog subtitle', '', 100],
  ['unlockStep1', 'Step 1', 'Use {seconds} for the waiting time.', 200],
  ['unlockStep2', 'Step 2', '', 200],
  ['unlockWarning', 'Warning line', '', 200],
  ['openLinkButton', 'Open-link button', '', 60],
  ['verifyButton', 'Unlock button', '', 80],
  ['waitingText', 'Text while waiting', '', 200],
  ['unlockedText', 'Text after unlocking', '', 200],
  ['watchButton', 'Watch button', '', 40],
  ['downloadButton', 'Download button', '', 40],
];

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Ads and unlock flow', '/admin/ads');
  body.append(loading());
  const load = async () => {
    try {
      const { settings: s, adScriptHostsConfigured, telegramConfigured } = await api.get('/api/admin/settings');
      if (!isCurrent()) return;
      body.replaceChildren(
        h('div', { class: 'notice' }, icon('info', 18), h('p', null, 'Banner ads and unlock links are separate. A banner never unlocks anything. Each part’s unlock link is set on the part itself (Videos → edit).')),
        ...PLACEMENTS.map(([key, label, hint]) => bannerCard(key, label, hint, s.banners[key], adScriptHostsConfigured)),
        gateCard(s), notifyCard(s, telegramConfigured), textsCard(s));
    } catch (e) {
      body.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}

async function saveSettings(patch, btn, label) {
  try {
    const res = await busy(btn, () => api.put('/api/admin/settings', patch), 'Saving…');
    await loadSettings();
    res.warnings?.forEach((w) => toast(w, 'info', 7000));
    toast(label, 'success');
    return res.settings;
  } catch (e) {
    toast(e.message, 'error', 9000);
    return null;
  }
}

function bannerCard(key, label, hint, b, hostsConfigured) {
  const enabled = h('input', { type: 'checkbox', id: `b-${key}-on`, checked: b.enabled });
  const html = h('textarea', { class: 'input mono', id: `b-${key}-html`, rows: 6, spellcheck: 'false', placeholder: 'Paste your Adsterra banner code here' }, b.html || '');
  const width = h('input', { class: 'input', id: `b-${key}-w`, type: 'number', min: 50, max: 970, value: b.width });
  const height = h('input', { class: 'input', id: `b-${key}-h`, type: 'number', min: 30, max: 600, value: b.height });
  const every = key === 'listCard' ? h('input', { class: 'input', id: 'b-every', type: 'number', min: 1, max: 20, value: b.every || 4 }) : null;
  const previewHost = h('div', { class: 'banner-preview' });
  const btn = h('button', { class: 'btn primary', type: 'button' }, 'Save placement');
  const paint = (cfg) => {
    previewHost.replaceChildren();
    if (!cfg.html) return previewHost.append(h('p', { class: 'muted' }, 'No code saved yet.'));
    if (!cfg.enabled) return previewHost.append(h('p', { class: 'muted' }, 'Saved, but switched off, so visitors see nothing here.'));
    previewHost.append(h('p', { class: 'hint' }, 'Saved banner as visitors see it:'), h('iframe', { class: 'banner-frame', title: `${label} preview`, src: `${apiBase()}/api/ads/banner-frame?p=${key}&v=${Date.now()}`, width: cfg.width, height: cfg.height, sandbox: 'allow-scripts allow-popups allow-popups-to-escape-sandbox', referrerpolicy: 'no-referrer', scrolling: 'no' }));
  };
  paint(b);
  btn.addEventListener('click', async () => {
    const patch = { enabled: enabled.checked, html: html.value, width: Number(width.value), height: Number(height.value) };
    if (every) patch.every = Number(every.value);
    const saved = await saveSettings({ banners: { [key]: patch } }, btn, `${label}: saved`);
    if (saved) {
      html.value = saved.banners[key].html;
      paint(saved.banners[key]);
    }
  });
  return h('section', { class: 'card form placement' },
    h('h2', null, label),
    h('p', { class: 'muted' }, hint),
    !hostsConfigured && key === 'home' ? h('div', { class: 'notice' }, icon('alert', 18), h('p', null, 'External banner scripts stay blocked until their host is listed in the Vercel environment variable AD_SCRIPT_HOSTS (see README) and the app is redeployed.')) : null,
    check(`b-${key}-on`, enabled, 'Show this placement'),
    field('Banner code', `b-${key}-html`, html, 'Paste the code exactly as your ad network gave it. It is checked on the server and shown in an isolated sandbox.'),
    h('div', { class: 'two' }, field('Width (px)', `b-${key}-w`, width), field('Height (px)', `b-${key}-h`, height)),
    every ? field('Show a banner after every N cards', 'b-every', every, 'Fewer banners means fewer embedded frames and a faster page.') : null,
    h('div', { class: 'row' }, btn),
    previewHost);
}

function gateCard(s) {
  const g = s.gate;
  const ack = h('input', { type: 'checkbox', id: 'g-ack', checked: g.policyAcknowledged });
  const away = h('input', { class: 'input', id: 'g-away', type: 'number', min: 1, max: 120, value: g.minAwaySeconds });
  const hours = h('input', { class: 'input', id: 'g-hours', type: 'number', min: 0, max: 8760, value: g.unlockHours });
  const sess = h('input', { class: 'input', id: 'g-sess', type: 'number', min: 1, max: 240, value: g.sessionTtlMinutes });
  const def = h('input', { class: 'input', id: 'g-def', type: 'url', value: g.defaultUnlockUrl || '', placeholder: 'https://… (used by locked parts with no link of their own)' });
  const btn = h('button', { class: 'btn primary', type: 'button' }, 'Save unlock settings');
  btn.addEventListener('click', () => saveSettings({ gate: { policyAcknowledged: ack.checked, minAwaySeconds: Number(away.value), unlockHours: Number(hours.value), sessionTtlMinutes: Number(sess.value), defaultUnlockUrl: def.value.trim() } }, btn, 'Unlock settings saved'));
  return h('section', { class: 'card form' },
    h('h2', null, 'Part unlock settings'),
    h('div', { class: 'notice warn' }, icon('alert', 18), h('div', null,
      h('p', null, h('strong', null, 'What unlocking can and cannot prove.')),
      h('p', { class: 'muted' }, 'Opening a Smartlink does not prove an ad was shown or completed. By default the server only records that the link was opened and that the visitor stayed away for the minimum time. If your provider sends server-to-server postbacks, set AD_POSTBACK_SECRET and choose the postback option on a part, then the unlock waits for that confirmation. Check your ad network’s rules (Adsterra restricts incentivised clicks) before using this flow.'))),
    check('g-ack', ack, 'I checked that my ad network allows this flow', 'Required before a part can be saved as locked.'),
    h('div', { class: 'two' }, field('Minimum seconds away', 'g-away', away, 'Measured by the server. A part can override it.'), field('Unlock lasts (hours)', 'g-hours', hours, '0 = permanent for that user and part.')),
    field('Unlock session timeout (minutes)', 'g-sess', sess),
    field('Default unlock link', 'g-def', def, 'Optional fallback Smartlink for locked parts without their own.'),
    h('div', { class: 'row' }, btn));
}

function notifyCard(s, telegramConfigured) {
  const inApp = h('input', { type: 'checkbox', id: 'n-app', checked: s.notifications.inApp });
  const tg = h('input', { type: 'checkbox', id: 'n-tg', checked: s.notifications.telegram });
  const btn = h('button', { class: 'btn primary', type: 'button' }, 'Save notification settings');
  btn.addEventListener('click', () => saveSettings({ notifications: { inApp: inApp.checked, telegram: tg.checked } }, btn, 'Notification settings saved'));
  return h('section', { class: 'card form' },
    h('h2', null, 'Publish notifications'),
    check('n-app', inApp, 'Create an in-app notification when a video is published', 'One per video, never duplicated.'),
    check('n-tg', tg, 'Post to Telegram when a video is published'),
    h('p', { class: `chip ${telegramConfigured ? 'ok' : 'mute'}` }, telegramConfigured ? 'Telegram is configured on the server' : 'Telegram is not configured: set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in Vercel to enable it'),
    h('p', { class: 'muted' }, 'Telegram posts go to the one channel or group you configure. The bot token stays on the server.'),
    h('div', { class: 'row' }, btn));
}

function textsCard(s) {
  const inputs = {};
  const fields = TEXT_FIELDS.map(([key, label, hint, max, long]) => {
    const input = long ? h('textarea', { class: 'input', id: `t-${key}`, rows: 3, maxlength: max }, s.texts[key]) : h('input', { class: 'input', id: `t-${key}`, value: s.texts[key], maxlength: max });
    inputs[key] = input;
    return field(label, `t-${key}`, input, hint);
  });
  const btn = h('button', { class: 'btn primary', type: 'button' }, 'Save texts');
  const reset = h('button', { class: 'btn ghost', type: 'button' }, 'Restore defaults');
  reset.addEventListener('click', () => { for (const [k, i] of Object.entries(inputs)) i.value = DEFAULT_SETTINGS.texts[k]; });
  btn.addEventListener('click', () => saveSettings({ texts: Object.fromEntries(Object.entries(inputs).map(([k, i]) => [k, i.value])) }, btn, 'Texts saved'));
  return h('section', { class: 'card form' }, h('h2', null, 'Popup texts'), h('p', { class: 'muted' }, 'Any language works. Keep wording honest: the step does not verify an ad was watched.'), ...fields, h('div', { class: 'row' }, btn, reset));
}
