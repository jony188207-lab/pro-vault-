// Browser side of media uploads.
//
//   1. Ask our API for upload parameters: POST /api/admin/uploads/auth (admin only). The API generates the one-time
//      token, expiry and signature with the ImageKit PRIVATE key, which never reaches the browser.
//   2. POST the file straight to ImageKit with those parameters (large videos never pass through our server).
//   3. Send only the returned fileId to the API when saving the video; the API re-reads the file from ImageKit and
//      stores the URLs itself.
import { api, ApiError } from '../lib/api.js';

const VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export function describeFile(file, kind) {
  const allowed = kind === 'video' ? VIDEO_TYPES : IMAGE_TYPES;
  if (!allowed.includes(file.type)) return `Unsupported file type. Use ${allowed.map((t) => t.split('/')[1].toUpperCase()).join(', ')}.`;
  return null;
}

function postToImageKit(auth, file, onProgress, signal) {
  return new Promise((resolve, reject) => {
    const form = new FormData();
    form.append('file', file, auth.fileName);
    form.append('fileName', auth.fileName);
    form.append('publicKey', auth.publicKey);
    form.append('signature', auth.signature);
    form.append('expire', String(auth.expire));
    form.append('token', auth.token);
    form.append('folder', auth.folder);
    form.append('useUniqueFileName', String(auth.useUniqueFileName));
    form.append('isPrivateFile', String(auth.isPrivateFile));
    const xhr = new XMLHttpRequest();
    xhr.open('POST', auth.uploadUrl);
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress?.(e.loaded / e.total);
    xhr.onerror = () => reject(new ApiError(0, 'network', 'Upload interrupted. Check your connection.'));
    xhr.onabort = () => reject(new ApiError(0, 'aborted', 'Upload cancelled.'));
    xhr.onload = () => {
      let data = null;
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        /* not JSON */
      }
      if (xhr.status >= 200 && xhr.status < 300 && data?.fileId) resolve(data);
      else reject(new ApiError(xhr.status, 'imagekit', `ImageKit refused the upload: ${data?.message || `error ${xhr.status}`}`));
    };
    signal?.addEventListener('abort', () => xhr.abort(), { once: true });
    xhr.send(form);
  });
}

/** Upload one file to ImageKit and return its fileId. A token can be used once, so every attempt asks for a fresh one. */
export async function uploadMedia(file, kind, onProgress, signal) {
  const problem = describeFile(file, kind);
  if (problem) throw new ApiError(400, 'unsupported_type', problem);
  for (let attempt = 1; ; attempt++) {
    if (signal?.aborted) throw new ApiError(0, 'aborted', 'Upload cancelled.');
    const auth = await api.post('/api/admin/uploads/auth', { kind, contentType: file.type, size: file.size });
    try {
      const res = await postToImageKit(auth, file, onProgress, signal);
      onProgress?.(1);
      return res.fileId;
    } catch (e) {
      if (e.code !== 'network' || attempt >= 3) throw e;
      await new Promise((r) => setTimeout(r, 800 * attempt));
    }
  }
}

export const uploadVideo = (file, onProgress, signal) => uploadMedia(file, 'video', onProgress, signal);
export const uploadThumbnail = (file, onProgress, signal) => uploadMedia(file, 'thumbnail', onProgress, signal);

/** Read duration (seconds) from a local video file without uploading it. */
export function readDuration(file) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    const url = URL.createObjectURL(file);
    const done = (val) => {
      URL.revokeObjectURL(url);
      resolve(val);
    };
    v.preload = 'metadata';
    v.onloadedmetadata = () => done(Number.isFinite(v.duration) ? Math.round(v.duration) : 0);
    v.onerror = () => done(0);
    v.src = url;
  });
}
