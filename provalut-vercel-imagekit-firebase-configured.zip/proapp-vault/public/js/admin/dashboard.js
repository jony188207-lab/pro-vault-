import { h, compact, timeAgo, toast } from '../lib/dom.js';
import { api } from '../lib/api.js';
import { adminPage, loading, stat, barChart } from './layout.js';
import { errorState, avatar } from '../components.js';

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Dashboard', '/admin');
  body.append(loading());
  const load = async () => {
    try {
      const d = await api.get('/api/admin/dashboard');
      if (!isCurrent()) return;
      const t = d.totals;
      body.replaceChildren(
        h('div', { class: 'stats' },
          stat('Registered users', compact(t.users), 'users', t.suspendedUsers ? `${t.suspendedUsers} suspended` : undefined),
          stat('Videos', compact(t.videos), 'film'),
          stat('Total views', compact(t.views), 'eye'),
          stat('Likes', compact(t.likes), 'heart'),
          stat('Comments', compact(t.comments), 'comment'),
          stat('Saved videos', compact(t.saves), 'bookmark'),
          stat('Downloads', compact(t.downloads), 'download')),
        h('h2', { class: 'section-title' }, 'Last 14 days'),
        h('div', { class: 'charts' },
          barChart(d.daily.map((x) => ({ label: x.day?.slice(5), value: x.views || 0 })), { title: 'Views' }),
          barChart(d.daily.map((x) => ({ label: x.day?.slice(5), value: x.signups || 0 })), { title: 'New users', color: 'var(--teal)' })),
        h('h2', { class: 'section-title' }, 'Recently active users'),
        d.recentUsers.length
          ? h('ul', { class: 'rows' }, d.recentUsers.map((u) => h('li', { class: 'row-item' }, avatar(u.displayName, u.photoURL, { 'aria-hidden': 'true' }), h('div', { class: 'grow' }, h('p', { class: 'strong' }, u.displayName, u.role === 'admin' ? h('span', { class: 'chip' }, 'admin') : null, u.status === 'suspended' ? h('span', { class: 'chip warn' }, 'suspended') : null), h('p', { class: 'muted' }, u.email)), h('time', { class: 'muted' }, timeAgo(u.lastActiveAt)))))
          : h('p', { class: 'muted' }, 'No activity yet.'));
    } catch (e) {
      body.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}
