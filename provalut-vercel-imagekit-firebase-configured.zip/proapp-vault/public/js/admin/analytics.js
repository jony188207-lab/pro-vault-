import { h, compact, timeAgo, fullDate } from '../lib/dom.js';
import { api } from '../lib/api.js';
import { adminPage, loading, barChart } from './layout.js';
import { errorState, emptyState } from '../components.js';

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Analytics', '/admin/analytics');
  body.append(loading());
  const load = async () => {
    try {
      const a = await api.get('/api/admin/analytics');
      if (!isCurrent()) return;
      const series = (key) => a.daily.map((d) => ({ label: d.day?.slice(5), value: d[key] || 0 }));
      const table = (rows, key, title) =>
        h('section', { class: 'card' }, h('h2', null, title), rows.length ? h('ol', { class: 'rank-list' }, rows.map((v) => h('li', null, h('a', { href: `#/admin/videos/${v.id}` }, v.title), h('strong', null, compact(v[key]))))) : h('p', { class: 'muted' }, 'No data yet.'));
      body.replaceChildren(
        h('h2', { class: 'section-title' }, 'Last 30 days'),
        h('div', { class: 'charts' }, barChart(series('views'), { title: 'Views' }), barChart(series('likes'), { title: 'Likes', color: 'var(--rose)' }), barChart(series('comments'), { title: 'Comments', color: 'var(--teal)' }), barChart(series('signups'), { title: 'New users', color: 'var(--sky)' })),
        h('div', { class: 'two' }, table(a.topByViews, 'views', 'Most viewed'), table(a.topByLikes, 'likes', 'Most liked')),
        h('h2', { class: 'section-title' }, 'Recent admin activity'),
        a.auditLog.length
          ? h('ul', { class: 'rows' }, a.auditLog.map((l) => h('li', { class: 'row-item wrap' }, h('div', { class: 'grow' }, h('p', { class: 'strong' }, l.action), h('p', { class: 'muted' }, `${l.actorEmail || l.actorUid} · ${l.target}`)), h('time', { class: 'muted', title: fullDate(l.createdAt) }, timeAgo(l.createdAt)))))
          : emptyState({ title: 'No activity recorded yet' }));
    } catch (e) {
      body.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}
