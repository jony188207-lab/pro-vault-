# ProApp Vault

A mobile-first dark video streaming web app, deployed on **Vercel**, with **ImageKit** for media and **Firebase** for accounts and data.

| Part | Tech | Where |
| --- | --- | --- |
| Frontend | HTML, CSS, JavaScript (ES modules, no framework) | `public/` |
| Accounts | Firebase Authentication (email + password) | `public/js/lib/firebase.js` |
| App data | Cloud Firestore (users, video metadata, likes, comments, saves, views, settings) | rules in `firestore.rules` |
| API + admin backend | Vercel Function (Node), one entry file | `api/index.js` -> `server/src/` |
| Media (videos, thumbnails, profile photos) | ImageKit, behind a swappable **Storage Adapter** | `server/src/storage/` |

Cloudflare R2 and Cloudflare Workers are **no longer used or required**.

## Status: read this first

Nothing here has been run against real Firebase, ImageKit or Vercel accounts, and no credentials are included. Everything below was tested only against in-memory stand-ins written for this project, so they can differ from the real services.

**Verified (against the stand-ins):**

* `node --test test/*.test.js` passes 38 tests: token verification, ownership and admin checks, ImageKit upload-auth (signature recomputed independently), server-side verification of uploaded files, private signed playback URLs (valid, tampered, expired-extended and unsigned requests), range requests, avatar upload/replace/remove, media-manager protection (files in use, files outside the app folder), like/save/comment rules, the ad-unlock flow, server-side view counting, banner sanitising, suspension, cascade deletion, a lint of `firestore.rules`, and static checks (`vercel.json`, CSP, no secrets under `public/`, no old-provider leftovers, every frontend import/asset path exists, `api/index.js` entry).
* `node test/e2e.mjs`: a 42-step Chromium run on a phone-size screen. The frontend and `/api` are served from **one origin through `api/index.js`**, with the production CSP from `vercel.json`. It covers sign-up/login, admin setup, uploading a video and thumbnail **directly to ImageKit** from the admin UI, the lock/unlock/watch flow with a signed ImageKit URL and a range request, likes, comments, saves, search, profile photo upload, the media manager, and cascade delete. No console errors or CSP violations.

**Not verified - you must test these after deploying:**

* Any call to the real ImageKit (upload, Media API, CDN, signed URLs). In particular **whether your ImageKit plan supports private files / signed URLs** is unconfirmed (see "Private videos" below).
* The real Vercel runtime: the `/api/*` rewrite, the `export default { fetch }` function entry, environment variables, and the build step.
* `firestore.rules` were only linted, not run. Run them in the Firebase emulator (see "Testing the security rules").
* Real Firebase Auth behaviour (email verification mail, password reset), and real Adsterra banners.
* Playback and upload of a real, large video.
* The signature algorithms follow ImageKit's documentation as I read it; I could not confirm them with an official test vector. The mock re-implements the same documented rules, so passing tests do not prove ImageKit accepts them.

## A note on the "ad before watching" feature

Adsterra's publisher terms (section 6, as I read them) prohibit using incentives to increase impressions or clicks, and prohibit forcing or confusing visitors into taking an action. Gating content behind an ad may fall under that, and other networks have similar rules. So:

* The feature is **off by default**, and the admin must tick "I checked that my ad network allows this flow" before it can be turned on.
* The app **never claims an ad was watched**. What the server can prove is: the sponsor link was issued to this user, at least N seconds passed (measured by the server), and, only if your provider sends server-to-server postbacks, that the provider confirmed (`verification: postback`).
* The wording is yours to edit in Admin -> Ads. Check your ad network's rules.

## Setup, step by step

You need: a Google account (Firebase), an ImageKit account, a Vercel account, and this folder in a Git repository (GitHub, GitLab or Bitbucket) or the Vercel CLI.

### 1. Firebase

1. Create a project at <https://console.firebase.google.com>.
2. **Build -> Authentication -> Get started -> Email/Password -> Enable.**
3. **Build -> Firestore Database -> Create database** (production mode, a region near your users).
4. Deploy the rules and indexes from this folder:
   ```
   npm install -g firebase-tools
   firebase login
   firebase use --add          # choose your project
   firebase deploy --only firestore:rules,firestore:indexes
   ```
   Wait until the indexes show "Enabled" (Firestore -> Indexes). Until then the home list and search show a "needs an index" message.
5. **Project settings -> General -> Your apps -> Web app (`</>`)**: copy `apiKey` (-> `FIREBASE_API_KEY`) and `projectId` (-> `FIREBASE_PROJECT_ID`). Both are public by design.
6. **Project settings -> Service accounts -> Generate new private key.** This downloads a JSON file. It is a **secret**. Its whole content goes into the Vercel variable `FIREBASE_SERVICE_ACCOUNT_JSON` (step 3) and nowhere else. Never commit it or put it in the frontend.
7. **Authentication -> Settings -> Authorized domains:** add your Vercel domain (after step 4 you will know it, e.g. `your-app.vercel.app`, plus any custom domain).

### 2. ImageKit

1. Sign up at <https://imagekit.io>. In **Dashboard -> Developer options** (or "API keys") copy:
   * **URL endpoint**, like `https://ik.imagekit.io/your_imagekit_id` -> `IMAGEKIT_URL_ENDPOINT`
   * **Public key** -> `IMAGEKIT_PUBLIC_KEY`
   * **Private key** -> `IMAGEKIT_PRIVATE_KEY` (**secret**, server only)
2. Nothing else has to be created. The API puts files in the folder `/proapp-vault` (`videos`, `thumbs`, `avatars`; change the name with `IMAGEKIT_FOLDER`).
3. **Check your plan's limits.** At the time of writing ImageKit lists a maximum video file size of 100 MB on the free plan (larger on paid plans). `MAX_VIDEO_BYTES` defaults to 100 MB; raise it only if your plan allows more. Check ImageKit's pricing page for current numbers.
4. **Private videos (default).** Videos are uploaded as *private files* and are playable only through a signed URL that the API issues after the ad-gate check (valid 6 hours). I could not confirm that private files and signed URLs are available on every ImageKit plan. If uploads of videos are rejected with `not_private`, or private playback fails, either upgrade the plan or set `IMAGEKIT_PRIVATE_VIDEOS=false`. **Consequence of `false`:** videos become public URLs, so anyone with a video's link can play it, and the unlock/ad gate can no longer protect the file itself (it still controls the app's UI). Thumbnails and profile photos are always public.
5. If you use a **custom ImageKit domain** (CNAME) instead of `ik.imagekit.io`, change `https://ik.imagekit.io` in the Content-Security-Policy in `vercel.json` to your domain.

### 3. Vercel

1. Push this folder to a Git repository and **Add New -> Project** in Vercel, importing it. Leave "Framework Preset" as *Other*. `vercel.json` already sets the build command (`node scripts/generate-config.mjs`), the output directory (`public`) and the `/api/*` routing. No install step is needed (no npm dependencies).
2. Before the first deploy, open **Settings -> Environment Variables** and add (for Production, and Preview if you use it):

| Variable | Required | Secret | Meaning |
| --- | --- | --- | --- |
| `FIREBASE_API_KEY` | yes | no | Firebase web API key. Used at build time to write `public/js/config.js`. |
| `FIREBASE_PROJECT_ID` | yes | no | Firebase project id (build time and server). |
| `FIREBASE_SERVICE_ACCOUNT_JSON` | yes | **yes** | Whole service-account JSON (pasted as is, or base64 of it). |
| `IMAGEKIT_URL_ENDPOINT` | yes | no | `https://ik.imagekit.io/your_imagekit_id` |
| `IMAGEKIT_PUBLIC_KEY` | yes | no | ImageKit public key (returned to the admin's browser with each signed upload token). |
| `IMAGEKIT_PRIVATE_KEY` | yes | **yes** | ImageKit private key. Never in the frontend. |
| `BOOTSTRAP_ADMIN_EMAILS` | yes | no | Comma-separated e-mails that become admin once verified. |
| `AD_SCRIPT_HOSTS` | for banners | no | Comma-separated hosts allowed in banner `<script src>` (e.g. your Adsterra host). |
| `MAX_VIDEO_BYTES` | no | no | Default 104857600 (100 MB). |
| `IMAGEKIT_FOLDER` | no | no | Default `proapp-vault`. |
| `IMAGEKIT_PRIVATE_VIDEOS` | no | no | Default `true`. See step 2.4. |
| `AD_POSTBACK_SECRET` | no | **yes** | Only if your ad provider sends server-to-server postbacks. |
| `ALLOWED_ORIGINS` | no | no | Only if a different origin calls the API. Not needed for the normal same-origin setup. |

   Mark the secret ones as **Sensitive** in Vercel. See `.env.example` for the names. Only `FIREBASE_API_KEY`, `FIREBASE_PROJECT_ID` and `IMAGEKIT_URL_ENDPOINT` are copied into the frontend (`public/js/config.js`) by the build; the build script never reads any other variable. If you leave `FIREBASE_API_KEY` unset, the build keeps `public/js/config.js` as committed, so you can also edit that file by hand with the same three public values.
3. **Deploy.** Variables are applied at build time for the config, so after changing any of the three public ones, redeploy.
4. Check `https://YOUR-DOMAIN/api/health` returns `{"ok":true,...}`, and add the domain to Firebase authorized domains (step 1.7).

### 4. First run

1. Open the site, **Create account** with the e-mail from `BOOTSTRAP_ADMIN_EMAILS`.
2. Verify the e-mail (Profile -> "Send verification email", click the link, then "I verified it"). Admin rights are only granted for a verified address.
3. An **Admin** tab appears. Go to Videos -> Add video, choose a video file and a thumbnail. The browser uploads them directly to ImageKit using a token the API signed; then the video is saved with its ImageKit URLs.
4. Admin -> Settings and Ads: site texts, list sizes, banner, and (optionally) the sponsor step.

### Allow your ad network (Adsterra banner)

1. In Adsterra, create a banner and copy its code: `<script>atOptions = {...};</script><script src="https://HOST/KEY/invoke.js"></script>`.
2. Put `HOST` in `AD_SCRIPT_HOSTS` in Vercel and redeploy.
3. Paste the code in Admin -> Ads -> Banner. The server checks it and the app shows it in a sandboxed iframe served by `/api/ads/banner-frame`.

## How media works

* **Upload (admin, videos and thumbnails):** the browser asks `POST /api/admin/uploads/auth` (admin only, type and size validated). The API returns `token`, `expire`, `signature` (HMAC-SHA1 of `token + expire` with the private key), the public key, the target folder and the file name. The browser POSTs the file straight to ImageKit (this avoids Vercel's 4.5 MB request limit). It then sends only the ImageKit **file id** to `POST /api/admin/videos`. The server looks the file up through ImageKit's Media API (existence, folder, size, type, private flag, not used by another video) and builds the stored URL itself from `IMAGEKIT_URL_ENDPOINT` + file path. URLs sent by a browser are never trusted. Oversize files are deleted.
* **Playback:** `POST /api/videos/:id/play` (signed-in user) counts the view on the server and returns a signed ImageKit URL (`ik-t`/`ik-s`, 6 hours) for private videos.
* **Profile photos:** the browser crops to a 512 px JPEG and sends it to `POST /api/me/avatar`; the server checks type, size (2 MB) and magic bytes, uploads it to ImageKit and stores `photoURL`. Replaced and removed photos are deleted from ImageKit, as are photos of deleted accounts.
* **Thumbnails and avatars** are displayed with ImageKit transformations (`?tr=w-...`), only for URLs under your configured endpoint.
* **Admin media manager:** lists the app's folders in ImageKit, shows what uses each file, and deletes only unused files inside the app folder.

## How it is secured

* **Browsers can read some Firestore data but never write it.** Every `allow write` in `firestore.rules` is `false`. Profiles, roles, views, likes, saves, comments, unlocks, settings and video metadata are all written by the API with the service account.
* **The API re-checks everything.** It verifies the Firebase ID token (signature, issuer, audience, expiry), then loads the profile from Firestore. Role and status come from that profile, never from the request, so a demotion or suspension applies immediately.
* **No privilege escalation:** a user cannot write their own profile; admins cannot change their own role; the first admin comes only from a verified e-mail in `BOOTSTRAP_ADMIN_EMAILS`.
* **Secrets:** `IMAGEKIT_PRIVATE_KEY` and the Firebase service account exist only as Vercel environment variables, read by the server. Tests assert that no API response contains them and that nothing under `public/` does.
* **Views are counted on the server** (once per user per video per 30 minutes). **One like per user per video** is enforced by document id `<uid>_<videoId>` plus a "must not exist" precondition.
* **Comments:** only the author or an admin can delete; rate-limited; shown as text.
* **Admin HTML (banner):** tag allowlist; `<script src>` must be https and on `AD_SCRIPT_HOSTS`; inline scripts may only assign `atOptions = {...}`; shown in a sandboxed iframe with its own CSP.
* **Suspension** sets the profile status and disables the Firebase Auth account. **Account deletion** needs a login from the last 5 minutes and removes the user's data and photo.

Remaining risks: Firebase email/password sign-in has no CAPTCHA by default (consider App Check); a leaked signed video URL works until it expires (6 hours); with `IMAGEKIT_PRIVATE_VIDEOS=false` video URLs are public; ad scripts you allow run in their own sandbox but can show whatever that network serves.

## Database structure

| Collection | Document id | Fields | Browser access |
| --- | --- | --- | --- |
| `users` | Firebase uid | email, displayName, photoURL, photoFileId, role, status, emailVerified, createdAt, lastActiveAt | own profile read only |
| `videos` | uuid | title, description, tags, status, **videoFileId, videoUrl, videoPath, videoPrivate, thumbnailFileId, thumbnailUrl, thumbnailPath**, durationSec, sizeBytes, contentType, ad{enabled,url,verification,minAwaySeconds,label}, views, likes, commentsCount, savesCount, searchTokens, createdAt, updatedAt | read published |
| `comments` | uuid | videoId, uid, authorName, authorPhoto, text, createdAt | read |
| `likes` | `<uid>_<videoId>` | uid, videoId, createdAt | read own |
| `saves` | `<uid>_<videoId>` | uid, videoId, createdAt | read own |
| `views` | `<uid>_<videoId>` | uid, videoId, lastViewAt | none |
| `adSessions` | uuid | uid, videoId, purpose, status, verification, minAwaySeconds, openedAt, expiresAt | none |
| `unlocks` | `<uid>_<videoId>_<watch\|save>` | uid, videoId, purpose, expiresAt, unlockedAt | none |
| `settings` | `public` | siteName, tagline, popularCount, homeListLimit, allowSignups, commentsEnabled, banner, gate, texts | read |
| `stats` | `d_YYYYMMDD` | day, views, likes, comments, signups | admin read |
| `auditLogs` | uuid | actorUid, action, target, meta, createdAt | admin read |

Changes from the R2 version: `videoKey`/`thumbnailKey` were replaced by the ImageKit fields above, and users/comments gained photo fields. Because the R2 version was never deployed, no migration was written. If you did store data with the old fields, those videos would need their media re-uploaded.

## API reference

Authenticated routes need `Authorization: Bearer <Firebase ID token>`. All paths are under `/api` on the same origin.

| Method + path | Who | Purpose |
| --- | --- | --- |
| `GET /api/health` | public | liveness |
| `POST /api/session` | signed in | create/refresh profile after login |
| `PATCH /api/me`, `DELETE /api/me` | user | rename; delete account |
| `POST /api/me/avatar` (raw image body), `DELETE /api/me/avatar` | user | set / remove profile photo |
| `GET /api/videos/:id/state` | user | liked/saved and unlock status |
| `POST /api/videos/:id/like` `{liked}` | user | like/unlike |
| `POST /api/videos/:id/save` `{saved}` | user | save/unsave (needs save unlock if gated) |
| `POST /api/videos/:id/comments` `{text}` | user | add comment |
| `DELETE /api/comments/:id` | author or admin | delete comment |
| `POST /api/videos/:id/play` | user | playback URL (signed if private) + server-side view count |
| `POST /api/ads/start`, `POST /api/ads/complete` | user | sponsor step |
| `GET/POST /api/ads/postback?sid&secret` | ad provider | server-to-server confirmation |
| `GET /api/ads/banner-frame` | public | sandboxed banner document |
| `POST /api/admin/uploads/auth` `{kind,contentType,size}` | admin | ImageKit upload token, expire, signature |
| `GET/DELETE /api/admin/media` | admin | list / delete ImageKit files |
| `/api/admin/*` (dashboard, analytics, users, videos, settings) | admin | management |

## Changing the storage provider

Implement the methods listed at the top of `server/src/storage/index.js` in a new class, register it in `PROVIDERS` and set `STORAGE_PROVIDER`. The rest of the code only calls the adapter.

## Testing

```
node --test test/*.test.js     # API, rules lint, project checks; no dependencies
node test/e2e.mjs              # browser run; needs Playwright with Chromium installed
```

`test/mock-backend.js` and `test/mock-imagekit.js` are in-memory re-implementations of Firestore, Firebase Auth, Google OAuth and ImageKit, so they can differ from the real services.

### Testing the security rules

Before launch, run the rules against the emulator (for example with `@firebase/rules-unit-testing`, `firebase emulators:exec --only firestore "npm test"`). Cases worth asserting: a signed-in user cannot write to any collection; cannot read another user's `users/{uid}`, `likes` or `saves`; cannot read `views`, `unlocks`, `adSessions`; the public can read `published` videos but not drafts; an admin can read drafts, `stats` and `auditLogs`.

## Troubleshooting

| Symptom | Likely cause |
| --- | --- |
| "Setup needed" screen | `public/js/config.js` still has placeholders: set `FIREBASE_API_KEY`, `FIREBASE_PROJECT_ID`, `IMAGEKIT_URL_ENDPOINT` in Vercel and redeploy |
| Build fails with "Missing Environment Variable(s)" | `FIREBASE_API_KEY` is set but one of the other two public values is not |
| `/api/...` returns 500 about missing variables | a server variable (`FIREBASE_SERVICE_ACCOUNT_JSON`, `IMAGEKIT_*`) is missing; redeploy after adding |
| Upload fails in the browser | check the CSP in `vercel.json` allows `https://upload.imagekit.io`; check `MAX_VIDEO_BYTES` and your ImageKit plan's file-size limit; the browser console shows ImageKit's message |
| Video create fails with `not_private` | your ImageKit plan ignored the private flag; see "Private videos" |
| Thumbnails or video blocked | custom ImageKit domain not added to the CSP in `vercel.json` |
| "The database needs an index" | indexes not deployed or still building |
| No Admin tab | e-mail not verified, or not in `BOOTSTRAP_ADMIN_EMAILS`, or the account existed before it was set (an admin can promote you in Users) |
| Sign-in blocked | the Vercel domain is not in Firebase authorized domains |
| Banner save refused: "host not allowed" | add the host to `AD_SCRIPT_HOSTS` and redeploy |
