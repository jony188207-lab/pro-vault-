// ProApp Vault - application shell: header, search, navigation, routing.
import { h, icon, debounce, toast, clear } from './lib/dom.js';
import * as fb from './lib/firebase.js';
import { state, subscribe, loadSettings, establishSession, isAdmin, logout, rememberReturn } from './state.js';
import { route, startRouter, parseHash, navigate } from './router.js';
import { logoMark, errorState, emptyState, avatar } from './components.js';

const cfg = window.PROAPP_CONFIG;
const root = document.getElementById('app');

const looksUnconfigured = () => /REPLACE/.test(cfg.firebase.apiKey + cfg.firebase.projectId + (cfg.imagekit?.urlEndpoint || 'REPLACE') + (cfg.apiBase || ''));

// ---------------------------------------------------------------- routes
const authView = (mode) => () => import('./views/auth.js').then((m) => ({ render: (c) => m.render({ ...c, params: { mode } }) }));
route('/', () => import('./views/home.js'));
route('/v/:id', () => import('./views/video.js'));
route('/login', authView('login'));
route('/signup', authView('signup'));
route('/reset', authView('reset'));
route('/saved', () => import('./views/saved.js'), { auth: true });
route('/profile', () => import('./views/profile.js'), { auth: true });
route('/admin', () => import('./admin/dashboard.js'), { admin: true });
route('/admin/users', () => import('./admin/users.js'), { admin: true });
route('/admin/videos', () => import('./admin/videos.js'), { admin: true });
route('/admin/videos/new', () => import('./admin/video-form.js'), { admin: true });
route('/admin/videos/:id', () => import('./admin/video-form.js'), { admin: true });
route('/admin/media', () => import('./admin/media.js'), { admin: true });
route('/admin/ads', () => import('./admin/ads.js'), { admin: true });
route('/admin/analytics', () => import('./admin/analytics.js'), { admin: true });
route('/admin/settings', () => import('./admin/settings.js'), { admin: true });

// ---------------------------------------------------------------- shell
const searchInput = h('input', { class: 'search-input', type: 'search', name: 'q', placeholder: 'Search videos', 'aria-label': 'Search videos', autocomplete: 'off', enterkeyhint: 'search', maxlength: 80 });
const searchForm = h('form', { class: 'search', role: 'search' }, icon('search', 18), searchInput);
const goSearch = () => {
  const q = searchInput.value.trim();
  navigate(q ? `#/?q=${encodeURIComponent(q)}` : '#/');
};
searchForm.addEventListener('submit', (e) => {
  e.preventDefault();
  goSearch();
});
searchInput.addEventListener('input', debounce(() => {
  if (searchInput.value.trim().length >= 2 || !searchInput.value.trim()) goSearch();
}, 450));

const brand = h('a', { class: 'brand', href: '#/', 'aria-label': 'ProApp Vault home' }, logoMark(30), h('span', { class: 'brand-name' }, 'ProApp Vault'));
const accountSlot = h('div', { class: 'account-slot' });
const header = h('header', { class: 'topbar' }, h('div', { class: 'topbar-in' }, brand, searchForm, accountSlot));
const nav = h('nav', { class: 'tabs', 'aria-label': 'Main' });
const main = h('main', { id: 'main', tabindex: '-1' });
root.replaceChildren(header, main, nav);

function paintChrome() {
  const logged = !!state.user;
  const items = [
    ['/', 'home', 'Home'],
    ['/saved', 'bookmark', 'Saved', true],
    logged ? ['/profile', 'user', 'Profile'] : ['/login', 'user', 'Log in'],
    ...(isAdmin() ? [['/admin', 'shield', 'Admin']] : []),
  ];
  const path = parseHash().path;
  clear(nav);
  for (const [to, ic, label] of items) {
    const active = to === '/' ? path === '/' : path.startsWith(to) || (to === '/login' && (path === '/signup' || path === '/reset'));
    nav.append(h('a', { href: `#${to}`, class: active ? 'tab active' : 'tab', 'aria-current': active ? 'page' : undefined }, icon(ic, 22), h('span', null, label)));
  }
  clear(accountSlot);
  if (logged) accountSlot.append(avatar(state.user.displayName, state.user.photoURL, { href: '#/profile', 'aria-label': 'Your profile', title: state.user.displayName }, 'a'));
  else accountSlot.append(h('a', { class: 'btn small primary', href: '#/login' }, 'Log in'));
  brand.querySelector('.brand-name').textContent = state.settings.siteName;
}

subscribe(paintChrome);

function notFound(host, err) {
  host.replaceChildren(err ? errorState('This page could not be loaded. Check your connection and try again.', () => location.reload()) : emptyState({ title: 'Page not found', text: 'That link does not lead anywhere.', action: h('a', { class: 'btn primary', href: '#/' }, 'Go home') }));
  host.firstChild?.classList.add('page');
}

const run = startRouter({
  root: main,
  notFound,
  guard(opts, path) {
    if (opts.auth && !state.user) {
      rememberReturn(`#${path}`);
      return '#/login';
    }
    if (opts.admin && !isAdmin()) return state.user ? '#/' : (rememberReturn(`#${path}`), '#/login');
    return null;
  },
  onRoute(path) {
    paintChrome();
    document.title = state.settings.siteName;
    const q = parseHash().query.q || '';
    if (path === '/' && document.activeElement !== searchInput) searchInput.value = q;
    if (path !== '/' && document.activeElement !== searchInput) searchInput.value = '';
    main.dataset.section = path.startsWith('/admin') ? 'admin' : 'app';
  },
});

// ---------------------------------------------------------------- boot
async function boot() {
  if (looksUnconfigured()) {
    main.replaceChildren(h('div', { class: 'page narrow' }, h('div', { class: 'state state-error' }, h('h2', null, 'Setup needed'), h('p', null, 'Set FIREBASE_API_KEY, FIREBASE_PROJECT_ID and IMAGEKIT_URL_ENDPOINT in your Vercel Environment Variables (or edit public/js/config.js) and redeploy. The README lists every step.'))));
    return;
  }
  main.replaceChildren(h('div', { class: 'boot' }, h('div', { class: 'spinner', role: 'status', 'aria-label': 'Loading' })));
  await loadSettings();
  try {
    const session = await fb.restoreSession();
    if (session) await establishSession();
  } catch (e) {
    toast(e.message, 'error');
  }
  state.ready = true;
  fb.onAuthChange((s) => {
    if (!s && state.user) {
      logout();
      toast('You were logged out. Log in again to continue.', 'info');
      if (location.hash.startsWith('#/admin') || location.hash.startsWith('#/profile') || location.hash.startsWith('#/saved')) navigate('#/login');
    }
  });
  paintChrome();
  run();
}

boot();
