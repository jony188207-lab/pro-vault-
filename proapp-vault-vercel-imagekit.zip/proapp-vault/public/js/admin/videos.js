import { h, icon, toast, dialog, compact, timeAgo } from '../lib/dom.js';
import { api } from '../lib/api.js';
import { adminPage, loading } from './layout.js';
import { thumb, emptyState, errorState } from '../components.js';

export async function render({ root, isCurrent }) {
  const body = adminPage(root, 'Videos', '/admin/videos', h('a', { class: 'btn primary', href: '#/admin/videos/new' }, icon('plus', 18), 'Add video'));
  const list = h('ul', { class: 'rows' });
  const more = h('div', { class: 'more' });
  body.append(list, more);
  let offset = 0;
  const PAGE = 25;

  async function load(reset) {
    if (reset) {
      offset = 0;
      list.replaceChildren(h('li', null, loading()));
      more.replaceChildren();
    }
    try {
      const res = await api.get(`/api/admin/videos?limit=${PAGE}&offset=${offset}`);
      if (!isCurrent()) return;
      if (reset) list.replaceChildren();
      if (reset && !res.videos.length) {
        list.append(h('li', null, emptyState({ title: 'No videos yet', text: 'Upload a video file and publish it.', action: h('a', { class: 'btn primary', href: '#/admin/videos/new' }, 'Add your first video') })));
        return;
      }
      res.videos.forEach((v) => list.append(row(v)));
      offset += PAGE;
      more.replaceChildren(res.hasMore ? h('button', { class: 'btn', type: 'button', onclick: () => load(false) }, 'Load more') : '');
    } catch (e) {
      list.replaceChildren(h('li', null, errorState(e.message, () => load(true))));
    }
  }

  function row(v) {
    const li = h('li', { class: 'row-item wrap' },
      h('div', { class: 'row-thumb' }, thumb(v)),
      h('div', { class: 'grow' },
        h('p', { class: 'strong' }, v.title, h('span', { class: `chip ${v.status === 'published' ? 'ok' : 'mute'}` }, v.status), v.ad?.enabled ? h('span', { class: 'chip' }, 'ad assigned') : null),
        h('p', { class: 'muted' }, `${compact(v.views)} views · ${compact(v.likes)} likes · ${compact(v.commentsCount)} comments · ${compact(v.savesCount)} saves`),
        h('p', { class: 'muted small-print' }, v.createdAt ? `Added ${timeAgo(v.createdAt)}` : '')),
      h('div', { class: 'row-actions' },
        h('a', { class: 'btn small', href: `#/admin/videos/${v.id}` }, icon('edit', 16), 'Edit'),
        h('a', { class: 'btn small', href: `#/v/${v.id}` }, 'View'),
        h('button', { class: 'btn small danger', type: 'button', onclick: () => remove(v, li) }, icon('trash', 16), 'Delete')));
    return li;
  }

  function remove(v, li) {
    const withMedia = h('input', { type: 'checkbox', id: 'dm' });
    dialog({
      title: `Delete “${v.title}”?`,
      body: h('div', { class: 'form' }, h('p', null, 'The video, its likes, saves and comments will be removed.'), h('label', { class: 'check', for: 'dm' }, withMedia, 'Also delete the video and thumbnail files from storage')),
      actions: [
        { label: 'Cancel', onClick: (close) => close() },
        {
          label: 'Delete video',
          kind: 'danger',
          onClick: async (close) => {
            try {
              let res;
              do {
                res = await api.del(`/api/admin/videos/${v.id}${withMedia.checked ? '?deleteMedia=1' : ''}`);
              } while (res.cleanupPending);
              li.remove();
              close();
              toast('Video deleted', 'success');
            } catch (e) {
              toast(e.message, 'error');
            }
          },
        },
      ],
    });
  }
  await load(true);
}
