// Shared UI components.
import { h, icon, compact, duration } from './lib/dom.js';
import { apiBase } from './lib/api.js';
import { avatarSrc, thumbSrc } from './lib/media.js';

export function logoMark(size = 28) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 32 32');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('aria-hidden', 'true');
  // vault dial: outer ring, 12 tick marks, play wedge as the "keyhole"
  const ticks = Array.from({ length: 12 }, (_, i) => {
    const a = (i * Math.PI) / 6;
    const x1 = 16 + Math.sin(a) * 11.5;
    const y1 = 16 - Math.cos(a) * 11.5;
    const x2 = 16 + Math.sin(a) * (i % 3 === 0 ? 8.8 : 9.8);
    const y2 = 16 - Math.cos(a) * (i % 3 === 0 ? 8.8 : 9.8);
    return `<line x1="${x1.toFixed(2)}" y1="${y1.toFixed(2)}" x2="${x2.toFixed(2)}" y2="${y2.toFixed(2)}" stroke="currentColor" stroke-width="${i % 3 === 0 ? 1.8 : 1.1}" stroke-linecap="round"/>`;
  }).join('');
  svg.innerHTML = `<circle cx="16" cy="16" r="14.2" fill="none" stroke="currentColor" stroke-width="1.6"/>${ticks}<path d="M13.2 11.4v9.2l7.6-4.6z" fill="currentColor"/>`;
  return svg;
}

/** Round avatar: shows the ImageKit photo when there is one, otherwise (or if it fails to load) the first letter of the name. */
export function avatar(name, photoUrl, attrs = {}, tag = 'div') {
  const el = h(tag, { ...attrs, class: `${attrs.class || ''} avatar`.trim() }, Array.from(name || '?')[0].toUpperCase());
  const src = avatarSrc(photoUrl, 160);
  if (src) el.append(h('img', { src, alt: '', loading: 'lazy', decoding: 'async', onerror: (e) => e.target.remove() }));
  return el;
}

export function thumb(video, { eager = false } = {}) {
  const wrap = h('div', { class: 'thumb' });
  const url = thumbSrc(video.thumbnailUrl, 640);
  if (url) {
    wrap.append(h('img', { src: url, alt: '', loading: eager ? 'eager' : 'lazy', decoding: 'async', onerror: (e) => e.target.remove() }));
  }
  const letter = Array.from(video.title || '?')[0].toUpperCase();
  wrap.prepend(h('span', { class: 'thumb-fallback', 'aria-hidden': 'true' }, letter));
  if (video.durationSec) wrap.append(h('span', { class: 'thumb-dur' }, duration(video.durationSec)));
  return wrap;
}

export function videoCard(video) {
  return h(
    'a',
    { class: 'vcard', href: `#/v/${video.id}` },
    thumb(video),
    h(
      'div',
      { class: 'vcard-body' },
      h('h3', { class: 'vcard-title' }, video.title),
      h('p', { class: 'meta' }, h('span', null, icon('eye', 14), compact(video.views), ' views'), h('span', null, icon('heart', 14), compact(video.likes))),
    ),
  );
}

export function popularStrip(videos) {
  return h(
    'ol',
    { class: 'popular', 'aria-label': 'Most viewed videos' },
    videos.map((v, i) =>
      h(
        'li',
        null,
        h(
          'a',
          { class: 'pop', href: `#/v/${v.id}` },
          h('span', { class: 'pop-rank', 'aria-label': `Rank ${i + 1}` }, String(i + 1)),
          thumb(v),
          h('span', { class: 'pop-body' }, h('span', { class: 'pop-title' }, v.title), h('span', { class: 'meta' }, h('span', null, icon('eye', 13), compact(v.views)))),
        ),
      ),
    ),
  );
}

export function skeletonGrid(n = 6) {
  return h('div', { class: 'grid', 'aria-busy': 'true', 'aria-label': 'Loading' }, Array.from({ length: n }, () => h('div', { class: 'vcard skeleton' }, h('div', { class: 'thumb' }), h('div', { class: 'vcard-body' }, h('div', { class: 'sk-line' }), h('div', { class: 'sk-line short' })))));
}

export function emptyState({ title, text, action }) {
  return h('div', { class: 'state' }, h('div', { class: 'state-art', 'aria-hidden': 'true' }, logoMark(44)), h('h2', null, title), text ? h('p', null, text) : null, action || null);
}

export function errorState(message, onRetry) {
  return h(
    'div',
    { class: 'state state-error', role: 'alert' },
    h('div', { class: 'state-art', 'aria-hidden': 'true' }, icon('alert', 36)),
    h('h2', null, 'Something went wrong'),
    h('p', null, message),
    onRetry ? h('button', { class: 'btn primary', type: 'button', onclick: onRetry }, 'Try again') : null,
  );
}

export function banner(settings) {
  const b = settings.banner;
  if (!b?.enabled || !b.html) return null;
  const frame = h('iframe', {
    class: 'banner-frame',
    title: 'Sponsored banner',
    src: `${apiBase()}/api/ads/banner-frame`,
    width: b.width,
    height: b.height,
    loading: 'lazy',
    // The API also sends a CSP `sandbox` header; both layers keep the banner away from the app and the user's session.
    sandbox: 'allow-scripts allow-popups allow-popups-to-escape-sandbox',
    referrerpolicy: 'no-referrer',
    scrolling: 'no',
  });
  const wrap = h('aside', { class: 'banner', 'aria-label': 'Advertisement' }, h('span', { class: 'banner-tag' }, 'Sponsored'), h('div', { class: 'banner-slot' }, frame));
  wrap.querySelector('.banner-slot').style.height = `${b.height}px`; // CSSOM, not a style attribute: the CSP forbids inline styles
  // scale down when the banner is wider than the screen
  const fit = () => {
    const avail = wrap.clientWidth - 2;
    const scale = avail > 0 && b.width > avail ? avail / b.width : 1;
    frame.style.transform = scale < 1 ? `scale(${scale})` : '';
    frame.style.transformOrigin = 'top left';
    wrap.querySelector('.banner-slot').style.height = `${Math.ceil(b.height * scale)}px`;
    frame.style.marginLeft = scale < 1 ? '0' : '';
  };
  new ResizeObserver(fit).observe(wrap);
  return wrap;
}
