import { h, clear, icon } from '../lib/dom.js';
import { query } from '../lib/firebase.js';
import { state } from '../state.js';
import { queryToken, queryWords } from '../lib/search.js';
import { banner, emptyState, errorState, popularStrip, skeletonGrid, videoCard } from '../components.js';

const PUBLISHED = ['status', '==', 'published'];

export async function render({ root, query: qs, isCurrent }) {
  const q = (qs.q || '').trim();
  const s = state.settings;
  const page = h('div', { class: 'page' });
  root.append(page);
  if (q) return renderSearch(page, q, isCurrent);

  page.append(h('section', { class: 'hero' }, h('h1', null, s.siteName), h('p', null, s.tagline)));

  const popularHost = h('section', { class: 'block', 'aria-labelledby': 'pop-h' }, h('div', { class: 'block-head' }, h('h2', { id: 'pop-h' }, 'Most viewed')));
  const bannerNode = banner(s);
  const listHost = h('section', { class: 'block', 'aria-labelledby': 'new-h' }, h('div', { class: 'block-head' }, h('h2', { id: 'new-h' }, 'Latest videos')));
  page.append(popularHost, bannerNode, listHost);

  // popular strip: compact, loads independently of the main list
  popularHost.append(h('div', { class: 'popular-skeleton skeleton' }));
  query({ collection: 'videos', where: [PUBLISHED], orderBy: [['views', 'desc']], limit: s.popularCount })
    .then((vids) => {
      if (!isCurrent()) return;
      popularHost.querySelector('.popular-skeleton')?.remove();
      const shown = vids.filter((v) => (v.views || 0) > 0); // a "most viewed" list only makes sense for videos that were viewed
      if (shown.length) popularHost.append(popularStrip(shown));
      else popularHost.remove();
    })
    .catch(() => {
      popularHost.remove();
    });

  await loadList(listHost, s.homeListLimit, isCurrent);
}

async function loadList(host, pageSize, isCurrent) {
  let offset = 0;
  const grid = h('div', { class: 'grid' });
  const footer = h('div', { class: 'more' });
  const first = skeletonGrid(Math.min(pageSize, 6));
  host.append(first);

  async function loadPage() {
    const vids = await query({ collection: 'videos', where: [PUBLISHED], orderBy: [['createdAt', 'desc']], limit: pageSize + 1, offset });
    if (!isCurrent()) return;
    const more = vids.length > pageSize;
    vids.slice(0, pageSize).forEach((v) => grid.append(videoCard(v)));
    offset += pageSize;
    clear(footer);
    if (more) {
      const btn = h('button', { class: 'btn', type: 'button' }, 'Show more videos');
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        btn.textContent = 'Loading…';
        try {
          await loadPage();
        } catch (e) {
          btn.disabled = false;
          btn.textContent = 'Show more videos';
          footer.append(h('p', { class: 'form-error', role: 'alert' }, e.message));
        }
      });
      footer.append(btn);
    }
    return vids.length;
  }

  try {
    const n = await loadPage();
    first.remove();
    if (!isCurrent()) return;
    if (!n) {
      host.append(emptyState({ title: 'No videos yet', text: 'New videos will appear here as soon as they are published.' }));
      return;
    }
    host.append(grid, footer);
  } catch (e) {
    first.remove();
    host.append(errorState(e.message, () => {
      host.querySelector('.state')?.remove();
      loadList(host, pageSize, isCurrent);
    }));
  }
}

async function renderSearch(page, q, isCurrent) {
  const words = queryWords(q);
  const token = queryToken(q);
  page.append(h('div', { class: 'block-head search-head' }, h('h1', { class: 'h2' }, `Results for “${q}”`), h('a', { class: 'btn small', href: '#/' }, 'Clear search')));
  const host = h('section', { class: 'block' });
  page.append(host);
  if (!token) {
    host.append(emptyState({ title: 'Type a word to search', text: 'Search matches video titles and tags.' }));
    return;
  }
  host.append(skeletonGrid(4));
  const run = async () => {
    try {
      const found = await query({ collection: 'videos', where: [PUBLISHED, ['searchTokens', 'array-contains', token]], orderBy: [['createdAt', 'desc']], limit: 40 });
      if (!isCurrent()) return;
      const results = found.filter((v) => words.every((w) => (v.searchTokens || []).includes(Array.from(w).slice(0, 20).join(''))));
      clear(host);
      if (!results.length) {
        host.append(emptyState({ title: 'No matches', text: `Nothing matched “${q}”. Check the spelling or try a shorter word.`, action: h('a', { class: 'btn primary', href: '#/' }, 'Back to home') }));
        return;
      }
      host.append(h('p', { class: 'muted result-count', role: 'status' }, `${results.length} ${results.length === 1 ? 'video' : 'videos'}`), h('div', { class: 'grid' }, results.map(videoCard)));
    } catch (e) {
      clear(host);
      host.append(errorState(e.message, run));
    }
  };
  await run();
}
