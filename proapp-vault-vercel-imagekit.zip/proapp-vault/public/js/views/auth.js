import { h, busy, icon } from '../lib/dom.js';
import * as fb from '../lib/firebase.js';
import { establishSession, state, takeReturn } from '../state.js';
import { navigate } from '../router.js';
import { logoMark } from '../components.js';

function field({ label, id, type = 'text', autocomplete, required = true, minlength, hint }) {
  const input = h('input', { id, name: id, type, autocomplete, required, minlength, class: 'input' });
  return { input, node: h('div', { class: 'field' }, h('label', { for: id }, label), input, hint ? h('p', { class: 'hint' }, hint) : null) };
}

function shell(title, subtitle, ...content) {
  return h('div', { class: 'page narrow' }, h('div', { class: 'auth-card' }, h('div', { class: 'auth-mark' }, logoMark(40)), h('h1', null, title), subtitle ? h('p', { class: 'muted' }, subtitle) : null, ...content));
}

const validEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

export async function render({ root, params, query }) {
  const mode = params.mode || 'login';
  if (fb.currentSession() && state.user) return navigate('#/', { replace: true });
  if (mode === 'reset') return root.append(resetForm());
  root.append(mode === 'signup' ? signupForm() : loginForm());
}

function loginForm() {
  const email = field({ label: 'Email', id: 'email', type: 'email', autocomplete: 'email' });
  const pass = field({ label: 'Password', id: 'password', type: 'password', autocomplete: 'current-password' });
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Log in');
  const form = h('form', { class: 'form', novalidate: true }, email.node, pass.node, err, btn, h('p', { class: 'center' }, h('a', { href: '#/reset' }, 'Forgot password?')));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.hidden = true;
    if (!validEmail(email.input.value.trim())) return show(err, 'Enter a valid email address.');
    if (!pass.input.value) return show(err, 'Enter your password.');
    await busy(btn, async () => {
      try {
        await fb.signIn(email.input.value.trim(), pass.input.value);
        await establishSession();
        navigate(takeReturn());
      } catch (ex) {
        show(err, ex.message);
      }
    }, 'Logging in…');
  });
  return shell('Welcome back', 'Log in to watch, like, save and comment.', form, h('p', { class: 'center muted' }, 'New here? ', h('a', { href: '#/signup' }, 'Create an account')));
}

function signupForm() {
  const name = field({ label: 'Display name', id: 'name', autocomplete: 'nickname', hint: 'Shown next to your comments.' });
  const email = field({ label: 'Email', id: 'email', type: 'email', autocomplete: 'email' });
  const pass = field({ label: 'Password', id: 'password', type: 'password', autocomplete: 'new-password', minlength: 6, hint: 'At least 6 characters.' });
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Create account');
  const form = h('form', { class: 'form', novalidate: true }, name.node, email.node, pass.node, err, btn);
  const closed = state.settings.allowSignups === false;
  if (closed) {
    return shell('Sign-ups are closed', 'New accounts are not being accepted right now.', h('p', { class: 'center' }, h('a', { class: 'btn', href: '#/login' }, 'Log in instead')));
  }
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.hidden = true;
    const displayName = name.input.value.trim();
    if (displayName.length < 2 || displayName.length > 40) return show(err, 'Display name must be 2 to 40 characters.');
    if (!validEmail(email.input.value.trim())) return show(err, 'Enter a valid email address.');
    if (pass.input.value.length < 6) return show(err, 'Password must be at least 6 characters.');
    await busy(btn, async () => {
      try {
        await fb.signUp(email.input.value.trim(), pass.input.value);
        await fb.setDisplayName(displayName).catch(() => {});
        await establishSession();
        fb.sendVerificationEmail().catch(() => {});
        navigate(takeReturn());
      } catch (ex) {
        show(err, ex.message);
      }
    }, 'Creating account…');
  });
  return shell('Create your account', 'One account for watching, saving and commenting.', form, h('p', { class: 'center muted' }, 'Already have an account? ', h('a', { href: '#/login' }, 'Log in')));
}

function resetForm() {
  const email = field({ label: 'Email', id: 'email', type: 'email', autocomplete: 'email' });
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const ok = h('p', { class: 'form-ok', role: 'status', hidden: true }, 'If an account exists for that email, a reset link is on its way. Check your inbox and spam folder.');
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Send reset link');
  const form = h('form', { class: 'form', novalidate: true }, email.node, err, ok, btn);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.hidden = ok.hidden = true;
    if (!validEmail(email.input.value.trim())) return show(err, 'Enter a valid email address.');
    await busy(btn, async () => {
      try {
        await fb.sendPasswordReset(email.input.value.trim());
        ok.hidden = false;
      } catch (ex) {
        // Do not reveal whether the account exists.
        if (ex.code === 'network') show(err, ex.message);
        else ok.hidden = false;
      }
    }, 'Sending…');
  });
  return shell('Reset your password', 'We will email you a link to choose a new one.', form, h('p', { class: 'center' }, h('a', { href: '#/login' }, 'Back to log in')));
}

function show(el, msg) {
  el.textContent = msg;
  el.hidden = false;
}
