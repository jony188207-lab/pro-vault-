import { h } from '../lib/dom.js';
import { query, getDocs } from '../lib/firebase.js';
import { state } from '../state.js';
import { emptyState, errorState, skeletonGrid, videoCard } from '../components.js';

export async function render({ root, isCurrent }) {
  const page = h('div', { class: 'page' }, h('div', { class: 'block-head' }, h('h1', { class: 'h2' }, 'Saved videos')));
  root.append(page);
  const host = h('section', { class: 'block' }, skeletonGrid(4));
  page.append(host);
  const load = async () => {
    try {
      const saves = await query({ collection: 'saves', where: [['uid', '==', state.user.uid]], orderBy: [['createdAt', 'desc']], limit: 60 });
      const docs = await getDocs(saves.map((s) => `videos/${s.videoId}`));
      if (!isCurrent()) return;
      const videos = docs.filter((v) => v && v.status === 'published');
      host.replaceChildren();
      if (!videos.length) {
        host.append(emptyState({ title: 'Nothing saved yet', text: 'Tap Save on any video to keep it here.', action: h('a', { class: 'btn primary', href: '#/' }, 'Browse videos') }));
        return;
      }
      host.append(h('div', { class: 'grid' }, videos.map(videoCard)));
    } catch (e) {
      host.replaceChildren(errorState(e.message, load));
    }
  };
  await load();
}
