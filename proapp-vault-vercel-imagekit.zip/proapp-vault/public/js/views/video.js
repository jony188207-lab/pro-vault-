import { h, icon, compact, timeAgo, fullDate, toast, confirmDialog, busy, clear } from '../lib/dom.js';
import { getDoc, query } from '../lib/firebase.js';
import { api, ApiError } from '../lib/api.js';
import { state, isAdmin, rememberReturn } from '../state.js';
import { thumb, errorState, emptyState, avatar } from '../components.js';
import { thumbSrc } from '../lib/media.js';

export async function render({ root, params, isCurrent }) {
  const id = params.id;
  const page = h('div', { class: 'page video-page' });
  root.append(page);
  page.append(h('div', { class: 'player skeleton' }), h('div', { class: 'sk-line' }), h('div', { class: 'sk-line short' }));

  let video;
  try {
    video = await getDoc(`videos/${id}`);
  } catch (e) {
    clear(page);
    return page.append(errorState(e.message, () => (clear(root), render({ root, params, isCurrent }))));
  }
  if (!isCurrent()) return;
  clear(page);
  if (!video || (video.status !== 'published' && !isAdmin())) {
    return page.append(emptyState({ title: 'Video not found', text: 'It may have been removed or is not published yet.', action: h('a', { class: 'btn primary', href: '#/' }, 'Back to home') }));
  }
  document.title = `${video.title} · ${state.settings.siteName}`;

  const texts = state.settings.texts;
  const ui = { liked: false, saved: false, gate: { watch: { required: false, unlocked: true }, save: { required: false, unlocked: true } }, loaded: false };

  // ---------------------------------------------------------------- player area
  const player = h('div', { class: 'player' });
  const playerBody = h('div', { class: 'player-body' });
  const poster = thumbSrc(video.thumbnailUrl, 960);
  if (poster) player.append(h('img', { class: 'player-poster', src: poster, alt: '' }));
  else player.append(h('div', { class: 'player-poster fallback' }, thumb(video)));
  player.append(playerBody);

  const title = h('h1', { class: 'video-title' }, video.title);
  const stats = h('p', { class: 'meta big' });
  const actions = h('div', { class: 'actions' });
  const gateHost = h('div', { class: 'gate-host' });
  const desc = h('div', { class: 'desc' });
  const comments = h('section', { class: 'comments', 'aria-labelledby': 'cm-h' });
  page.append(h('a', { class: 'back', href: '#/' }, icon('back', 18), 'Back'), player, title, stats, actions, gateHost, desc, comments);

  const likeBtn = h('button', { class: 'btn pill', type: 'button', 'aria-pressed': 'false' });
  const saveBtn = h('button', { class: 'btn pill', type: 'button', 'aria-pressed': 'false' });

  function paintStats() {
    clear(stats);
    stats.append(h('span', null, icon('eye', 16), `${compact(video.views)} views`), h('span', null, icon('heart', 16), `${compact(video.likes)} likes`), h('span', null, icon('comment', 16), `${compact(video.commentsCount)} comments`), video.createdAt ? h('span', { title: fullDate(video.createdAt) }, timeAgo(video.createdAt)) : null);
  }
  function paintActions() {
    likeBtn.classList.toggle('on', ui.liked);
    likeBtn.setAttribute('aria-pressed', String(ui.liked));
    clear(likeBtn);
    likeBtn.append(icon('heart', 18), ui.liked ? 'Liked' : 'Like');
    saveBtn.classList.toggle('on', ui.saved);
    saveBtn.setAttribute('aria-pressed', String(ui.saved));
    clear(saveBtn);
    saveBtn.append(icon(ui.saved ? 'check' : 'bookmark', 18), ui.saved ? 'Saved' : texts.saveButton);
  }
  function paintDesc() {
    clear(desc);
    if (video.description) desc.append(...video.description.split(/\n{2,}/).map((p) => h('p', null, p)));
    if (video.tags?.length) desc.append(h('p', { class: 'tags' }, video.tags.map((t) => h('a', { class: 'tag', href: `#/?q=${encodeURIComponent(t)}` }, `#${t}`))));
  }
  paintStats();
  paintActions();
  paintDesc();
  actions.append(likeBtn, saveBtn);

  // ---------------------------------------------------------------- watching
  function paintPlayer() {
    clear(playerBody);
    player.classList.remove('playing');
    if (!state.user) {
      playerBody.append(overlay('lock', 'Log in to watch', 'Free account. Takes under a minute.', h('a', { class: 'btn primary', href: '#/login', onclick: () => rememberReturn(`#/v/${id}`) }, 'Log in'), h('a', { class: 'btn', href: '#/signup', onclick: () => rememberReturn(`#/v/${id}`) }, 'Create account')));
      return;
    }
    if (!ui.loaded) return playerBody.append(h('div', { class: 'spinner', role: 'status', 'aria-label': 'Loading' }));
    const g = ui.gate.watch;
    if (g.required && !g.unlocked) {
      playerBody.append(overlay('lock', 'Locked', texts.watchInstruction));
      return;
    }
    const watchBtn = h('button', { class: 'btn primary xl', type: 'button' }, icon('play', 22), texts.watchButton);
    watchBtn.addEventListener('click', () => startPlayback(watchBtn));
    playerBody.append(g.required ? h('p', { class: 'unlocked-note' }, icon('unlock', 16), texts.unlockedText) : null, watchBtn);
  }

  let videoEl = null;
  async function startPlayback(btn, retried = false) {
    try {
      const res = await (btn ? busy(btn, () => api.post(`/api/videos/${id}/play`, {}), 'Starting…') : api.post(`/api/videos/${id}/play`, {}));
      if (res.viewCounted) {
        video.views = (video.views || 0) + 1;
        paintStats();
      }
      clear(playerBody);
      player.classList.add('playing');
      videoEl = h('video', { class: 'video-el', controls: true, playsinline: true, autoplay: true, controlsList: 'nodownload', poster: poster || undefined, preload: 'metadata' });
      videoEl.addEventListener('error', () => {
        if (!retried) startPlayback(null, true); // the signed link may have expired: get a fresh one once
        else toast('This video could not be played. Try again later.', 'error');
      }, { once: true });
      videoEl.src = res.url;
      playerBody.append(videoEl);
      videoEl.play?.().catch(() => {});
    } catch (e) {
      if (e instanceof ApiError && e.code === 'ad_required') {
        ui.gate.watch.unlocked = false;
        paintPlayer();
        paintGate();
      }
      toast(e.message, 'error');
    }
  }

  // ---------------------------------------------------------------- sponsor gate (watch + save)
  function paintGate() {
    clear(gateHost);
    if (!state.user || !ui.loaded) return;
    if (ui.gate.watch.required && !ui.gate.watch.unlocked) {
      gateHost.append(gatePanel({ purpose: 'watch', videoId: id, status: ui.gate.watch, instruction: texts.watchInstruction, openLabel: texts.openAdButton, verifyLabel: texts.verifyButton, waitingText: texts.waitingText, unlockedText: texts.unlockedText, onUnlocked: () => ((ui.gate.watch.unlocked = true), paintGate(), paintPlayer(), toast(texts.unlockedText, 'success')) }));
    }
    if (saveGateOpen && ui.gate.save.required && !ui.gate.save.unlocked) {
      gateHost.append(gatePanel({ purpose: 'save', videoId: id, status: ui.gate.save, instruction: texts.saveInstruction, openLabel: texts.saveOpenAdButton, verifyLabel: texts.verifyButton, waitingText: texts.waitingText, unlockedText: texts.saveUnlockedText, onUnlocked: async () => { ui.gate.save.unlocked = true; saveGateOpen = false; paintGate(); toast(texts.saveUnlockedText, 'success'); await doSave(true); } }));
    }
  }

  // ---------------------------------------------------------------- like / save
  likeBtn.addEventListener('click', async () => {
    if (!requireLogin()) return;
    const next = !ui.liked;
    ui.liked = next;
    video.likes = Math.max(0, (video.likes || 0) + (next ? 1 : -1));
    paintActions();
    paintStats();
    try {
      const res = await api.post(`/api/videos/${id}/like`, { liked: next });
      ui.liked = res.liked;
      video.likes = res.likes;
    } catch (e) {
      ui.liked = !next;
      video.likes = Math.max(0, (video.likes || 0) + (next ? -1 : 1));
      toast(e.message, 'error');
    }
    paintActions();
    paintStats();
  });

  let saveGateOpen = false;
  async function doSave(saved) {
    try {
      await api.post(`/api/videos/${id}/save`, { saved });
      ui.saved = saved;
      video.savesCount = Math.max(0, (video.savesCount || 0) + (saved ? 1 : -1));
      toast(saved ? 'Saved to your list' : 'Removed from saved', 'success');
    } catch (e) {
      if (e.code === 'ad_required') {
        ui.gate.save.unlocked = false;
        saveGateOpen = true;
        paintGate();
      }
      toast(e.message, 'error');
    }
    paintActions();
  }
  saveBtn.addEventListener('click', async () => {
    if (!requireLogin()) return;
    if (ui.saved) return busy(saveBtn, () => doSave(false));
    if (ui.gate.save.required && !ui.gate.save.unlocked) {
      saveGateOpen = !saveGateOpen;
      paintGate();
      gateHost.scrollIntoView?.({ behavior: 'smooth', block: 'center' });
      return;
    }
    await busy(saveBtn, () => doSave(true));
  });

  function requireLogin() {
    if (state.user) return true;
    rememberReturn(`#/v/${id}`);
    toast('Log in to do that.', 'info');
    location.hash = '#/login';
    return false;
  }

  // ---------------------------------------------------------------- comments
  await Promise.all([loadViewerState(), renderComments()]);

  async function loadViewerState() {
    paintPlayer();
    if (!state.user) return;
    try {
      const s = await api.get(`/api/videos/${id}/state`);
      if (!isCurrent()) return;
      ui.liked = s.liked;
      ui.saved = s.saved;
      ui.gate = s.gate;
      ui.loaded = true;
    } catch (e) {
      ui.loaded = true;
      toast(e.message, 'error');
    }
    paintActions();
    paintGate();
    paintPlayer();
  }

  async function renderComments() {
    clear(comments);
    comments.append(h('h2', { id: 'cm-h' }, 'Comments'));
    if (state.settings.commentsEnabled === false) return comments.append(h('p', { class: 'muted' }, 'Comments are turned off.'));
    const list = h('ul', { class: 'comment-list' });
    const form = commentForm();
    comments.append(form, list);
    list.append(h('li', { class: 'muted' }, 'Loading comments…'));
    const load = async () => {
      try {
        const items = await query({ collection: 'comments', where: [['videoId', '==', id]], orderBy: [['createdAt', 'desc']], limit: 50 });
        if (!isCurrent()) return;
        clear(list);
        if (!items.length) list.append(h('li', { class: 'empty-line' }, 'No comments yet. Be the first to say something.'));
        items.forEach((c) => list.append(commentItem(c)));
      } catch (e) {
        clear(list);
        list.append(h('li', null, h('span', { class: 'form-error' }, e.message), ' ', h('button', { class: 'btn small', type: 'button', onclick: load }, 'Retry')));
      }
    };
    function commentItem(c) {
      const mine = state.user && c.uid === state.user.uid;
      const li = h('li', { class: 'comment', dataset: { id: c.id } },
        avatar(c.authorName, c.authorPhoto, { 'aria-hidden': 'true' }),
        h('div', { class: 'comment-main' },
          h('p', { class: 'comment-head' }, h('strong', null, c.authorName || 'Member'), h('time', { datetime: c.createdAt?.toISOString?.(), title: fullDate(c.createdAt) }, timeAgo(c.createdAt))),
          h('p', { class: 'comment-text' }, c.text)),
        mine || isAdmin()
          ? h('button', { class: 'icon-btn danger', type: 'button', 'aria-label': 'Delete comment', onclick: async (ev) => {
              if (!(await confirmDialog({ title: 'Delete comment?', message: 'This can not be undone.', confirmLabel: 'Delete', danger: true }))) return;
              try {
                await api.del(`/api/comments/${c.id}`);
                li.remove();
                video.commentsCount = Math.max(0, (video.commentsCount || 0) - 1);
                paintStats();
                if (!list.children.length) list.append(h('li', { class: 'empty-line' }, 'No comments yet. Be the first to say something.'));
              } catch (e) {
                toast(e.message, 'error');
              }
            } }, icon('trash', 18))
          : null);
      return li;
    }
    function commentForm() {
      if (!state.user) return h('p', { class: 'muted login-hint' }, h('a', { href: '#/login', onclick: () => rememberReturn(`#/v/${id}`) }, 'Log in'), ' to join the conversation.');
      const ta = h('textarea', { class: 'input', rows: 2, maxlength: 1000, placeholder: 'Add a comment…', 'aria-label': 'Add a comment', required: true });
      const count = h('span', { class: 'hint' }, '0 / 1000');
      const btn = h('button', { class: 'btn primary', type: 'submit' }, 'Post comment');
      const f = h('form', { class: 'comment-form' }, ta, h('div', { class: 'row between' }, count, btn));
      ta.addEventListener('input', () => (count.textContent = `${ta.value.length} / 1000`));
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const text = ta.value.trim();
        if (!text) return;
        await busy(btn, async () => {
          try {
            const { comment } = await api.post(`/api/videos/${id}/comments`, { text });
            comment.createdAt = new Date(comment.createdAt);
            ta.value = '';
            count.textContent = '0 / 1000';
            list.querySelector('.empty-line, .muted')?.closest('li')?.remove();
            list.prepend(commentItem(comment));
            video.commentsCount = (video.commentsCount || 0) + 1;
            paintStats();
          } catch (ex) {
            toast(ex.message, 'error');
          }
        }, 'Posting…');
      });
      return f;
    }
    await load();
  }
}

function overlay(iconName, title, text, ...actions) {
  return h('div', { class: 'overlay-card' }, h('div', { class: 'overlay-icon' }, icon(iconName, 26)), h('h2', null, title), text ? h('p', null, text) : null, actions.length ? h('div', { class: 'row center-row' }, actions) : null);
}

/**
 * The sponsor step. Shows the admin-written instruction, opens the sponsor link on request, and asks the server to unlock.
 * Honest by design: it never says an ad was "viewed" - the server only knows the link was issued, that enough time passed,
 * and (with a postback-capable ad provider) that the provider confirmed.
 */
function gatePanel({ purpose, videoId, status, instruction, openLabel, verifyLabel, waitingText, onUnlocked }) {
  let phase = 'idle';
  let sessionId = null;
  let timer = null;
  const minAway = status.minAwaySeconds || 5;
  const body = h('div', { class: 'gate-body' });
  const root = h('section', { class: `gate gate-${purpose}`, 'aria-live': 'polite' }, h('div', { class: 'gate-icon' }, icon('lock', 22)), body);
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });

  function paint() {
    clear(body);
    if (phase === 'idle') {
      const open = h('button', { class: 'btn primary', type: 'button' }, icon('external', 18), openLabel);
      open.addEventListener('click', () => openSponsor(open));
      body.append(h('p', { class: 'gate-text' }, instruction), open, err);
    } else {
      const verify = h('button', { class: 'btn primary', type: 'button', disabled: true }, verifyLabel);
      const hint = h('p', { class: 'hint', role: 'timer' });
      verify.addEventListener('click', () => complete(verify));
      let left = minAway;
      const tick = () => {
        hint.textContent = left > 0 ? `You can continue in ${left}s` : status.verification === 'postback' ? 'Waiting for the sponsor to confirm. This can take a moment.' : 'Ready when you are.';
        verify.disabled = left > 0;
        if (left-- > 0) timer = setTimeout(tick, 1000);
      };
      clearTimeout(timer);
      tick();
      const fallback = fallbackLink ? h('p', { class: 'hint' }, 'Pop-up blocked? ', h('a', { href: fallbackLink, target: '_blank', rel: 'noopener noreferrer sponsored' }, 'Open the sponsor page here')) : null;
      body.append(h('p', { class: 'gate-text' }, waitingText), hint, verify, fallback, err);
    }
  }

  let fallbackLink = null;
  async function openSponsor(btn) {
    err.hidden = true;
    // Open the tab synchronously inside the click so pop-up blockers allow it, then point it at the sponsor URL.
    const tab = window.open('about:blank', '_blank');
    try {
      const res = await busy(btn, () => api.post('/api/ads/start', { videoId, purpose }), 'Opening…');
      if (res.alreadyUnlocked) {
        tab?.close();
        return onUnlocked(res.expiresAt);
      }
      sessionId = res.sessionId;
      status.verification = res.verification;
      if (tab) {
        try {
          tab.opener = null;
        } catch {
          /* ignore */
        }
        tab.location.href = res.adUrl;
        fallbackLink = null;
      } else fallbackLink = res.adUrl;
      phase = 'away';
      paint();
    } catch (e) {
      tab?.close();
      showErr(e.message);
    }
  }

  async function complete(btn) {
    err.hidden = true;
    await busy(btn, async () => {
      try {
        const res = await api.post('/api/ads/complete', { sessionId });
        clearTimeout(timer);
        onUnlocked(res.expiresAt);
      } catch (e) {
        if (e.code === 'session_expired' || e.code === 'invalid_session') {
          phase = 'idle';
          sessionId = null;
          paint();
        } else if (e.code === 'too_early') {
          const wait = e.extra?.retryAfterSeconds || 2;
          showErr(`Not quite yet. Try again in ${wait}s.`);
          return;
        }
        showErr(e.message);
      }
    }, 'Checking…');
  }

  function showErr(msg) {
    err.textContent = msg;
    err.hidden = false;
  }
  paint();
  return root;
}
