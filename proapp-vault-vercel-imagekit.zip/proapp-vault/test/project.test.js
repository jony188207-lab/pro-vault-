// Static checks on the shipped project: config, Vercel setup, asset paths, and that no secrets or old-provider code remain.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const walk = (dir, out = []) => {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', '.vercel'].includes(e.name)) continue;
    const p = path.join(dir, e.name);
    e.isDirectory() ? walk(p, out) : out.push(p);
  }
  return out;
};

test('vercel.json: valid, API rewrite, CSP excludes /api and allows only ImageKit + Google', () => {
  const v = JSON.parse(read('vercel.json'));
  assert.deepEqual(v.rewrites, [{ source: '/api/(.*)', destination: '/api' }]);
  assert.equal(v.outputDirectory, 'public');
  assert.ok(fs.existsSync(path.join(ROOT, 'api/index.js')));
  const rule = v.headers.find((h) => h.headers.some((x) => x.key === 'Content-Security-Policy'));
  assert.ok(rule.source.includes('(?!api/)'));
  const csp = rule.headers.find((x) => x.key === 'Content-Security-Policy').value;
  assert.match(csp, /img-src[^;]*https:\/\/ik\.imagekit\.io/);
  assert.match(csp, /media-src[^;]*https:\/\/ik\.imagekit\.io/);
  assert.match(csp, /connect-src[^;]*https:\/\/upload\.imagekit\.io/);
  assert.match(csp, /script-src 'self';/);
  assert.doesNotMatch(csp, /unsafe-inline|unsafe-eval|workers\.dev|r2\./);
});

test('api/index.js delegates to the server handler and reads process.env', async () => {
  const src = read('api/index.js');
  assert.match(src, /process\.env/);
  const mod = await import('../api/index.js');
  assert.equal(typeof mod.default.fetch, 'function');
  const res = await mod.default.fetch(new Request('https://x.test/api/does-not-exist'));
  assert.ok([404, 500].includes(res.status));
  assert.ok(!(await res.text()).includes('PRIVATE'));
});

test('public/js/config.js has placeholders only, and no private credentials anywhere in public/', () => {
  const cfg = read('public/js/config.js');
  assert.match(cfg, /REPLACE_WITH/);
  assert.match(cfg, /urlEndpoint/);
  for (const f of walk(path.join(ROOT, 'public'))) {
    const t = fs.readFileSync(f, 'utf8');
    assert.doesNotMatch(t, /IMAGEKIT_PRIVATE_KEY|PRIVATE KEY|private_key|privateKey|private_[A-Za-z0-9+/=]{10,}/, `${f} must not contain private credentials`);
  }
});

test('no Cloudflare / R2 / Wrangler / Netlify leftovers in shipped files', () => {
  const skip = /(^|\/)test\//;
  for (const f of walk(ROOT)) {
    const rel = path.relative(ROOT, f);
    if (skip.test(rel) || /\.(png|jpg|ico|zip)$/.test(rel) || rel === 'README.md') continue;
    assert.doesNotMatch(rel, /wrangler|netlify|_headers|worker/i, rel);
    const t = fs.readFileSync(f, 'utf8');
    assert.doesNotMatch(t, /wrangler|workers\.dev|MEDIA_BUCKET|R2Bucket|\bR2\b|cloudflare/i, `${rel} mentions the old provider`);
  }
});

test('every local import and HTML reference in the frontend resolves to a file', () => {
  const pub = path.join(ROOT, 'public');
  const missing = [];
  for (const f of walk(pub)) {
    const t = fs.readFileSync(f, 'utf8');
    const refs = [];
    if (f.endsWith('.js')) for (const m of t.matchAll(/(?:import|export)[^'"`]*?from\s*['"](\.[^'"]+)['"]|import\(\s*['"](\.[^'"]+)['"]\s*\)/g)) refs.push(m[1] || m[2]);
    if (f.endsWith('.html')) for (const m of t.matchAll(/(?:src|href)=["']([^"'#?]+)["']/g)) if (!/^(https?:|data:|mailto:)/.test(m[1])) refs.push(m[1]);
    if (f.endsWith('.css')) for (const m of t.matchAll(/url\(["']?([^"')]+)["']?\)/g)) if (!/^(https?:|data:)/.test(m[1])) refs.push(m[1]);
    for (const r of refs) {
      const target = r.startsWith('/') ? path.join(pub, r) : path.resolve(path.dirname(f), r);
      if (!fs.existsSync(target)) missing.push(`${path.relative(pub, f)} -> ${r}`);
    }
  }
  assert.deepEqual(missing, []);
  assert.ok(fs.existsSync(path.join(pub, 'index.html')));
});

test('generate-config: leaves the file alone when unset, refuses partial config, writes public values only', async () => {
  const { buildConfig } = await import('../scripts/generate-config.mjs');
  assert.equal(buildConfig({}), null);
  assert.throws(() => buildConfig({ FIREBASE_API_KEY: 'k' }));
  const out = buildConfig({ FIREBASE_API_KEY: 'AIzaSyTESTTESTTESTTESTTESTTESTTESTTEST1', FIREBASE_PROJECT_ID: 'my-project-1', IMAGEKIT_URL_ENDPOINT: 'https://ik.imagekit.io/abc', IMAGEKIT_PRIVATE_KEY: 'private_secret_zzz', FIREBASE_SERVICE_ACCOUNT_JSON: '{"private_key":"x"}' });
  assert.match(out, /AIzaSyTESTTESTTESTTESTTESTTESTTESTTEST1/);
  assert.match(out, /https:\/\/ik\.imagekit\.io\/abc/);
  assert.doesNotMatch(out, /private_secret_zzz|private_key/);
});

test('.env.example contains no values for secrets', () => {
  const t = read('.env.example');
  for (const k of ['IMAGEKIT_PRIVATE_KEY', 'FIREBASE_SERVICE_ACCOUNT_JSON', 'IMAGEKIT_PUBLIC_KEY']) assert.match(t, new RegExp(`^${k}=$`, 'm'));
});

test('every JS file parses', () => {
  for (const f of walk(ROOT).filter((x) => /\.(js|mjs)$/.test(x) && !x.includes('/public/'))) execFileSync(process.execPath, ['--check', f]);
});
