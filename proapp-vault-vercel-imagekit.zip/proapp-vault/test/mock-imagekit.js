// In-memory stand-in for ImageKit (upload API, Media API, and the CDN that serves files), used ONLY by tests.
// It re-implements ImageKit's documented rules independently of the production code:
//   * client-side upload:  publicKey + token + expire + signature, signature = HMAC-SHA1(privateKey, token + expire) hex,
//                          expire must be in the future but less than 1 hour away, a token can be used only once
//   * server-side upload:  HTTP Basic auth with the private key
//   * Media API:           HTTP Basic auth with the private key (files list / details / delete)
//   * private files:       served only with ?ik-t=<expiry>&ik-s=HMAC-SHA1(privateKey, <path after endpoint, no leading slash> + <expiry>)
// It is NOT the real service: real ImageKit behaviour must still be verified after deployment.
import crypto from 'node:crypto';

export const IK = { publicKey: 'public_test_key_123', privateKey: 'private_test_key_456', id: 'testid' };

const hmac = (msg) => crypto.createHmac('sha1', IK.privateKey).update(msg).digest('hex');

export function createImageKitMock() {
  const files = new Map(); // fileId -> { fileId, name, filePath, size, mime, isPrivateFile, bytes, createdAt }
  const usedTokens = new Set();
  const state = { privateSupported: true, log: [] };
  let seq = 0;

  const json = (res, status, body) => {
    res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*' });
    res.end(JSON.stringify(body));
  };
  const basicOk = (req) => req.headers.authorization === `Basic ${Buffer.from(`${IK.privateKey}:`).toString('base64')}`;
  const pub = (f) => ({ fileId: f.fileId, name: f.name, filePath: f.filePath, size: f.size, mime: f.mime, fileType: f.mime.startsWith('image/') ? 'image' : 'non-image', isPrivateFile: f.isPrivateFile, createdAt: f.createdAt });

  async function upload(req, res, raw) {
    const form = await new Request('http://x/', { method: 'POST', headers: { 'content-type': req.headers['content-type'] }, body: raw }).formData();
    const get = (k) => form.get(k);
    if (!basicOk(req)) {
      const { publicKey, token, expire, signature } = Object.fromEntries(['publicKey', 'token', 'expire', 'signature'].map((k) => [k, get(k)]));
      if (!token || !expire || !signature) return json(res, 400, { message: 'Your request is missing token, expire or signature' });
      if (publicKey !== IK.publicKey) return json(res, 401, { message: 'Your account cannot be authenticated.' });
      if (signature !== hmac(`${token}${expire}`)) return json(res, 401, { message: 'Your request contains invalid signature.' });
      const now = Math.floor(Date.now() / 1000);
      if (Number(expire) <= now) return json(res, 400, { message: 'Your request expired.' });
      if (Number(expire) > now + 3600) return json(res, 400, { message: 'expire should be less than 1 hour in the future.' });
      if (usedTokens.has(token)) return json(res, 400, { message: 'Token already used.' });
      usedTokens.add(token);
    }
    const file = get('file');
    if (!file || typeof file === 'string') return json(res, 400, { message: 'file is required' });
    const folder = String(get('folder') || '/').replace(/\/+$/, '');
    if (!/^(\/[A-Za-z0-9_-]+)*$/.test(folder)) return json(res, 400, { message: 'invalid folder' });
    let name = String(get('fileName') || file.name).replace(/[^A-Za-z0-9._-]/g, '_');
    if (get('useUniqueFileName') !== 'false') name = name.replace(/(\.[^.]*)?$/, (ext) => `_${crypto.randomBytes(3).toString('hex')}${ext || ''}`);
    const bytes = Buffer.from(await file.arrayBuffer());
    const f = {
      fileId: crypto.randomBytes(12).toString('hex'),
      name,
      filePath: `${folder}/${name}`,
      size: bytes.length,
      mime: file.type || 'application/octet-stream',
      isPrivateFile: get('isPrivateFile') === 'true' && state.privateSupported,
      bytes,
      createdAt: new Date(Date.now() + ++seq).toISOString(),
    };
    files.set(f.fileId, f);
    state.log.push(`upload ${f.filePath}`);
    return json(res, 200, { ...pub(f), url: `https://ik.imagekit.io/${IK.id}${f.filePath}` }); // real ImageKit answers with its own domain
  }

  function api(req, res, url) {
    if (!basicOk(req)) return json(res, 401, { message: 'Your account cannot be authenticated.' });
    const p = url.pathname.replace('/ik/api/v1', '');
    let m;
    if (req.method === 'GET' && p === '/files') {
      const dir = url.searchParams.get('path');
      const limit = Number(url.searchParams.get('limit') || 1000);
      const skip = Number(url.searchParams.get('skip') || 0);
      const rows = [...files.values()].filter((f) => f.filePath.startsWith(`${dir}/`) && !f.filePath.slice(dir.length + 1).includes('/')).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      return json(res, 200, rows.slice(skip, skip + limit).map(pub));
    }
    if (req.method === 'GET' && (m = /^\/files\/([^/]+)\/details$/.exec(p))) {
      const f = files.get(m[1]);
      return f ? json(res, 200, pub(f)) : json(res, 404, { message: 'The requested asset does not exist.' });
    }
    if (req.method === 'DELETE' && (m = /^\/files\/([^/]+)$/.exec(p))) {
      if (!files.has(m[1])) return json(res, 404, { message: 'The requested file does not exist.' });
      state.log.push(`delete ${files.get(m[1]).filePath}`);
      files.delete(m[1]);
      res.writeHead(204, { 'Access-Control-Allow-Origin': '*' });
      return res.end();
    }
    return json(res, 404, { message: `mock: unhandled ${req.method} ${p}` });
  }

  /** The CDN: GET /ik/media/<id>/<path>[?ik-t&ik-s&tr] */
  function cdn(req, res, url) {
    const rel = decodeURIComponent(url.pathname.replace(`/ik/media/${IK.id}/`, ''));
    const f = [...files.values()].find((x) => x.filePath === `/${rel}`);
    if (!f) return json(res, 404, { message: 'not found' });
    if (f.isPrivateFile) {
      const t = url.searchParams.get('ik-t');
      const s = url.searchParams.get('ik-s');
      // signed over the path as it appears in the URL (encoded), exactly as the docs describe
      const encodedRel = url.pathname.replace(`/ik/media/${IK.id}/`, '');
      if (!t || !s || s !== hmac(`${encodedRel}${t}`)) return json(res, 401, { message: 'signature missing or invalid' });
      if (Number(t) < Math.floor(Date.now() / 1000)) return json(res, 401, { message: 'signed URL expired' });
    }
    const range = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range || '');
    const headers = { 'Content-Type': f.mime, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*', 'Cross-Origin-Resource-Policy': 'cross-origin' };
    if (range) {
      const start = Number(range[1]);
      const end = range[2] ? Math.min(Number(range[2]), f.size - 1) : f.size - 1;
      res.writeHead(206, { ...headers, 'Content-Range': `bytes ${start}-${end}/${f.size}`, 'Content-Length': end - start + 1 });
      return res.end(f.bytes.subarray(start, end + 1));
    }
    res.writeHead(200, { ...headers, 'Content-Length': f.size });
    return res.end(f.bytes);
  }

  return {
    files,
    state,
    /** returns true when the request belonged to ImageKit */
    async handle(req, res, url, raw) {
      if (!url.pathname.startsWith('/ik/')) return false;
      if (req.method === 'OPTIONS') return (res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' }), res.end(), true);
      if (url.pathname === '/ik/upload') await upload(req, res, raw);
      else if (url.pathname.startsWith('/ik/api/v1/')) api(req, res, url);
      else if (url.pathname.startsWith('/ik/media/')) cdn(req, res, url);
      else json(res, 404, { message: 'mock: no route' });
      return true;
    },
    env(baseUrl) {
      return {
        IMAGEKIT_PUBLIC_KEY: IK.publicKey,
        IMAGEKIT_PRIVATE_KEY: IK.privateKey,
        IMAGEKIT_URL_ENDPOINT: `${baseUrl}/ik/media/${IK.id}`,
        IMAGEKIT_API_BASE: `${baseUrl}/ik/api/v1`,
        IMAGEKIT_UPLOAD_URL: `${baseUrl}/ik/upload`,
      };
    },
  };
}
