// In-memory stand-ins for Google services, used ONLY by tests:
//   - Firestore REST (get, batchGet, runQuery, runAggregationQuery, commit with preconditions + transforms)
//   - Google OAuth token endpoint and Firebase JWKS
//   - Firebase Auth REST (signUp, signInWithPassword, token refresh, update, sendOobCode) and Identity admin calls
//   - ImageKit upload, Media API and CDN (see mock-imagekit.js)
// It does NOT enforce firestore.rules (those need the Firebase emulator; see README "Testing").
import http from 'node:http';
import crypto from 'node:crypto';
import { createImageKitMock } from './mock-imagekit.js';

export const PROJECT = 'test-project';
const b64u = (b) => Buffer.from(b).toString('base64url');

export function createMock() {
  const imagekit = createImageKitMock();
  const docs = new Map(); // "col/id" -> { fields, createTime, updateTime }
  const users = new Map(); // auth users: email -> { uid, email, password, name, disabled, verified }
  const refreshTokens = new Map();
  const log = [];
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'test-kid', alg: 'RS256', use: 'sig' };
  const saPair = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  let clock = Date.now();
  const tick = () => new Date((clock += 1)).toISOString();

  const signIdToken = (u, extra = {}) => {
    const now = Math.floor(Date.now() / 1000);
    const h = b64u(JSON.stringify({ alg: 'RS256', kid: 'test-kid', typ: 'JWT' }));
    const p = b64u(
      JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, auth_time: now, user_id: u.uid, sub: u.uid, iat: now, exp: now + 3600, email: u.email, email_verified: !!u.verified, name: u.name || undefined, ...extra }),
    );
    const sig = crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), privateKey);
    return `${h}.${p}.${b64u(sig)}`;
  };

  const newAuthUser = (email, password) => {
    const u = { uid: crypto.randomBytes(14).toString('hex'), email, password, name: '', disabled: false, verified: false };
    users.set(email, u);
    return u;
  };
  const tokensFor = (u) => {
    const refreshToken = crypto.randomBytes(16).toString('hex');
    refreshTokens.set(refreshToken, u.email);
    return { idToken: signIdToken(u), refreshToken, localId: u.uid, email: u.email, expiresIn: '3600' };
  };

  // ---------- value helpers (independent re-implementation, so tests do not just echo the production code)
  const dec = (v) => {
    if ('nullValue' in v) return null;
    if ('integerValue' in v) return Number(v.integerValue);
    if ('doubleValue' in v) return v.doubleValue;
    if ('booleanValue' in v) return v.booleanValue;
    if ('timestampValue' in v) return v.timestampValue;
    if ('stringValue' in v) return v.stringValue;
    if ('arrayValue' in v) return (v.arrayValue.values || []).map(dec);
    if ('mapValue' in v) return Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k, x]) => [k, dec(x)]));
    return null;
  };
  const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
  const pathOf = (name) => name.split('/documents/')[1];
  const toDoc = (path) => {
    const d = docs.get(path);
    return { name: `projects/${PROJECT}/databases/(default)/documents/${path}`, fields: d.fields, createTime: d.createTime, updateTime: d.updateTime };
  };
  const fieldVal = (d, f) => (d.fields[f] ? dec(d.fields[f]) : undefined);

  function runQuery(sq) {
    const col = sq.from[0].collectionId;
    let rows = [...docs.entries()].filter(([p]) => p.startsWith(`${col}/`) && p.split('/').length === 2);
    const filters = !sq.where ? [] : sq.where.compositeFilter ? sq.where.compositeFilter.filters : [sq.where];
    for (const { fieldFilter: f } of filters) {
      const want = dec(f.value);
      rows = rows.filter(([, d]) => {
        const v = fieldVal(d, f.field.fieldPath);
        switch (f.op) {
          case 'EQUAL': return v === want;
          case 'LESS_THAN': return v !== undefined && v < want;
          case 'LESS_THAN_OR_EQUAL': return v !== undefined && v <= want;
          case 'GREATER_THAN': return v !== undefined && v > want;
          case 'GREATER_THAN_OR_EQUAL': return v !== undefined && v >= want;
          case 'ARRAY_CONTAINS': return Array.isArray(v) && v.includes(want);
          case 'IN': return Array.isArray(want) && want.includes(v);
          default: throw new Error(`mock: unsupported op ${f.op}`);
        }
      });
    }
    for (const o of [...(sq.orderBy || [])].reverse()) {
      const f = o.field.fieldPath;
      rows = rows.filter(([, d]) => d.fields[f] !== undefined); // Firestore drops docs missing the ordered field
      rows.sort(([, a], [, b]) => cmp(fieldVal(a, f), fieldVal(b, f)) * (o.direction === 'DESCENDING' ? -1 : 1));
    }
    return rows.slice(sq.offset || 0, (sq.offset || 0) + (sq.limit || 1e9));
  }

  function commit(writes) {
    // validate first so a failure leaves nothing applied (atomic)
    const staged = new Map();
    const get = (p) => (staged.has(p) ? staged.get(p) : docs.get(p) || null);
    for (const w of writes) {
      const path = pathOf(w.update?.name || w.delete);
      const cur = get(path);
      const pre = w.currentDocument;
      if (pre) {
        if (pre.exists === true && !cur) throw { code: 404, status: 'NOT_FOUND', message: `No document to update: ${path}` };
        if (pre.exists === false && cur) throw { code: 409, status: 'ALREADY_EXISTS', message: `Document already exists: ${path}` };
        if (pre.updateTime && (!cur || cur.updateTime !== pre.updateTime)) throw { code: 400, status: 'FAILED_PRECONDITION', message: 'updateTime mismatch' };
      }
      if (w.delete) {
        staged.set(path, null);
        continue;
      }
      let next;
      if (w.updateMask) {
        next = { fields: { ...(cur?.fields || {}) }, createTime: cur?.createTime || tick(), updateTime: tick() };
        for (const f of w.updateMask.fieldPaths) if (w.update.fields[f]) next.fields[f] = w.update.fields[f];
      } else next = { fields: { ...w.update.fields }, createTime: cur?.createTime || tick(), updateTime: tick() };
      for (const t of w.updateTransforms || []) {
        if (t.setToServerValue) next.fields[t.fieldPath] = { timestampValue: new Date().toISOString() };
        else next.fields[t.fieldPath] = { integerValue: String(Number(dec(next.fields[t.fieldPath] || { integerValue: '0' })) + Number(t.increment.integerValue)) };
      }
      staged.set(path, next);
    }
    for (const [p, d] of staged) (d === null ? docs.delete(p) : docs.set(p, d));
  }

  const send = (res, status, body) => {
    res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' });
    res.end(JSON.stringify(body));
  };
  const gerr = (res, e) => send(res, e.code || 500, { error: { code: e.code || 500, status: e.status || 'INTERNAL', message: e.message || String(e) } });

  const server = http.createServer(async (req, res) => {
    if (req.method === 'OPTIONS') return send(res, 204, {});
    const url = new URL(req.url, 'http://x');
    const rawBuf = await new Promise((r) => {
      const c = [];
      req.on('data', (d) => c.push(d));
      req.on('end', () => r(Buffer.concat(c)));
    });
    if (await imagekit.handle(req, res, url, rawBuf)) return;
    const raw = rawBuf.toString();
    let body = {};
    const ct = req.headers['content-type'] || '';
    if (raw) body = ct.includes('urlencoded') ? Object.fromEntries(new URLSearchParams(raw)) : JSON.parse(raw);
    log.push(`${req.method} ${url.pathname}`);
    const p = url.pathname;
    try {
      if (p === '/oauth/token') return send(res, 200, { access_token: 'mock-access-token', expires_in: 3600 });
      if (p === '/jwks') return send(res, 200, { keys: [jwk] });

      // ---- Firebase Auth REST
      if (p.endsWith('/accounts:signUp')) {
        if (users.has(body.email)) return send(res, 400, { error: { message: 'EMAIL_EXISTS' } });
        if (String(body.password || '').length < 6) return send(res, 400, { error: { message: 'WEAK_PASSWORD : Password should be at least 6 characters' } });
        return send(res, 200, tokensFor(newAuthUser(body.email, body.password)));
      }
      if (p.endsWith('/accounts:signInWithPassword')) {
        const u = users.get(body.email);
        if (!u || u.password !== body.password) return send(res, 400, { error: { message: 'INVALID_LOGIN_CREDENTIALS' } });
        if (u.disabled) return send(res, 400, { error: { message: 'USER_DISABLED' } });
        return send(res, 200, tokensFor(u));
      }
      if (p.endsWith('/v1/token')) {
        const email = refreshTokens.get(body.refresh_token);
        const u = email && users.get(email);
        if (!u) return send(res, 400, { error: { message: 'INVALID_REFRESH_TOKEN' } });
        if (u.disabled) return send(res, 400, { error: { message: 'USER_DISABLED' } });
        return send(res, 200, { id_token: signIdToken(u), refresh_token: body.refresh_token, user_id: u.uid, expires_in: '3600' });
      }
      if (p.endsWith('/accounts:sendOobCode')) return send(res, 200, { email: body.email || 'x' });
      if (p.endsWith('/accounts:update') && body.idToken) {
        const claims = JSON.parse(Buffer.from(body.idToken.split('.')[1], 'base64url'));
        const u = [...users.values()].find((x) => x.uid === claims.sub);
        if (!u) return send(res, 400, { error: { message: 'USER_NOT_FOUND' } });
        if (body.displayName !== undefined) u.name = body.displayName;
        if (body.password) u.password = body.password;
        return send(res, 200, tokensFor(u));
      }
      // ---- Identity admin (service account)
      const admin = /\/projects\/[^/]+\/accounts:(update|delete)$/.exec(p);
      if (admin) {
        const u = [...users.values()].find((x) => x.uid === body.localId);
        if (!u) return send(res, 400, { error: { message: 'USER_NOT_FOUND' } });
        if (admin[1] === 'delete') users.delete(u.email);
        else if (body.disableUser !== undefined) u.disabled = !!body.disableUser;
        return send(res, 200, {});
      }

      // ---- Firestore
      const fsBase = `/v1/projects/${PROJECT}/databases/(default)/documents`;
      if (!p.startsWith(fsBase)) return send(res, 404, { error: { message: `mock: no route ${p}` } });
      const rest = decodeURIComponent(p.slice(fsBase.length));
      if (rest === ':runQuery') {
        const rows = runQuery(body.structuredQuery);
        return send(res, 200, rows.length ? rows.map(([path]) => ({ document: toDoc(path), readTime: tick() })) : [{ readTime: tick() }]);
      }
      if (rest === ':batchGet') return send(res, 200, body.documents.map((n) => (docs.has(pathOf(n)) ? { found: toDoc(pathOf(n)) } : { missing: n })));
      if (rest === ':commit') {
        try {
          commit(body.writes);
        } catch (e) {
          return gerr(res, e);
        }
        return send(res, 200, { writeResults: body.writes.map(() => ({})) });
      }
      if (rest === ':runAggregationQuery') {
        const q = body.structuredAggregationQuery;
        const rows = runQuery({ ...q.structuredQuery, limit: undefined });
        const aggregateFields = {};
        for (const a of q.aggregations) {
          if (a.count) aggregateFields[a.alias] = { integerValue: String(rows.length) };
          else {
            const f = a.sum.field.fieldPath;
            aggregateFields[a.alias] = { integerValue: String(rows.reduce((s, [, d]) => s + (Number(fieldVal(d, f)) || 0), 0)) };
          }
        }
        return send(res, 200, [{ result: { aggregateFields }, readTime: tick() }]);
      }
      if (req.method === 'GET' && rest.startsWith('/')) {
        const path = rest.slice(1);
        return docs.has(path) ? send(res, 200, toDoc(path)) : send(res, 404, { error: { code: 404, status: 'NOT_FOUND', message: 'not found' } });
      }
      return send(res, 404, { error: { message: `mock: unhandled ${req.method} ${p}` } });
    } catch (e) {
      console.error('mock error', e);
      return send(res, 500, { error: { message: String(e) } });
    }
  });

  return {
    docs,
    imagekit,
    users,
    log,
    publicJwk: jwk,
    signIdToken,
    newAuthUser,
    /** read a doc as plain JS (for assertions) */
    read(path) {
      const d = docs.get(path);
      return d ? Object.fromEntries(Object.entries(d.fields).map(([k, v]) => [k, dec(v)])) : null;
    },
    ids(col) {
      return [...docs.keys()].filter((k) => k.startsWith(`${col}/`)).map((k) => k.split('/')[1]);
    },
    serviceAccountJson() {
      return JSON.stringify({
        client_email: 'sa@test-project.iam.gserviceaccount.com',
        private_key: saPair.privateKey.export({ type: 'pkcs8', format: 'pem' }),
        token_uri: `${this.url}/oauth/token`,
      });
    },
    start() {
      return new Promise((resolve) =>
        server.listen(0, '127.0.0.1', () => {
          this.url = `http://127.0.0.1:${server.address().port}`;
          resolve(this);
        }),
      );
    },
    stop: () => new Promise((r) => server.close(r)),
  };
}
