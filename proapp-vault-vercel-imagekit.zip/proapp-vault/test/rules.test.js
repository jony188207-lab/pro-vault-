// Static checks on firestore.rules. These do NOT replace running the rules against the Firebase emulator
// (see README "Testing the security rules"), but they catch the most dangerous mistakes: any rule that lets a browser write.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const rules = fs.readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8').replace(/\/\/.*$/gm, '');

test('no rule allows a browser to create, update, delete or write', () => {
  const allows = [...rules.matchAll(/allow\s+([^:]+):\s*if\s+([^;]+);/g)].map((m) => ({ ops: m[1].split(',').map((x) => x.trim()), cond: m[2].trim() }));
  assert.ok(allows.length > 5);
  for (const a of allows) {
    const writes = a.ops.filter((o) => ['write', 'create', 'update', 'delete'].includes(o));
    if (writes.length) assert.equal(a.cond, 'false', `write operations ${writes} must be "if false" but got "${a.cond}"`);
  }
  // the catch-all denies everything not listed
  assert.match(rules, /match \/\{document=\*\*\}\s*\{\s*allow read, write: if false;/);
});

test('sensitive collections are not readable by the public', () => {
  for (const col of ['views', 'unlocks', 'adSessions']) assert.doesNotMatch(rules, new RegExp(`match /${col}/`), `${col} must fall through to the deny-all rule`);
  const users = /match \/users\/\{uid\}\s*\{([\s\S]*?)\n    \}/.exec(rules)[1];
  assert.match(users, /allow get: if signedIn\(\) && \(request\.auth\.uid == uid \|\| isAdmin\(\)\)/);
  assert.doesNotMatch(users, /allow (get, )?list: if true/);
});

test('admin check reads the role from the protected profile document, not from the request', () => {
  assert.match(rules, /get\(profilePath\(request\.auth\.uid\)\)\.data\.role == 'admin'/);
  assert.doesNotMatch(rules, /request\.auth\.token\.(admin|role)/);
});
