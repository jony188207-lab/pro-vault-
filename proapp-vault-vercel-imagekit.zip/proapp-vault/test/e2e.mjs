// End-to-end browser test (Playwright + Chromium) against the local rig: real frontend, real api/index.js (Vercel entry),
// mocked Google services. Run:  node test/e2e.mjs   (needs playwright; see README "Testing")
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { startRig } from './e2e-server.js';

const require = createRequire(import.meta.url);
let chromium;
try {
  ({ chromium } = require('playwright'));
} catch {
  ({ chromium } = require('/opt/npm-tools/node_modules/playwright'));
}

const SHOTS = process.env.SHOTS_DIR;
if (SHOTS) fs.mkdirSync(SHOTS, { recursive: true });

const rig = await startRig();
const { mock, siteOrigin } = rig;
const adminAuth = mock.newAuthUser('boss@site.test', 'adminpass1');
adminAuth.verified = true;

const MP4 = Buffer.from([0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d, 0, 0, 2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

const browser = await chromium.launch();
const problems = [];
let step = 0;
const log = (m) => console.log(`  ${String(++step).padStart(2, '0')} ${m}`);

async function newSession(name, viewport = { width: 390, height: 844 }) {
  const ctx = await browser.newContext({ viewport });
  await ctx.route('https://ads.example.com/**', (r) =>
    r.request().url().endsWith('.js') ? r.fulfill({ contentType: 'text/javascript', body: '/* fake ad script */' }) : r.fulfill({ contentType: 'text/html', body: '<html><body>Sponsor page</body></html>' }),
  );
  await ctx.route('https://fonts.googleapis.com/**', (r) => r.fulfill({ contentType: 'text/css', body: '' }));
  await ctx.route('https://fonts.gstatic.com/**', (r) => r.abort());
  const page = await ctx.newPage();
  page.on('console', (m) => {
    // 4xx/5xx resource errors are reported with their URL by the response listener below (some are expected)
    if (/Failed to load resource/.test(m.text())) return;
    if (m.type() === 'error' || /Content Security Policy|violates/i.test(m.text())) problems.push(`[${name}] console ${m.type()}: ${m.text()} @ ${m.location().url}`);
  });
  page.on('response', (r) => {
    if (r.status() < 400) return;
    const u = r.url();
    const expected = /\/api\/admin\/settings$/.test(u) && r.request().method() === 'PUT'; // deliberate invalid banner / policy tests
    const firstRun = /documents\/settings\/public$/.test(u); // no settings document until an admin saves once: the app falls back to defaults
    const expected2 = firstRun || /accounts:(signInWithPassword|signUp)/.test(u) || (/\/api\/admin\/videos$/.test(u) && r.request().method() === 'POST');
    if (!expected && !expected2 && !/accounts:update/.test(u)) problems.push(`[${name}] HTTP ${r.status()} ${r.request().method()} ${u}`);
  });
  page.on('pageerror', (e) => problems.push(`[${name}] pageerror: ${e.message} ${e.stack?.split('\n')[1] || ''}`));
  page.on('requestfailed', (r) => {
    if (!/fonts\.gstatic|ads\.example\.com|favicon/.test(r.url())) problems.push(`[${name}] request failed: ${r.url()} ${r.failure()?.errorText}`);
  });
  return { ctx, page };
}

const shot = async (page, name) => SHOTS && (await page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: false }));
const go = async (page, hash) => {
  await page.goto(`${siteOrigin}/${hash}`);
  await page.waitForSelector('main#main > *', { timeout: 10000 });
};
const toastText = (page, re) => page.locator('.toast').filter({ hasText: re }).first().waitFor({ timeout: 8000 });

async function login(page, email, password) {
  await go(page, '#/login');
  await page.fill('#email', email);
  await page.fill('#password', password);
  await page.click('button[type=submit]');
  await page.waitForSelector('.avatar', { timeout: 8000 });
}

try {
  // ============================================================== visitor
  console.log('Visitor');
  const visitor = await newSession('visitor');
  let p = visitor.page;
  await go(p, '');
  await p.getByText('No videos yet').waitFor();
  assert.equal(await p.locator('h1').first().innerText(), 'ProApp Vault');
  log('home shows empty state and site name');
  await p.goto(`${siteOrigin}/#/saved`);
  await p.waitForSelector('#email');
  log('protected route redirects to login');
  await p.goto(`${siteOrigin}/#/admin`);
  await p.waitForSelector('#email');
  log('admin route redirects to login for visitors');
  await p.goto(`${siteOrigin}/#/does-not-exist`);
  await p.getByText('Page not found').waitFor();
  log('unknown route shows a not-found page');

  // ============================================================== admin
  console.log('Admin');
  const adm = await newSession('admin');
  p = adm.page;
  await login(p, 'boss@site.test', 'adminpass1');
  await p.locator('.tab', { hasText: 'Admin' }).waitFor();
  log('bootstrap admin logs in and sees the Admin tab');

  await go(p, '#/admin/settings');
  await p.fill('#s-list', '1');
  await p.fill('#s-pop', '3');
  await p.click('button:has-text("Save settings")');
  await toastText(p, /Settings saved/);
  assert.equal(mock.read('settings/public').homeListLimit, 1);
  log('admin saves home-list limit = 1');

  await go(p, '#/admin/ads');
  await p.fill('#b-html', '<script>atOptions = {"key":"abc","format":"iframe","height":60,"width":468,"params":{}};</script><script src="https://ads.example.com/abc/invoke.js"></script>');
  await p.fill('#b-w', '468');
  await p.fill('#b-h', '60');
  await p.check('#b-on');
  await p.click('button:has-text("Save banner")');
  await toastText(p, /Banner saved/);
  await p.waitForSelector('iframe[title="Banner preview"]');
  log('admin saves an Adsterra-style banner (accepted, preview shown)');

  await p.fill('#b-html', '<script>alert(document.cookie)</script>');
  await p.click('button:has-text("Save banner")');
  await toastText(p, /Inline scripts are limited/);
  log('malicious banner HTML is rejected with an explanation');

  // gate can not be enabled without acknowledging network policy
  await p.check('#g-watch');
  await p.click('button:has-text("Save unlock settings")');
  await toastText(p, /confirm that your ad network allows/);
  await p.check('#g-ack');
  await p.check('#g-save');
  await p.fill('#g-away', '2');
  await p.click('button:has-text("Save unlock settings")');
  await toastText(p, /Unlock settings saved/);
  log('ad gate requires policy acknowledgement, then saves');

  await p.fill('#t-watchInstruction', 'আগে 5 সেকেন্ড অ্যাড দেখুন তারপর ফিরে আসুন');
  await p.fill('#t-watchButton', 'এখনই দেখুন');
  await p.fill('#t-openAdButton', 'Open sponsor');
  await p.click('button:has-text("Save texts")');
  await toastText(p, /Texts saved/);
  assert.equal(mock.read('settings/public').texts.openAdButton, 'Open sponsor');
  log('admin customises instruction and button labels');
  await shot(p, 'admin-ads');

  // create video through the real upload UI
  await go(p, '#/admin/videos/new');
  await p.setInputFiles('#f-video', { name: 'big_buck demo.mp4', mimeType: 'video/mp4', buffer: MP4 });
  await p.setInputFiles('#f-thumb', { name: 'thumb.png', mimeType: 'image/png', buffer: PNG });
  await p.waitForFunction(() => document.querySelector('#f-title').value.length > 0);
  await p.fill('#f-title', 'Mountain Sunrise Demo');
  await p.fill('#f-desc', 'A calm sunrise.\n\nShot on location.');
  await p.fill('#f-tags', 'nature, sunrise');
  await p.selectOption('#f-status', 'published');
  await p.check('#f-ad-on');
  await p.fill('#f-ad-url', 'http://not-secure.test');
  await p.click('button:has-text("Create video")');
  await p.getByText('The ad URL must start with https://').waitFor();
  await p.fill('#f-ad-url', 'https://ads.example.com/offer?sid={sid}');
  await p.click('button:has-text("Create video")');
  await toastText(p, /Video created/);
  await p.waitForURL(/#\/admin\/videos$/);
  assert.equal(mock.ids('videos').length, 1);
  assert.equal(rig.imagekit.files.size, 2, 'video + thumbnail uploaded straight to ImageKit');
  const storedVideo = mock.read(`videos/${mock.ids('videos')[0]}`);
  assert.match(storedVideo.videoUrl, /\/proapp-vault\/videos\//);
  assert.match(storedVideo.thumbnailUrl, /\/proapp-vault\/thumbs\//);
  log('admin uploads video + thumbnail and creates the video with its own ad URL');
  const vid = mock.ids('videos')[0];

  // second video without ad, to test list limit + pagination
  await go(p, '#/admin/videos/new');
  await p.setInputFiles('#f-video', { name: 'second.mp4', mimeType: 'video/mp4', buffer: MP4 });
  await p.fill('#f-title', 'Second Clip');
  await p.selectOption('#f-status', 'published');
  await p.click('button:has-text("Create video")');
  await p.waitForURL(/#\/admin\/videos$/);
  await p.waitForFunction(() => document.querySelectorAll('.toast').length > 0);
  for (let i = 0; i < 50 && mock.ids('videos').length < 2; i++) await new Promise((r) => setTimeout(r, 100));
  const vid2 = mock.ids('videos').find((x) => x !== vid);
  assert.ok(vid2, 'second video exists');
  log('second video (no ad) created');

  // ============================================================== member
  console.log('Member');
  const mem = await newSession('alice');
  p = mem.page;
  await go(p, '#/signup');
  await p.fill('#name', 'Alice');
  await p.fill('#email', 'alice@site.test');
  await p.fill('#password', '12');
  await p.click('button[type=submit]');
  await p.getByText('Password must be at least 6 characters.').waitFor();
  await p.fill('#password', 'secret123');
  await p.click('button[type=submit]');
  await p.waitForSelector('.avatar');
  const aliceUid = mock.users.get('alice@site.test').uid;
  assert.equal(mock.read(`users/${aliceUid}`).displayName, 'Alice');
  assert.equal(mock.read(`users/${aliceUid}`).role, 'user');
  log('sign-up validates, creates Firebase user + server profile (role=user)');

  await p.waitForSelector('.vcard');
  assert.equal(await p.locator('.grid .vcard').count(), 1, 'home list limit of 1 is respected');
  await p.getByRole('button', { name: 'Show more videos' }).click();
  await p.waitForFunction(() => document.querySelectorAll('.grid .vcard').length === 2);
  log('home list honours the admin limit and "Show more" loads the rest');
  await p.waitForSelector('iframe.banner-frame');
  const frameEl = await p.$('iframe.banner-frame');
  const frame = await frameEl.contentFrame();
  await frame.waitForSelector('body');
  log('banner renders in a sandboxed iframe below the popular area');
  assert.equal(await p.locator('.popular').count(), 0, 'popular strip hidden while no video has views');
  await shot(p, 'home');

  // search
  await p.fill('input[name=q]', 'sunr');
  await p.waitForSelector('.result-count');
  assert.equal(await p.locator('.grid .vcard').count(), 1);
  await p.fill('input[name=q]', 'zzzz');
  await p.getByText('No matches').waitFor();
  await p.fill('input[name=q]', '');
  await p.waitForSelector('.hero');
  log('search finds by prefix, shows empty state for no match, clears');

  // video page, gated
  await go(p, `#/v/${vid}`);
  await p.getByText('Mountain Sunrise Demo').first().waitFor();
  await p.locator('.gate').waitFor();
  assert.equal(await p.locator('.overlay-card h2').innerText(), 'Locked');
  assert.equal(await p.locator('button:has-text("এখনই দেখুন")').count(), 0, 'Watch button hidden before unlock');
  await p.getByText('আগে 5 সেকেন্ড অ্যাড দেখুন তারপর ফিরে আসুন').first().waitFor();
  log('video is locked; admin-written Bangla instruction shown; Watch button absent');
  await shot(p, 'video-locked');

  const [popup] = await Promise.all([p.waitForEvent('popup'), p.click('button:has-text("Open sponsor")')]);
  await popup.waitForURL(/ads\.example\.com\/offer\?sid=[0-9a-f-]{36}/, { timeout: 8000 });
  await popup.close();
  const unlockBtn = p.locator('button:has-text("আমি ফিরে এসেছি")');
  await unlockBtn.waitFor();
  assert.equal(await unlockBtn.isDisabled(), true);
  log('sponsor page opens in a new tab with a session id; unlock button waits');
  await p.waitForFunction(() => !document.querySelector('.gate button.btn.primary:disabled'), null, { timeout: 8000 });
  await unlockBtn.click();
  await p.locator('button:has-text("এখনই দেখুন")').waitFor();
  log('after the server-measured wait the unlock succeeds and Watch appears');
  await p.locator('button:has-text("এখনই দেখুন")').click();
  await p.waitForSelector('video.video-el');
  const src = await p.getAttribute('video.video-el', 'src');
  assert.match(src, /\/proapp-vault\/videos\/.*[?&]ik-s=[0-9a-f]{40}/, 'player gets a signed ImageKit URL');
  await p.getByText(/1 views/).waitFor();
  assert.equal(mock.read(`videos/${vid}`).views, 1);
  log('Watch plays through a signed ImageKit URL; server-side view count = 1');
  const hdr = await p.evaluate(async (u) => {
    const r = await fetch(u, { headers: { Range: 'bytes=4-7' } });
    return { s: r.status, t: await r.text() };
  }, src);
  assert.deepEqual(hdr, { s: 206, t: 'ftyp' });
  log('ImageKit CDN (mock) serves range requests for the signed URL');

  // like / unlike
  await p.getByRole('button', { name: /^Like$/ }).click();
  await p.getByRole('button', { name: /Liked/ }).waitFor();
  await p.getByText(/1 likes/).waitFor();
  assert.equal(mock.read(`videos/${vid}`).likes, 1);
  await p.reload();
  await p.getByRole('button', { name: /Liked/ }).waitFor();
  await p.getByRole('button', { name: /Liked/ }).click();
  await p.getByRole('button', { name: /^Like$/ }).waitFor();
  await p.getByText(/0 likes/).waitFor();
  assert.equal(mock.ids('likes').length, 0);
  log('like persists across reload; unlike removes it');

  // comments
  await p.fill('textarea[aria-label="Add a comment"]', '<img src=x onerror=alert(1)> Nice!');
  await p.click('button:has-text("Post comment")');
  await p.locator('.comment').first().waitFor();
  assert.equal(await p.locator('.comment-text').first().innerText(), '<img src=x onerror=alert(1)> Nice!');
  assert.equal(await p.locator('.comment img').count(), 0);
  await p.getByText(/1 comments/).waitFor();
  await p.reload();
  await p.locator('.comment time').first().waitFor();
  log('comment posts with timestamp; HTML is shown as text and not executed');
  await shot(p, 'video-playing');

  // save requires sponsor step
  await p.getByRole('button', { name: 'সেভ করুন' }).click();
  await p.locator('.gate-save').waitFor();
  const [pop2] = await Promise.all([p.waitForEvent('popup'), p.locator('.gate-save button:has-text("স্পনসর")').click()]);
  await pop2.close();
  await p.waitForFunction(() => !document.querySelector('.gate-save button.btn.primary:disabled'), null, { timeout: 8000 });
  await p.locator('.gate-save button:has-text("আমি ফিরে এসেছি")').click();
  await p.getByRole('button', { name: /Saved/ }).waitFor();
  assert.ok(mock.read(`saves/${aliceUid}_${vid}`));
  log('saving requires the sponsor step, then saves automatically');
  await go(p, '#/saved');
  await p.locator('.vcard', { hasText: 'Mountain Sunrise Demo' }).waitFor();
  log('saved list shows the video');

  // popular strip now visible
  await go(p, '#/');
  await p.waitForSelector('.popular .pop');
  assert.equal(await p.locator('.popular .pop').first().innerText().then((t) => t.includes('Mountain Sunrise Demo')), true);
  log('most-viewed strip appears once a video has views');

  // second video without ad plays directly
  await go(p, `#/v/${vid2}`);
  await p.locator('button:has-text("এখনই দেখুন")').click();
  await p.waitForSelector('video.video-el');
  log('video without an assigned ad plays with no sponsor step');

  // profile
  await go(p, '#/profile');
  await p.fill('#dn', 'Alice Wonder');
  await p.click('button:has-text("Save name")');
  await toastText(p, /Name updated/);
  assert.equal(mock.read(`users/${aliceUid}`).displayName, 'Alice Wonder');
  await p.fill('#cp', 'wrong-password');
  await p.fill('#np', 'newsecret1');
  await p.click('button:has-text("Change password")');
  await toastText(p, /Wrong email or password/);
  await p.fill('#cp', 'secret123');
  await p.click('button:has-text("Change password")');
  await toastText(p, /Password changed/);
  assert.equal(mock.users.get('alice@site.test').password, 'newsecret1');
  log('profile: rename, wrong current password rejected, password change works');

  // profile photo: browser crops to JPEG, API validates and stores it in ImageKit
  await p.setInputFiles('#avatar-file', { name: 'me.png', mimeType: 'image/png', buffer: PNG });
  await toastText(p, /Profile photo updated/);
  const photo = mock.read(`users/${aliceUid}`);
  assert.match(photo.photoURL, /\/proapp-vault\/avatars\//);
  await p.waitForSelector('.profile-head .avatar img');
  await p.waitForFunction(() => { const i = document.querySelector('.profile-head .avatar img'); return i && i.complete && i.naturalWidth > 0; });
  assert.equal(rig.imagekit.files.get(photo.photoFileId).mime, 'image/jpeg');
  log('profile photo uploads through the API into ImageKit and renders from the ImageKit URL');
  await shot(p, 'profile');

  // session persistence and logout
  await p.reload();
  await p.waitForSelector('.profile-head');
  log('session survives a page reload (refresh token)');
  await p.getByRole('button', { name: 'Log out' }).click();
  await p.waitForSelector('a.btn:has-text("Log in")');
  await p.goto(`${siteOrigin}/#/saved`);
  await p.waitForSelector('#email');
  log('logout works and protected routes close again');

  // wrong password message
  await go(p, '#/login');
  await p.fill('#email', 'alice@site.test');
  await p.fill('#password', 'nope');
  await p.click('button[type=submit]');
  await p.getByText('Wrong email or password.').waitFor();
  log('login shows a friendly error for wrong credentials');

  // ============================================================== admin management
  console.log('Admin management');
  p = adm.page;
  await go(p, '#/admin');
  await p.waitForSelector('.stat');
  const statsText = await p.locator('.stat').allInnerTexts();
  assert.ok(statsText.some((t) => /Total users|Users/i.test(t)), `dashboard stats: ${statsText.join(' | ')}`);
  log(`dashboard renders ${statsText.length} stat tiles`);
  await shot(p, 'admin-dashboard');

  await go(p, '#/admin/users');
  await p.getByText('alice@site.test').waitFor();
  await shot(p, 'admin-users');
  log('user list shows members');
  await p.fill('input[aria-label="Search users by email"]', 'ali');
  await p.waitForFunction(() => document.querySelectorAll('.row-item').length === 1);
  await p.locator('.row-item', { hasText: 'alice@site.test' }).getByRole('button', { name: 'Suspend' }).click();
  await p.getByRole('button', { name: 'Confirm' }).click();
  await p.locator('.chip.warn', { hasText: 'suspended' }).waitFor();
  assert.equal(mock.read(`users/${aliceUid}`).status, 'suspended');
  assert.equal(mock.users.get('alice@site.test').disabled, true);
  log('admin suspends a user (profile + Firebase Auth account)');
  const blocked = await newSession('alice2');
  await go(blocked.page, '#/login');
  await blocked.page.fill('#email', 'alice@site.test');
  await blocked.page.fill('#password', 'newsecret1');
  await blocked.page.click('button[type=submit]');
  await blocked.page.getByText('This account has been suspended.').waitFor();
  await blocked.ctx.close();
  log('suspended user can not log in');
  await p.locator('.row-item', { hasText: 'alice@site.test' }).getByRole('button', { name: 'Restore' }).click();
  await p.getByRole('button', { name: 'Confirm' }).click();
  await p.locator('.chip.warn').waitFor({ state: 'detached' });
  assert.equal(mock.read(`users/${aliceUid}`).status, 'active');
  log('admin restores the user');

  await go(p, '#/admin/analytics');
  await p.getByText('Mountain Sunrise Demo').first().waitFor();
  log('analytics lists top videos');

  await go(p, '#/admin/media');
  await p.getByText('Used by').first().waitFor();
  assert.equal(await p.locator('.row-actions button:not([disabled])').count(), 0, 'both video files are in use, so no Delete button is enabled');
  log('media manager lists files; files in use have Delete disabled');
  await p.getByRole('tab', { name: /profile photos/i }).click();
  await p.locator('.row-item', { hasText: 'Alice' }).first().waitFor();
  assert.equal(await p.locator('.row-actions button:not([disabled])').count(), 0, 'the profile photo in use can not be deleted');
  log('media manager Profile photos tab shows the avatar as in use');

  await go(p, '#/admin/videos');
  await p.getByText('Mountain Sunrise Demo').waitFor();
  log('video list loads');
  await p.locator('.row-item', { hasText: 'Mountain Sunrise Demo' }).getByRole('button', { name: 'Delete' }).click();
  await p.getByLabel('Also delete the video and thumbnail files from storage').check();
  await p.getByRole('button', { name: 'Delete video' }).click();
  await toastText(p, /Video deleted/);
  assert.equal(mock.read(`videos/${vid}`), null);
  for (const col of ['likes', 'saves', 'comments', 'views', 'unlocks', 'adSessions']) {
    assert.equal(mock.docs.size && [...mock.docs.keys()].filter((k) => k.startsWith(`${col}/`) && mock.read(k)?.videoId === vid).length, 0, `${col} for the video removed`);
  }
  assert.equal([...rig.imagekit.files.values()].filter((f) => f.filePath.includes('/thumbs/')).length, 0, 'thumbnail removed from ImageKit');
  assert.equal([...rig.imagekit.files.values()].filter((f) => f.filePath.includes('/videos/')).length, 1, 'only the second video file remains');
  log('admin deletes a video with its data and stored files');
} catch (e) {
  console.error('\nFAILED:', e.message);
  for (const ctxPage of browser.contexts().flatMap((c) => c.pages())) {
    if (SHOTS) await ctxPage.screenshot({ path: `${SHOTS}/failure-${Date.now()}.png` }).catch(() => {});
  }
  problems.push(`test failure: ${e.stack}`);
} finally {
  await browser.close();
  await rig.stop();
}

if (problems.length) {
  console.error('\nProblems:\n' + problems.map((x) => ` - ${x}`).join('\n'));
  process.exit(1);
}
console.log('\nE2E passed with no console errors or CSP violations.');
