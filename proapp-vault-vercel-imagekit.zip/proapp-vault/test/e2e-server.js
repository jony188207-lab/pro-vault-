// Local test rig that mirrors the Vercel deployment: ONE origin serves the static frontend (public/) and /api/*,
// where /api/* is handled by the real api/index.js entry. Google services and ImageKit are the in-memory mocks.
// The Content-Security-Policy is read from vercel.json, with ImageKit's hosts swapped for the local mock.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createMock, PROJECT } from './mock-backend.js';
import { IK } from './mock-imagekit.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..', 'public');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };

function listen(server) {
  return new Promise((r) => server.listen(0, '127.0.0.1', () => r(server.address().port)));
}

export async function startRig() {
  const mock = await createMock().start();
  const vercel = JSON.parse(fs.readFileSync(path.join(HERE, '..', 'vercel.json'), 'utf8'));
  const csp = vercel.headers.find((h) => h.source.includes('(?!api/)')).headers.find((h) => h.key === 'Content-Security-Policy').value;

  // api/index.js reads process.env, exactly like a Vercel function
  Object.assign(process.env, {
    FIREBASE_PROJECT_ID: PROJECT,
    FIREBASE_SERVICE_ACCOUNT_JSON: mock.serviceAccountJson(),
    FIREBASE_JWKS_URL: `${mock.url}/jwks`,
    FIRESTORE_API_BASE: `${mock.url}/v1`,
    IDENTITY_API_BASE: `${mock.url}/v1`,
    BOOTSTRAP_ADMIN_EMAILS: 'boss@site.test',
    AD_SCRIPT_HOSTS: 'ads.example.com',
    MAX_VIDEO_BYTES: String(50 * 1024 * 1024),
    ...mock.imagekit.env(mock.url),
  });
  const { default: fn } = await import('../api/index.js');

  let siteOrigin = '';
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) {
      const chunks = [];
      for await (const c of req) chunks.push(c);
      const headers = new Headers();
      for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers.set(k, v);
      const request = new Request(`${siteOrigin}${req.url}`, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks) });
      const r = await fn.fetch(request);
      res.writeHead(r.status, Object.fromEntries(r.headers));
      return res.end(Buffer.from(await r.arrayBuffer()));
    }
    const file = url.pathname === '/' ? '/index.html' : url.pathname;
    if (file === '/js/config.js') {
      res.writeHead(200, { 'Content-Type': 'text/javascript' });
      return res.end(
        `window.PROAPP_CONFIG=${JSON.stringify({ firebase: { apiKey: 'test-key', projectId: PROJECT }, apiBase: '', imagekit: { urlEndpoint: `${mock.url}/ik/media/${IK.id}` }, overrides: { authBase: `${mock.url}/v1`, tokenBase: `${mock.url}/v1`, firestoreBase: `${mock.url}/v1` } })};`,
      );
    }
    const full = path.join(ROOT, path.normalize(file));
    if (!full.startsWith(ROOT) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) {
      res.writeHead(404);
      return res.end('not found');
    }
    // production policy; ImageKit's real hosts are replaced by the local mock origin
    const policy = csp.replaceAll('https://ik.imagekit.io', mock.url).replaceAll('https://upload.imagekit.io', mock.url).replace("connect-src 'self'", `connect-src 'self' ${mock.url}`);
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(full)] || 'application/octet-stream', 'Content-Security-Policy': policy });
    res.end(fs.readFileSync(full));
  });
  siteOrigin = `http://127.0.0.1:${await listen(server)}`;

  return {
    mock,
    imagekit: mock.imagekit,
    siteOrigin,
    csp,
    async stop() {
      await Promise.all([mock.stop(), new Promise((r) => server.close(r))]);
    },
  };
}
