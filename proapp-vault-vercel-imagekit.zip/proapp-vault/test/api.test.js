import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createMock, PROJECT } from './mock-backend.js';
import { IK } from './mock-imagekit.js';
import { handle } from '../server/src/index.js';
import { sanitizeBannerHtml } from '../server/src/lib/sanitize.js';
import { searchTokens } from '../server/src/lib/ids.js';
import { searchTokens as clientTokens } from '../public/js/lib/search.js';

const ORIGIN = 'https://site.test';
let mock;
let env;

const call = async (method, path, { token, body, raw, headers = {} } = {}) => {
  const h = { Origin: ORIGIN, ...headers };
  if (token) h.Authorization = `Bearer ${token}`;
  let payload = raw;
  if (body !== undefined && method !== 'GET') {
    payload = JSON.stringify(body);
    h['Content-Type'] = 'application/json';
  }
  const res = await handle(new Request(`https://api.test${path}`, { method, headers: h, body: payload }), env, {});
  const text = await res.clone().text();
  assert.ok(!text.includes(IK.privateKey), `response of ${method} ${path} leaked the ImageKit private key`);
  assert.ok(!text.includes('PRIVATE KEY'), `response of ${method} ${path} leaked a service-account key`);
  let data = null;
  try {
    data = JSON.parse(text);
  } catch {
    /* not json */
  }
  return { status: res.status, data, res, text };
};

const person = (email, { verified = true } = {}) => {
  const u = mock.newAuthUser(email, 'secret123');
  u.verified = verified;
  return { u, token: () => mock.signIdToken(u) };
};
const signin = async (p) => (await call('POST', '/api/session', { token: p.token() })).data?.user;

const MP4 = new Uint8Array([0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d, 0, 0, 2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3, 4]);


/** Do what the admin's browser does: ask our API for upload auth, then POST the file straight to ImageKit. */
const uploadToImageKit = async (t, kind, bytes, contentType, { sizeClaim } = {}) => {
  const a = await call('POST', '/api/admin/uploads/auth', { token: t, body: { kind, contentType, size: sizeClaim ?? bytes.length } });
  assert.equal(a.status, 200, a.text);
  const form = new FormData();
  form.append('file', new Blob([bytes], { type: contentType }), a.data.fileName);
  for (const k of ['fileName', 'publicKey', 'signature', 'token', 'folder', 'useUniqueFileName', 'isPrivateFile']) form.append(k, String(a.data[k]));
  form.append('expire', String(a.data.expire));
  const res = await fetch(a.data.uploadUrl, { method: 'POST', body: form });
  return { auth: a.data, status: res.status, body: await res.json() };
};

let admin;
let alice;
let bob;
let videoId;
let videoId2;

before(async () => {
  mock = await createMock().start();
  env = {
    FIREBASE_PROJECT_ID: PROJECT,
    FIREBASE_SERVICE_ACCOUNT_JSON: mock.serviceAccountJson(),
    FIREBASE_JWKS_URL: `${mock.url}/jwks`,
    FIRESTORE_API_BASE: `${mock.url}/v1`,
    IDENTITY_API_BASE: `${mock.url}/v1`,
    ALLOWED_ORIGINS: ORIGIN,
    BOOTSTRAP_ADMIN_EMAILS: 'boss@site.test',
    AD_SCRIPT_HOSTS: 'ads.example.com,*.adnet.test',
    AD_POSTBACK_SECRET: 'p'.repeat(24),
    MAX_VIDEO_BYTES: String(1024 * 1024),
    ...mock.imagekit.env(mock.url),
  };
  admin = person('boss@site.test');
  alice = person('alice@site.test');
  bob = person('bob@site.test');
});
after(() => mock.stop());

// ------------------------------------------------------------------------------------------------ auth
test('health + CORS only for the configured origin', async () => {
  const ok = await call('GET', '/api/health');
  assert.equal(ok.status, 200);
  assert.equal(ok.res.headers.get('Access-Control-Allow-Origin'), ORIGIN);
  const bad = await call('GET', '/api/health', { headers: { Origin: 'https://evil.test' } });
  assert.equal(bad.res.headers.get('Access-Control-Allow-Origin'), null);
  const pre = await call('OPTIONS', '/api/session');
  assert.equal(pre.status, 204);
});

test('requests without a valid token are rejected', async () => {
  assert.equal((await call('POST', '/api/session')).status, 401);
  assert.equal((await call('POST', '/api/session', { token: 'garbage' })).status, 401);
  // token signed by another key
  const forged = mock.signIdToken(alice.u).split('.');
  forged[2] = forged[2].slice(0, -4) + 'AAAA';
  assert.equal((await call('POST', '/api/session', { token: forged.join('.') })).status, 401);
  // wrong audience
  const wrongAud = mock.signIdToken(alice.u, { aud: 'other-project' });
  assert.equal((await call('POST', '/api/session', { token: wrongAud })).status, 401);
  // expired
  const expired = mock.signIdToken(alice.u, { exp: Math.floor(Date.now() / 1000) - 10 });
  const r = await call('POST', '/api/session', { token: expired });
  assert.equal(r.status, 401);
  assert.equal(r.data.error.code, 'token_expired');
});

test('first sign-in creates a profile; client cannot claim admin; bootstrap admin needs verified email', async () => {
  const a = await signin(alice);
  assert.equal(a.role, 'user');
  assert.equal(mock.read(`users/${alice.u.uid}`).status, 'active');
  // an unverified account using the admin e-mail does NOT get admin
  const fake = person('boss@site.test', { verified: false });
  fake.u.uid = 'faker000000000001';
  const f = await call('POST', '/api/session', { token: mock.signIdToken(fake.u) });
  assert.equal(f.data.user.role, 'user');
  const b = await signin(admin);
  assert.equal(b.role, 'admin');
  await signin(bob);
  // second call is idempotent
  assert.equal((await signin(alice)).uid, alice.u.uid);
});

test('admin endpoints reject normal users and anonymous callers', async () => {
  for (const [m, p] of [['GET', '/api/admin/dashboard'], ['GET', '/api/admin/users'], ['PUT', '/api/admin/settings'], ['POST', '/api/admin/videos'], ['POST', '/api/admin/uploads/auth'], ['DELETE', '/api/admin/media']]) {
    assert.equal((await call(m, p, { token: alice.token(), body: {} })).status, 403, `${m} ${p} as user`);
    assert.equal((await call(m, p, { body: {} })).status, 401, `${m} ${p} anonymous`);
  }
});

test('profile: update name, reject bad input', async () => {
  const ok = await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: '  Alice  Wonder ' } });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.user.displayName, 'Alice Wonder');
  assert.equal((await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'x' } })).status, 400);
  assert.equal((await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'a'.repeat(41) } })).status, 400);
  // role cannot be smuggled in
  await call('PATCH', '/api/me', { token: alice.token(), body: { displayName: 'Alice W', role: 'admin' } });
  assert.equal(mock.read(`users/${alice.u.uid}`).role, 'user');
});

// ------------------------------------------------------------------------------------------------ settings & banner
test('settings: validation, banner sanitising, policy acknowledgement', async () => {
  const t = admin.token();
  const get = await call('GET', '/api/admin/settings', { token: t });
  assert.equal(get.status, 200);
  assert.equal(get.data.settings.homeListLimit, 12);

  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { homeListLimit: 0 } })).status, 400);
  assert.equal((await call('PUT', '/api/admin/settings', { token: t, body: { homeListLimit: 999 } })).status, 400);

  const bad = await call('PUT', '/api/admin/settings', { token: t, body: { banner: { html: '<iframe src="https://x.test"></iframe>' } } });
  assert.equal(bad.status, 400);
  const badHost = await call('PUT', '/api/admin/settings', { token: t, body: { banner: { html: '<script src="https://evil.test/a.js"></script>' } } });
  assert.equal(badHost.data.error.code, 'script_host_not_allowed');

  const gate = await call('PUT', '/api/admin/settings', { token: t, body: { gate: { requireForWatch: true } } });
  assert.equal(gate.data.error.code, 'policy_ack_required');

  const html = '<script>atOptions = {"key":"abc123","format":"iframe","height":60,"width":468,"params":{}};</script><script src="https://ads.example.com/abc123/invoke.js"></script>';
  const ok = await call('PUT', '/api/admin/settings', {
    token: t,
    body: {
      homeListLimit: 5,
      popularCount: 4,
      banner: { enabled: true, html, width: 468, height: 60 },
      gate: { requireForWatch: true, requireForSave: true, policyAcknowledged: true, minAwaySeconds: 1, unlockTtlMinutes: 30 },
      texts: { watchInstruction: 'Open the sponsor page, then come back', watchButton: 'Watch now' },
    },
  });
  assert.equal(ok.status, 200, ok.text);
  assert.equal(ok.data.settings.homeListLimit, 5);
  assert.equal(ok.data.settings.gate.policyAcknowledgedBy, admin.u.uid);
  assert.equal(mock.read('settings/public').texts.watchButton, 'Watch now');
  assert.equal(mock.read('settings/public').texts.openAdButton, 'স্পনসর পেজ খুলুন', 'unchanged texts keep defaults');

  const frame = await call('GET', '/api/ads/banner-frame');
  assert.match(frame.text, /ads\.example\.com\/abc123\/invoke\.js/);
  assert.match(frame.res.headers.get('Content-Security-Policy'), /sandbox allow-scripts/);
  assert.doesNotMatch(frame.res.headers.get('Content-Security-Policy'), /allow-same-origin/);
  assert.match(frame.res.headers.get('Content-Security-Policy'), /frame-ancestors 'self' https:\/\/site\.test/);
});

test('banner sanitiser blocks script injection vectors', () => {
  const opt = { allowedHosts: ['ads.example.com', '*.adnet.test'] };
  const reject = (html) => assert.throws(() => sanitizeBannerHtml(html, opt), undefined, html);
  reject('<script>alert(1)</script>');
  reject('<script>atOptions = {}; fetch("https://evil.test")</script>');
  reject('<script>location = {"a":1};</script>');
  reject('<script src="https://evil.test/x.js"></script>');
  reject('<script src="https://ads.example.com.evil.test/x.js"></script>');
  reject('<script src="https://ads.example.com/x.js">alert(1)</script>');
  reject('<script src="javascript:alert(1)"></script>');
  reject('<iframe src="https://a.test"></iframe>');
  reject('<object data="x"></object>');
  reject('<svg onload=alert(1)>');
  reject('<style>*{}</style>');
  reject('<form action="x"></form>');
  reject('<link rel="stylesheet" href="x">');
  reject('<!DOCTYPE html>');
  reject('<div');
  const okHost = sanitizeBannerHtml('<script src="//cdn.adnet.test/a.js" async></script>', opt);
  assert.match(okHost.html, /https:\/\/cdn\.adnet\.test\/a\.js/);
  const clean = sanitizeBannerHtml('<a href="javascript:alert(1)" onclick="x()" target="_top"><img src="https://i.test/a.png" onerror="x()" width="10"></a><!-- c -->', opt);
  assert.doesNotMatch(clean.html, /javascript:|onclick|onerror|_top|<!--/);
  assert.match(clean.html, /<img src="https:\/\/i\.test\/a\.png" width="10" \/>/);
  assert.ok(clean.warnings.length >= 2);
  const attr = sanitizeBannerHtml('<div title="&quot;><script>x">hi</div>', opt);
  assert.doesNotMatch(attr.html, /<script>x/);
});

test('search tokens are identical on server and client', () => {
  for (const s of ['Hello World 2024', 'বাংলা ভিডিও', 'Ünïcode  café', '']) assert.deepEqual(searchTokens(s, 'tag'), clientTokens(s, 'tag'));
});

// ------------------------------------------------------------------------------------------------ uploads & videos
test('upload auth: admin only, validated, signed with the private key (never revealed)', async () => {
  const t = admin.token();
  const ask = (body) => call('POST', '/api/admin/uploads/auth', { token: t, body });
  assert.equal((await ask({ kind: 'video', contentType: 'application/x-msdownload', size: 10 })).status, 400);
  assert.equal((await ask({ kind: 'video', contentType: 'video/mp4', size: 5 * 1024 * 1024 })).status, 413);
  assert.equal((await ask({ kind: 'thumbnail', contentType: 'image/svg+xml', size: 10 })).status, 400);
  assert.equal((await ask({ kind: 'avatar', contentType: 'image/png', size: 10 })).status, 400);
  assert.equal((await call('POST', '/api/admin/uploads/auth', { token: alice.token(), body: { kind: 'video', contentType: 'video/mp4', size: 10 } })).status, 403);
  assert.equal((await call('POST', '/api/admin/uploads/auth', { body: { kind: 'video', contentType: 'video/mp4', size: 10 } })).status, 401);

  const r = await ask({ kind: 'video', contentType: 'video/mp4', size: MP4.length });
  assert.equal(r.status, 200, r.text);
  const a = r.data;
  // token + expire + signature as ImageKit documents them, recomputed here with node:crypto
  assert.equal(a.signature, crypto.createHmac('sha1', IK.privateKey).update(`${a.token}${a.expire}`).digest('hex'));
  assert.match(a.signature, /^[0-9a-f]{40}$/);
  const now = Math.floor(Date.now() / 1000);
  assert.ok(a.expire > now && a.expire < now + 3600, 'expire is less than one hour ahead');
  assert.equal(a.publicKey, IK.publicKey);
  assert.equal(a.folder, '/proapp-vault/videos');
  assert.equal(a.isPrivateFile, true);
  assert.match(a.fileName, /^[0-9a-f-]{36}\.mp4$/);
  assert.ok(!('privateKey' in a));
  const r2 = await ask({ kind: 'video', contentType: 'video/mp4', size: MP4.length });
  assert.notEqual(r2.data.token, a.token, 'every call returns a fresh token');
  const th = await ask({ kind: 'thumbnail', contentType: 'image/png', size: PNG.length });
  assert.equal(th.data.folder, '/proapp-vault/thumbs');
  assert.equal(th.data.isPrivateFile, false, 'thumbnails stay public');
});

test('uploads go straight to ImageKit with our signature; ImageKit enforces the token rules', async () => {
  const t = admin.token();
  const thumb = await uploadToImageKit(t, 'thumbnail', PNG, 'image/png');
  assert.equal(thumb.status, 200, JSON.stringify(thumb.body));
  const video = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  assert.equal(video.status, 200, JSON.stringify(video.body));
  const stored = mock.imagekit.files.get(video.body.fileId);
  assert.equal(stored.filePath.startsWith('/proapp-vault/videos/'), true);
  assert.equal(stored.isPrivateFile, true, 'videos are stored as private files');
  globalThis.thumbFileId = thumb.body.fileId;
  globalThis.videoFileId = video.body.fileId;

  // the mock (independent of our code) refuses a forged signature and a reused token
  const form = new FormData();
  form.append('file', new Blob([MP4]), 'x.mp4');
  for (const [k, v] of Object.entries({ fileName: 'x.mp4', publicKey: IK.publicKey, signature: 'a'.repeat(40), token: 't1', expire: String(Math.floor(Date.now() / 1000) + 600) })) form.append(k, v);
  assert.equal((await fetch(video.auth.uploadUrl, { method: 'POST', body: form })).status, 401);
  const reuse = new FormData();
  reuse.append('file', new Blob([MP4]), 'x.mp4');
  for (const k of ['fileName', 'publicKey', 'signature', 'token']) reuse.append(k, String(video.auth[k]));
  reuse.append('expire', String(video.auth.expire));
  assert.equal((await fetch(video.auth.uploadUrl, { method: 'POST', body: reuse })).status, 400, 'a token works only once');
});

test('video create/update: the server verifies the uploaded file and stores URLs itself', async () => {
  const t = admin.token();
  const base = { title: 'Big Buck Demo', description: 'A test video', tags: ['Demo', 'demo', 'Test'], status: 'published', videoFileId: globalThis.videoFileId, thumbnailFileId: globalThis.thumbFileId };
  const post = (body) => call('POST', '/api/admin/videos', { token: t, body });
  assert.equal((await post({ ...base, videoFileId: 'doesnotexist123456789' })).data.error.code, 'media_missing');
  assert.equal((await post({ ...base, videoFileId: '../../secret' })).status, 400);
  assert.equal((await post({ ...base, videoFileId: globalThis.thumbFileId })).data.error.code, 'media_wrong_folder', 'an image id can not be used as a video');
  assert.equal((await post({ ...base, thumbnailFileId: globalThis.videoFileId })).data.error.code, 'media_wrong_folder');
  assert.equal((await post({ ...base, title: '' })).status, 400);
  assert.equal((await post({ ...base, ad: { enabled: true, url: 'http://insecure.test' } })).status, 400);
  assert.equal((await post({ ...base, ad: { enabled: true, url: 'javascript:alert(1)' } })).status, 400);
  // a client-supplied URL is ignored: only ids are accepted
  const ok = await post({ ...base, videoUrl: 'https://evil.test/x.mp4', ad: { enabled: true, url: 'https://ads.example.com/offer?sid={sid}', minAwaySeconds: 1 } });
  assert.equal(ok.status, 201, ok.text);
  videoId = ok.data.id;
  const v = mock.read(`videos/${videoId}`);
  const file = mock.imagekit.files.get(globalThis.videoFileId);
  assert.equal(v.videoUrl, `${mock.url}/ik/media/${IK.id}${file.filePath}`, 'URL built from IMAGEKIT_URL_ENDPOINT + path (not the domain ImageKit returned, not client input)');
  assert.equal(v.videoPrivate, true);
  assert.equal(v.videoFileId, globalThis.videoFileId);
  assert.equal(v.sizeBytes, MP4.length);
  assert.equal(v.contentType, 'video/mp4');
  assert.match(v.thumbnailUrl, new RegExp(`^${mock.url}/ik/media/${IK.id}/proapp-vault/thumbs/`));
  assert.deepEqual(v.tags, ['demo', 'test']);
  assert.equal(v.views, 0);
  assert.ok(v.searchTokens.includes('big') && v.searchTokens.includes('dem'));
  assert.ok(!JSON.stringify(v).includes(IK.privateKey));

  assert.equal((await post({ ...base, title: 'Second' })).data.error.code, 'media_in_use', 'one file can not back two videos');
  const upd = await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { title: 'Renamed Clip' } });
  assert.equal(upd.status, 200);
  assert.ok(mock.read(`videos/${videoId}`).searchTokens.includes('renamed'));
  assert.equal(mock.read(`videos/${videoId}`).ad.url, 'https://ads.example.com/offer?sid={sid}', 'ad kept on partial update');
  assert.equal(mock.read(`videos/${videoId}`).videoUrl, v.videoUrl, 'media kept on partial update');
});

test('video create rejects oversize files (and removes them) and files that are not private when they must be', async () => {
  const t = admin.token();
  // 1 MB limit in this test environment
  const big = await uploadToImageKit(t, 'video', Buffer.concat([Buffer.from(MP4), Buffer.alloc(1024 * 1024 + 10)]), 'video/mp4', { sizeClaim: 100 });
  assert.equal(big.status, 200);
  const tooBig = await call('POST', '/api/admin/videos', { token: t, body: { title: 'Big', videoFileId: big.body.fileId } });
  assert.equal(tooBig.status, 413, tooBig.text);
  assert.equal(mock.imagekit.files.has(big.body.fileId), false, 'oversize upload was deleted from ImageKit');

  mock.imagekit.state.privateSupported = false; // simulate a plan that silently ignores isPrivateFile
  const pub = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  mock.imagekit.state.privateSupported = true;
  const notPrivate = await call('POST', '/api/admin/videos', { token: t, body: { title: 'Public', videoFileId: pub.body.fileId } });
  assert.equal(notPrivate.data.error.code, 'not_private');
  const wrongType = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  mock.imagekit.files.get(wrongType.body.fileId).mime = 'application/zip';
  assert.equal((await call('POST', '/api/admin/videos', { token: t, body: { title: 'Zip', videoFileId: wrongType.body.fileId } })).data.error.code, 'unsupported_type');
  for (const r of [pub, wrongType]) await call('DELETE', '/api/admin/media', { token: t, body: { fileId: r.body.fileId } });
});

test('IMAGEKIT_PRIVATE_VIDEOS=false stores and serves public URLs', async () => {
  const saved = { ...env };
  env.IMAGEKIT_PRIVATE_VIDEOS = 'false';
  try {
    const t = admin.token();
    const up = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
    assert.equal(up.auth.isPrivateFile, false);
    const created = await call('POST', '/api/admin/videos', { token: t, body: { title: 'Open clip', status: 'published', videoFileId: up.body.fileId } });
    assert.equal(created.status, 201, created.text);
    const id = created.data.id;
    const play = await call('POST', `/api/videos/${id}/play`, { token: alice.token() });
    assert.equal(play.status, 200, play.text);
    assert.ok(!play.data.url.includes('ik-s='), 'public videos need no signature');
    assert.equal((await fetch(play.data.url)).status, 200);
    await call('DELETE', `/api/admin/videos/${id}?deleteMedia=1`, { token: t });
  } finally {
    Object.assign(env, saved);
    delete env.IMAGEKIT_PRIVATE_VIDEOS;
  }
});

// ------------------------------------------------------------------------------------------------ viewer flow
test('watching is blocked until the sponsor flow is completed', async () => {
  const t = alice.token();
  const denied = await call('POST', `/api/videos/${videoId}/play`, { token: t });
  assert.equal(denied.status, 403);
  assert.equal(denied.data.error.code, 'ad_required');

  const st = await call('GET', `/api/videos/${videoId}/state`, { token: t });
  assert.equal(st.data.gate.watch.required, true);
  assert.equal(st.data.gate.watch.unlocked, false);

  const start = await call('POST', '/api/ads/start', { token: t, body: { videoId, purpose: 'watch' } });
  assert.equal(start.status, 200, start.text);
  assert.match(start.data.adUrl, /^https:\/\/ads\.example\.com\/offer\?sid=[0-9a-f-]{36}$/);

  // another user cannot complete my session
  const steal = await call('POST', '/api/ads/complete', { token: bob.token(), body: { sessionId: start.data.sessionId } });
  assert.equal(steal.status, 404);

  // too early: the server measures the wait itself
  const early = await call('POST', '/api/ads/complete', { token: t, body: { sessionId: start.data.sessionId } });
  assert.equal(early.status, 409);
  assert.equal(early.data.error.code, 'too_early');
  assert.equal((await call('POST', `/api/videos/${videoId}/play`, { token: t })).status, 403);

  await new Promise((r) => setTimeout(r, 1100));
  const done = await call('POST', '/api/ads/complete', { token: t, body: { sessionId: start.data.sessionId } });
  assert.equal(done.status, 200, done.text);
  assert.equal(done.data.unlocked, true);
  // completing twice is harmless
  assert.equal((await call('POST', '/api/ads/complete', { token: t, body: { sessionId: start.data.sessionId } })).data.unlocked, true);
});

test('play: signed private ImageKit URL, server-side view counting, range requests', async () => {
  const t = alice.token();
  const play = await call('POST', `/api/videos/${videoId}/play`, { token: t });
  assert.equal(play.status, 200, play.text);
  assert.equal(play.data.viewCounted, true);
  assert.equal(mock.read(`videos/${videoId}`).views, 1);
  // replays inside the window do not inflate the count
  const again = await call('POST', `/api/videos/${videoId}/play`, { token: t });
  assert.equal(again.data.viewCounted, false);
  assert.equal(mock.read(`videos/${videoId}`).views, 1);

  const u = new URL(play.data.url);
  assert.ok(play.data.url.startsWith(mock.read(`videos/${videoId}`).videoUrl));
  const expiry = Number(u.searchParams.get('ik-t'));
  const now = Math.floor(Date.now() / 1000);
  assert.ok(expiry > now + 5 * 3600 && expiry <= now + 6 * 3600 + 5, 'signed for about 6 hours');
  assert.match(u.searchParams.get('ik-s'), /^[0-9a-f]{40}$/);

  // what the browser's <video> does: GET the URL, with and without Range
  const full = await fetch(play.data.url);
  assert.equal(full.status, 200);
  assert.equal(Buffer.from(await full.arrayBuffer()).length, MP4.length);
  const part = await fetch(play.data.url, { headers: { Range: 'bytes=4-7' } });
  assert.equal(part.status, 206);
  assert.equal(await part.text(), 'ftyp');

  // the private file is useless without a valid signature
  const bare = new URL(play.data.url);
  bare.search = '';
  assert.equal((await fetch(bare)).status, 401, 'stored URL alone does not play');
  const forged = new URL(play.data.url);
  forged.searchParams.set('ik-s', 'f'.repeat(40));
  assert.equal((await fetch(forged)).status, 401);
  const stretched = new URL(play.data.url);
  stretched.searchParams.set('ik-t', String(expiry + 99999));
  assert.equal((await fetch(stretched)).status, 401, 'expiry can not be extended without re-signing');

  // thumbnails are public
  const thumbUrl = mock.read(`videos/${videoId}`).thumbnailUrl;
  assert.equal((await fetch(thumbUrl)).status, 200);
  assert.equal((await fetch(`${thumbUrl}?tr=w-640,q-80`)).status, 200, 'transformation query is accepted');
});

test('likes: one per user, idempotent, counters stay consistent', async () => {
  const like = (p, liked) => call('POST', `/api/videos/${videoId}/like`, { token: p.token(), body: { liked } });
  assert.equal((await like(alice, true)).data.likes, 1);
  assert.equal((await like(alice, true)).data.likes, 1, 'double like ignored');
  assert.equal((await like(bob, true)).data.likes, 2);
  assert.equal((await like(alice, false)).data.likes, 1);
  assert.equal((await like(alice, false)).data.likes, 1, 'double unlike ignored');
  assert.equal(mock.read(`videos/${videoId}`).likes, 1);
  assert.equal((await call('POST', `/api/videos/${videoId}/like`, { token: alice.token(), body: { liked: 'yes' } })).status, 400);
  // parallel likes from one user still produce a single like
  await Promise.all([like(alice, true), like(alice, true), like(alice, true)]);
  assert.equal(mock.read(`videos/${videoId}`).likes, 2);
});

test('saving requires the save unlock; unsave works', async () => {
  const t = alice.token();
  const denied = await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: true } });
  assert.equal(denied.data.error.code, 'ad_required');
  await new Promise((r) => setTimeout(r, 2100)); // ad starts are rate limited to one per 2 s per user
  const s = await call('POST', '/api/ads/start', { token: t, body: { videoId, purpose: 'save' } });
  assert.equal(s.status, 200, s.text);
  await new Promise((r) => setTimeout(r, 1100));
  assert.equal((await call('POST', '/api/ads/complete', { token: t, body: { sessionId: s.data.sessionId } })).status, 200);
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: true } })).status, 200);
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: true } })).status, 200);
  assert.equal(mock.read(`videos/${videoId}`).savesCount, 1);
  assert.ok(mock.read(`saves/${alice.u.uid}_${videoId}`));
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: t, body: { saved: false } })).status, 200);
  assert.equal(mock.read(`videos/${videoId}`).savesCount, 0);
  // the unlock for "watch" does not unlock "save" for other users
  assert.equal((await call('POST', `/api/videos/${videoId}/save`, { token: bob.token(), body: { saved: true } })).data.error.code, 'ad_required');
});

test('comments: validation, ownership, admin moderation, counters', async () => {
  const post = (p, text) => call('POST', `/api/videos/${videoId}/comments`, { token: p.token(), body: { text } });
  assert.equal((await post(alice, '   ')).status, 400);
  assert.equal((await post(alice, 'x'.repeat(1001))).status, 400);
  const c1 = await post(alice, '<b>Great</b> video!');
  assert.equal(c1.status, 201, c1.text);
  assert.equal(c1.data.comment.text, '<b>Great</b> video!', 'stored verbatim; the UI renders with textContent');
  assert.equal((await post(alice, 'spam')).status, 429, 'rate limited');
  assert.equal(mock.read(`videos/${videoId}`).commentsCount, 1);
  const id = c1.data.comment.id;
  assert.equal((await call('DELETE', `/api/comments/${id}`, { token: bob.token() })).status, 403);
  assert.ok(mock.read(`comments/${id}`));
  assert.equal((await call('DELETE', `/api/comments/${id}`, { token: alice.token() })).status, 200);
  assert.equal(mock.read(`comments/${id}`), null);
  assert.equal(mock.read(`videos/${videoId}`).commentsCount, 0);
  // admin can moderate others' comments
  await new Promise((r) => setTimeout(r, 3100));
  const c2 = await post(alice, 'second');
  assert.equal((await call('DELETE', `/api/comments/${c2.data.comment.id}`, { token: admin.token() })).status, 200);
  assert.equal((await call('DELETE', '/api/comments/not-an-id', { token: alice.token() })).status, 404);
});

test('draft videos are invisible to normal users', async () => {
  const t = admin.token();
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'draft' } });
  assert.equal((await call('GET', `/api/videos/${videoId}/state`, { token: alice.token() })).status, 404);
  assert.equal((await call('POST', `/api/videos/${videoId}/play`, { token: alice.token() })).status, 404);
  assert.equal((await call('GET', `/api/videos/${videoId}/state`, { token: t })).status, 200, 'admin can preview');
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { status: 'published' } });
});

test('postback verification mode requires provider confirmation', async () => {
  const t = admin.token();
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { ad: { verification: 'postback' } } });
  const p = bob;
  const start = await call('POST', '/api/ads/start', { token: p.token(), body: { videoId, purpose: 'watch' } });
  assert.equal(start.data.verification, 'postback');
  await new Promise((r) => setTimeout(r, 1100));
  const early = await call('POST', '/api/ads/complete', { token: p.token(), body: { sessionId: start.data.sessionId } });
  assert.equal(early.data.error.code, 'not_confirmed');
  assert.equal((await call('GET', `/api/ads/postback?sid=${start.data.sessionId}&secret=wrong`)).status, 403);
  assert.equal((await call('GET', `/api/ads/postback?sid=${start.data.sessionId}&secret=${'p'.repeat(24)}`)).status, 200);
  const done = await call('POST', '/api/ads/complete', { token: p.token(), body: { sessionId: start.data.sessionId } });
  assert.equal(done.data.unlocked, true);
  await call('PATCH', `/api/admin/videos/${videoId}`, { token: t, body: { ad: { verification: 'sponsor_opened' } } });
});

// ------------------------------------------------------------------------------------------------ admin
test('admin: dashboard, user management, suspension, no self-demotion', async () => {
  const t = admin.token();
  const d = await call('GET', '/api/admin/dashboard', { token: t });
  assert.equal(d.status, 200, d.text);
  assert.equal(d.data.totals.users, 4);
  assert.equal(d.data.totals.videos, 1);
  assert.equal(d.data.totals.views, 1);
  assert.ok(d.data.recentUsers.length > 0);

  assert.equal((await call('PATCH', `/api/admin/users/${admin.u.uid}`, { token: t, body: { role: 'user' } })).status, 400);
  assert.equal((await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'superuser' } })).status, 400);
  const sus = await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { status: 'suspended' } });
  assert.equal(sus.status, 200, sus.text);
  assert.equal(sus.data.authSync, true);
  assert.equal(mock.users.get('bob@site.test').disabled, true, 'Firebase Auth account disabled as well');
  assert.equal((await call('POST', `/api/videos/${videoId}/like`, { token: bob.token(), body: { liked: true } })).data.error.code, 'account_suspended');
  assert.equal((await call('POST', '/api/session', { token: bob.token() })).status, 403);
  await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { status: 'active' } });
  assert.equal((await call('POST', '/api/session', { token: bob.token() })).status, 200);

  // role management
  assert.equal((await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'admin' } })).status, 200);
  assert.equal((await call('GET', '/api/admin/users', { token: bob.token() })).status, 200);
  await call('PATCH', `/api/admin/users/${bob.u.uid}`, { token: t, body: { role: 'user' } });
  assert.equal((await call('GET', '/api/admin/users', { token: bob.token() })).status, 403, 'demotion takes effect immediately');

  const list = await call('GET', '/api/admin/users?q=ali', { token: t });
  assert.equal(list.data.users.length, 1);
  const an = await call('GET', '/api/admin/analytics', { token: t });
  assert.equal(an.status, 200, an.text);
  assert.ok(an.data.auditLog.length > 0);
});

test('a second video (kept for the avatar test)', async () => {
  const t = admin.token();
  const up = await uploadToImageKit(t, 'video', MP4, 'video/mp4');
  const r = await call('POST', '/api/admin/videos', { token: t, body: { title: 'Second Clip', status: 'published', videoFileId: up.body.fileId } });
  assert.equal(r.status, 201, r.text);
  videoId2 = r.data.id;
});

test('admin: media list protects files in use; only this app\'s folder can be touched; delete video cascades', async () => {
  const t = admin.token();
  const list = await call('GET', '/api/admin/media?prefix=videos', { token: t });
  assert.equal(list.status, 200, list.text);
  const mine = list.data.objects.find((o) => o.fileId === globalThis.videoFileId);
  assert.equal(mine.usedBy.id, videoId);
  assert.equal(mine.url, '', 'private files expose no URL');
  const thumbs = await call('GET', '/api/admin/media?prefix=thumbs', { token: t });
  const myThumb = thumbs.data.objects.find((o) => o.fileId === globalThis.thumbFileId);
  assert.equal(myThumb.usedBy.id, videoId);
  assert.match(myThumb.url, /\/proapp-vault\/thumbs\//);
  assert.equal((await call('GET', '/api/admin/media?prefix=etc', { token: t })).status, 400);

  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: globalThis.videoFileId } })).data.error.code, 'in_use');
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: '../x' } })).status, 400);
  // a file in the same ImageKit account but outside our folder must not be deletable through this API
  mock.imagekit.files.set('outsider0000000001', { fileId: 'outsider0000000001', name: 'logo.png', filePath: '/company/logo.png', size: 3, mime: 'image/png', isPrivateFile: false, bytes: Buffer.from([1, 2, 3]), createdAt: new Date().toISOString() });
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: 'outsider0000000001' } })).data.error.code, 'media_wrong_folder');
  assert.ok(mock.imagekit.files.has('outsider0000000001'));
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: 'neverexisted000000001' } })).status, 404);

  const del = await call('DELETE', `/api/admin/videos/${videoId}?deleteMedia=1`, { token: t });
  assert.equal(del.status, 200, del.text);
  assert.equal(del.data.cleanupPending, false);
  assert.equal(mock.read(`videos/${videoId}`), null);
  assert.equal(mock.imagekit.files.has(globalThis.videoFileId), false, 'video removed from ImageKit');
  assert.equal(mock.imagekit.files.has(globalThis.thumbFileId), false, 'thumbnail removed from ImageKit');
  for (const col of ['likes', 'saves', 'comments', 'views', 'unlocks', 'adSessions']) assert.equal(mock.ids(col).length, 0, `${col} cleaned up`);
  // an orphan (uploaded but never attached) can be deleted from the media manager
  const orphan = await uploadToImageKit(t, 'thumbnail', PNG, 'image/png');
  const listed = await call('GET', '/api/admin/media?prefix=thumbs', { token: t });
  assert.equal(listed.data.objects[0].usedBy, null);
  assert.equal((await call('DELETE', '/api/admin/media', { token: t, body: { fileId: orphan.body.fileId } })).status, 200);
  assert.equal(mock.imagekit.files.has(orphan.body.fileId), false);
});

test('profile photo: validated on the server, stored in ImageKit, replaced and removed cleanly', async () => {
  const t = alice.token();
  const post = (bytes, type) => call('POST', '/api/me/avatar', { token: t, raw: bytes, headers: { 'Content-Type': type } });
  assert.equal((await post(PNG, 'image/gif')).status, 400);
  assert.equal((await post(new Uint8Array([1, 2, 3, 4, 5, 6]), 'image/png')).data.error.code, 'bad_content', 'bytes must match the declared type');
  assert.equal((await post(new Uint8Array(2 * 1024 * 1024 + 1), 'image/png')).status, 413);
  assert.equal((await call('POST', '/api/me/avatar', { raw: PNG, headers: { 'Content-Type': 'image/png' } })).status, 401);

  const ok = await post(PNG, 'image/png');
  assert.equal(ok.status, 200, ok.text);
  const first = mock.read(`users/${alice.u.uid}`);
  assert.match(first.photoURL, new RegExp(`^${mock.url}/ik/media/${IK.id}/proapp-vault/avatars/${alice.u.uid}`));
  assert.equal(ok.data.user.photoURL, first.photoURL);
  assert.equal(mock.imagekit.files.get(first.photoFileId).isPrivateFile, false);
  assert.equal((await fetch(first.photoURL)).status, 200);
  assert.equal((await post(PNG, 'image/png')).status, 429, 'cooldown between changes');

  await new Promise((r) => setTimeout(r, 3100));
  const second = await post(PNG, 'image/png');
  assert.equal(second.status, 200, second.text);
  assert.equal(mock.imagekit.files.has(first.photoFileId), false, 'previous photo deleted from ImageKit');
  const now = mock.read(`users/${alice.u.uid}`);
  assert.notEqual(now.photoFileId, first.photoFileId);

  // admin sees it in the media manager; it is in use so it cannot be deleted
  const list = await call('GET', '/api/admin/media?prefix=avatars', { token: admin.token() });
  assert.equal(list.data.objects.find((o) => o.fileId === now.photoFileId).usedBy.type, 'user');
  assert.equal((await call('DELETE', '/api/admin/media', { token: admin.token(), body: { fileId: now.photoFileId } })).data.error.code, 'in_use');

  // the session payload and new comments carry the photo
  assert.equal((await call('POST', '/api/session', { token: t })).data.user.photoURL, now.photoURL);
  const c = await call('POST', `/api/videos/${videoId2}/comments`, { token: t, body: { text: 'with photo' } });
  assert.equal(c.data.comment.authorPhoto, now.photoURL);
  await call('DELETE', `/api/comments/${c.data.comment.id}`, { token: t });

  await new Promise((r) => setTimeout(r, 3100));
  const gone = await post(PNG, 'image/png');
  assert.equal(gone.status, 200);
  const rm = await call('DELETE', '/api/me/avatar', { token: t });
  assert.equal(rm.status, 200);
  assert.equal(rm.data.user.photoURL, '');
  assert.equal(mock.read(`users/${alice.u.uid}`).photoFileId, '');
  assert.equal([...mock.imagekit.files.values()].filter((f) => f.filePath.startsWith('/proapp-vault/avatars/')).length, 0);
  // leave one in place so account deletion has something to clean up
  await new Promise((r) => setTimeout(r, 3100));
  assert.equal((await post(PNG, 'image/png')).status, 200);
});

test('account deletion needs a recent login and removes user data', async () => {
  const stale = mock.signIdToken(alice.u, { auth_time: Math.floor(Date.now() / 1000) - 3600 });
  assert.equal((await call('DELETE', '/api/me', { token: stale, body: { confirm: true } })).data.error.code, 'reauth_required');
  assert.equal((await call('DELETE', '/api/me', { token: alice.token(), body: {} })).status, 400);
  const adminDel = await call('DELETE', '/api/me', { token: admin.token(), body: { confirm: true } });
  assert.equal(adminDel.data.error.code, 'admin_self_delete');
  const del = await call('DELETE', '/api/me', { token: alice.token(), body: { confirm: true } });
  assert.equal(del.data.done, true, del.text);
  assert.equal(mock.read(`users/${alice.u.uid}`), null);
  assert.equal(mock.users.has('alice@site.test'), false);
  assert.equal([...mock.imagekit.files.values()].filter((f) => f.filePath.startsWith('/proapp-vault/avatars/')).length, 0, 'avatar removed with the account');
});

test('closed sign-ups block new profiles', async () => {
  await call('PUT', '/api/admin/settings', { token: admin.token(), body: { allowSignups: false } });
  const carol = person('carol@site.test');
  const r = await call('POST', '/api/session', { token: carol.token() });
  assert.equal(r.data.error.code, 'signups_closed');
  await call('PUT', '/api/admin/settings', { token: admin.token(), body: { allowSignups: true } });
});

test('unknown routes and methods', async () => {
  assert.equal((await call('GET', '/api/nope')).status, 404);
  assert.equal((await call('DELETE', '/api/health')).status, 405);
  const big = await call('POST', '/api/session', { token: admin.token(), raw: 'x'.repeat(10) });
  assert.equal(big.status, 200);
});
