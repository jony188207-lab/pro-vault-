// The sponsor ("ad") unlock flow and the sandboxed banner frame.
//
// IMPORTANT - what this flow can and cannot prove:
//   * verification "sponsor_opened": the server issued the sponsor link, the browser asked for it, and at least
//     `minAwaySeconds` passed (measured on the server) before the viewer asked to unlock. It does NOT prove that
//     an advertisement was displayed or watched - no ad network exposes that for a plain link.
//   * verification "postback": the unlock additionally waits for a server-to-server confirmation from the ad
//     provider (POST/GET /api/ads/postback with AD_POSTBACK_SECRET). Use this with providers that offer it.
// The wording shown to viewers is admin-editable, so admins must not claim "ad viewed" unless the provider confirmed it.
import { W, FirestoreError } from '../lib/firestore.js';
import { HttpError, badRequest, forbidden, json, notFound, readJson } from '../lib/http.js';
import { tooMany } from '../lib/context.js';
import { safeEqual } from '../lib/signing.js';
import { uuid } from '../lib/ids.js';
import { BANNER_FRAME_CSP, bannerFrameDocument } from '../lib/sanitize.js';
import { allowedOrigins } from '../lib/http.js';

export function gateStatus(settings, video, purpose, unlockDoc) {
  const flag = purpose === 'watch' ? settings.gate.requireForWatch : settings.gate.requireForSave;
  const ad = video.ad || {};
  const required = !!flag && !!ad.enabled && !!ad.url;
  const exp = unlockDoc?.data?.expiresAt;
  const unlocked = !required || (exp instanceof Date && exp.getTime() > Date.now());
  return {
    required,
    unlocked,
    expiresAt: required && unlocked && exp instanceof Date ? exp.toISOString() : null,
    minAwaySeconds: ad.minAwaySeconds || settings.gate.minAwaySeconds,
    verification: ad.verification === 'postback' ? 'postback' : 'sponsor_opened',
  };
}

/** POST /api/ads/start { videoId, purpose } */
export async function startAd(c) {
  const body = await readJson(c.request);
  const purpose = body.purpose;
  if (purpose !== 'watch' && purpose !== 'save') throw badRequest('purpose must be "watch" or "save"');
  const videoId = String(body.videoId || '');
  const [video, settings] = await Promise.all([c.loadPublishedVideo(videoId), c.settings()]);
  const unlock = await c.fs.get(`unlocks/${c.uid}_${videoId}_${purpose}`);
  const gate = gateStatus(settings, video.data, purpose, unlock);
  if (!gate.required) throw badRequest('This video does not need a sponsor step', 'ad_not_required');
  if (gate.unlocked) return json({ alreadyUnlocked: true, expiresAt: gate.expiresAt });

  const lastStart = c.user.lastAdStartAt instanceof Date ? c.user.lastAdStartAt.getTime() : 0;
  if (Date.now() - lastStart < 2000) throw tooMany();

  const sid = uuid();
  const expiresAt = new Date(Date.now() + settings.gate.sessionTtlMinutes * 60_000);
  await c.fs.commit([
    W.set(
      `adSessions/${sid}`,
      { uid: c.uid, videoId, purpose, status: 'opened', verification: gate.verification, minAwaySeconds: gate.minAwaySeconds, expiresAt },
      { exists: false, transforms: [{ field: 'openedAt', serverTime: true }] },
    ),
    W.update(`users/${c.uid}`, {}, { exists: true, transforms: [{ field: 'lastAdStartAt', serverTime: true }] }),
  ]);
  return json({
    sessionId: sid,
    adUrl: video.data.ad.url.split('{sid}').join(sid),
    minAwaySeconds: gate.minAwaySeconds,
    verification: gate.verification,
    expiresAt: expiresAt.toISOString(),
  });
}

/** POST /api/ads/complete { sessionId } */
export async function completeAd(c) {
  const body = await readJson(c.request);
  const sid = String(body.sessionId || '');
  if (!/^[0-9a-f-]{36}$/.test(sid)) throw badRequest('Invalid session', 'invalid_session');
  const doc = await c.fs.get(`adSessions/${sid}`);
  if (!doc || doc.data.uid !== c.uid) throw notFound('Sponsor session not found', 'invalid_session');
  const s = doc.data;
  const settings = await c.settings();
  const now = Date.now();

  if (s.status !== 'completed') {
    if (!(s.expiresAt instanceof Date) || s.expiresAt.getTime() < now) throw new HttpError(410, 'This sponsor step expired. Please start again.', 'session_expired');
    const opened = s.openedAt instanceof Date ? s.openedAt.getTime() : now;
    const waitMs = s.minAwaySeconds * 1000 - (now - opened);
    if (waitMs > 0) throw new HttpError(409, 'Please give the sponsor page a little more time.', 'too_early', { retryAfterSeconds: Math.ceil(waitMs / 1000) });
    if (s.verification === 'postback' && s.status !== 'confirmed') {
      throw new HttpError(409, 'Waiting for confirmation from the ad provider. Try again in a moment.', 'not_confirmed');
    }
    const expiresAt = new Date(now + settings.gate.unlockTtlMinutes * 60_000);
    try {
      await c.fs.commit([
        W.update(`adSessions/${sid}`, { status: 'completed' }, { updateTime: doc.updateTime, transforms: [{ field: 'completedAt', serverTime: true }] }),
        W.set(
          `unlocks/${c.uid}_${s.videoId}_${s.purpose}`,
          { uid: c.uid, videoId: s.videoId, purpose: s.purpose, sessionId: sid, expiresAt },
          { transforms: [{ field: 'unlockedAt', serverTime: true }] },
        ),
      ]);
    } catch (e) {
      if (!(e instanceof FirestoreError && e.isPrecondition)) throw e; // parallel completion by the same user: fine
    }
    return json({ unlocked: true, purpose: s.purpose, videoId: s.videoId, expiresAt: expiresAt.toISOString() });
  }
  const unlock = await c.fs.get(`unlocks/${c.uid}_${s.videoId}_${s.purpose}`);
  return json({ unlocked: true, purpose: s.purpose, videoId: s.videoId, expiresAt: unlock?.data.expiresAt?.toISOString?.() || null });
}

/** GET|POST /api/ads/postback?sid=...&secret=... - server-to-server confirmation from an ad provider. */
export async function postback(c) {
  const secret = c.env.AD_POSTBACK_SECRET;
  if (!secret || secret.length < 16) throw notFound();
  let sid = c.url.searchParams.get('sid');
  let provided = c.url.searchParams.get('secret') || c.request.headers.get('X-Postback-Secret');
  if (c.request.method === 'POST' && !sid) {
    const body = await readJson(c.request).catch(() => ({}));
    sid = body.sid;
    provided = provided || body.secret;
  }
  if (!provided || !(await safeEqual(provided, secret))) throw forbidden('Invalid secret', 'bad_secret');
  if (!sid || !/^[0-9a-f-]{36}$/.test(sid)) throw badRequest('Invalid sid', 'invalid_session');
  const doc = await c.fs.get(`adSessions/${sid}`);
  if (!doc) throw notFound('Unknown session', 'invalid_session');
  if (doc.data.status === 'opened' && doc.data.expiresAt instanceof Date && doc.data.expiresAt.getTime() > Date.now()) {
    try {
      await c.fs.commit([W.update(`adSessions/${sid}`, { status: 'confirmed' }, { updateTime: doc.updateTime, transforms: [{ field: 'confirmedAt', serverTime: true }] })]);
    } catch (e) {
      if (!(e instanceof FirestoreError && e.isPrecondition)) throw e;
    }
  }
  return json({ ok: true });
}

/** GET /api/ads/banner-frame - the admin banner, served as its own sandboxed document. */
export async function bannerFrame(c) {
  const settings = await c.settings();
  const b = settings.banner;
  const html = b.enabled && b.html ? bannerFrameDocument(b.html) : bannerFrameDocument('');
  const ancestors = ["'self'", ...allowedOrigins(c.env)].join(' ');
  return new Response(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Security-Policy': `${BANNER_FRAME_CSP}; frame-ancestors ${ancestors}`,
      'Cache-Control': 'public, max-age=60',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
