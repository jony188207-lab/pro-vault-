# Provalut

A mobile-first dark video app, deployed on **Vercel**, with **ImageKit** for media and **Firebase** for accounts and data. Videos can have **any number of parts**; each part has its own quality, file or link, download link and (optionally) its own unlock link.

| Part | Tech | Where |
| --- | --- | --- |
| Frontend | HTML, CSS, JavaScript (ES modules, no framework) | `public/` |
| Accounts | Firebase Authentication (email + password) | `public/js/lib/firebase.js` |
| App data | Cloud Firestore | rules in `firestore.rules` |
| API + admin backend | Vercel Function (Node), one entry file | `api/index.js` -> `server/src/` |
| Media | ImageKit behind a swappable **Storage Adapter** | `server/src/storage/` |

## What it does

* **Home:** search, categories, Continue Watching, Trending, Recently Added.
* **Video details:** hero, like / save-later / download, share tile, the **Select Quality / Part** list (gradient rows, lock icon per part), comments with a sticky input bar.
* **Per-part unlock:** tapping a locked part opens that part's own unlock link (for example a separate Adsterra Smartlink per part). Only that part unlocks, the state is saved per user, and repeated taps cannot create duplicates.
* **Watch / Download** per unlocked part: ImageKit files use signed URLs; external links open in a new tab.
* **Saved, Recently Watched, Trending, Inbox (notifications), account sheet.**
* **Admin:** videos with a parts editor (add, edit, delete, reorder, publish), five independent banner placements, unlock settings and texts, categories, notifications, users, media manager, dashboard.
* **Notifications:** when a video becomes published, an in-app notification is created once (no duplicates). Telegram is optional.

## Status: read this first

Nothing here has been run against real Firebase, ImageKit, Vercel, Adsterra or Telegram accounts, and no credentials are included. Everything was tested only against in-memory stand-ins written for this project.

**Verified (against the stand-ins):**

* `node --test test/*.test.js`: 45 tests covering token verification, admin checks, ImageKit upload-auth and verification, signed playback and download URLs, parts (validation, numbering, reorder, delete, cascade), per-part unlock (parallel completes, persistence, expiry, postback), banner sanitising and per-placement settings, publish notifications (dedup, Telegram against a local fake), history, saves, comments, suspension, a lint of `firestore.rules`, and static checks (CSP, no secrets under `public/`, no old app name or old providers).
* `node test/e2e.mjs`: a Chromium run on a phone-size screen, with the frontend and `/api` on **one origin through `api/index.js`** and the production CSP from `vercel.json`. It covers admin setup (five banners, unlock settings, categories), creating a three-part video (one uploaded file, two external links, separate unlock links, one free part), reordering, publishing and the notification, sign-up, the home page and banners, unlocking **only** part 1 (part 2 stays locked, banners never unlock anything), persistence after reload, a signed ImageKit URL with a range request, refused access to a locked part, comments, inbox, history, saved, and deleting a part. No console errors or CSP violations beyond the deliberate probes.

**Not verified. Test these after deploying:**

* Any call to the real ImageKit: upload, Media API, CDN, signed URLs, and especially **`ik-attachment` signed download URLs** and **private files** (plan support is unconfirmed).
* The real Vercel runtime (`/api/*` rewrite, function entry, build step) and a real Firebase project (the rules were linted, not run in the emulator).
* Real Adsterra banner code and Smartlinks: I never saw them, so no code is built in. Paste yours in Admin -> Ads and each part's form.
* Live Telegram delivery.
* Playback of real, large videos.
* **Visual match with your BD Viral Link reference.** I matched it from the screenshot description (dark navy, red accents, gradient-bordered rows, Select Quality / Part popup, sticky comment bar) and checked the layout on a 390 px screen, but I could not compare pixel by pixel.

**Deliberately not built** (they would be fake buttons without a real backend): gems / coins, VIP and the "ad-free" strip, referrals, lucky wheel, video requests, promote, splash screen.

## Unlocking: what it can and cannot prove

A Smartlink gives no completion callback. Opening it proves nothing about an ad being shown or finished, so the app does **not** claim that. Per part:

* **Default (`sponsor_opened`):** the server records that this user was issued the link and that at least N seconds passed (measured by the server, default 10, configurable). The popup says in plain words that unlocking does not verify an ad was shown.
* **`postback`:** only use this if your provider can call your server. Set `AD_POSTBACK_SECRET` and configure the provider to call `/api/ads/postback?sid={sid}&secret=...`. The unlock then waits for that confirmation.
* An unlock link may contain the literal placeholder `{sid}`; the server replaces it with the session id so a provider can echo it back in a postback. Use it only if your provider supports passing a sub-id.

Adsterra's terms restrict incentivised clicks and views. Gating content behind an ad may fall under that. The admin must tick "I checked that my ad network allows this flow" before any part can be saved as locked. Check your network's rules yourself.

**Banners are independent.** Banner code never unlocks anything and is never involved in the unlock flow.

## Setup, step by step

You need: a Google account (Firebase), an ImageKit account, a Vercel account, and this folder in a Git repository (GitHub, GitLab or Bitbucket) or the Vercel CLI.

### 1. Firebase

1. Create a project at <https://console.firebase.google.com>.
2. **Build -> Authentication -> Get started -> Email/Password -> Enable.**
3. **Build -> Firestore Database -> Create database** (production mode, a region near your users).
4. Deploy the rules and indexes from this folder:
   ```
   npm install -g firebase-tools
   firebase login
   firebase use --add          # choose your project
   firebase deploy --only firestore:rules,firestore:indexes
   ```
   Wait until the indexes show "Enabled" (Firestore -> Indexes). Until then the home list and search show a "needs an index" message.
5. **Project settings -> General -> Your apps -> Web app (`</>`)**: copy `apiKey` (-> `FIREBASE_API_KEY`) and `projectId` (-> `FIREBASE_PROJECT_ID`). Both are public by design.
6. **Project settings -> Service accounts -> Generate new private key.** This downloads a JSON file. It is a **secret**. Its whole content goes into the Vercel variable `FIREBASE_SERVICE_ACCOUNT_JSON` (step 3) and nowhere else. Never commit it or put it in the frontend.
7. **Authentication -> Settings -> Authorized domains:** add your Vercel domain (after step 4 you will know it, e.g. `your-app.vercel.app`, plus any custom domain).

### 2. ImageKit

1. Sign up at <https://imagekit.io>. In **Dashboard -> Developer options** (or "API keys") copy:
   * **URL endpoint**, like `https://ik.imagekit.io/your_imagekit_id` -> `IMAGEKIT_URL_ENDPOINT`
   * **Public key** -> `IMAGEKIT_PUBLIC_KEY`
   * **Private key** -> `IMAGEKIT_PRIVATE_KEY` (**secret**, server only)
2. Nothing else has to be created. The API puts files in the folder `/provalut` (`videos`, `thumbs`, `avatars`; change the name with `IMAGEKIT_FOLDER`).
3. **Check your plan's limits.** At the time of writing ImageKit lists a maximum video file size of 100 MB on the free plan (larger on paid plans). `MAX_VIDEO_BYTES` defaults to 100 MB; raise it only if your plan allows more. Check ImageKit's pricing page for current numbers.
4. **Private videos (default).** Videos are uploaded as *private files* and are playable only through a signed URL that the API issues after the part's unlock check (valid 6 hours). I could not confirm that private files and signed URLs are available on every ImageKit plan. If uploads of videos are rejected with `not_private`, or private playback fails, either upgrade the plan or set `IMAGEKIT_PRIVATE_VIDEOS=false`. **Consequence of `false`:** videos become public URLs, so anyone with a video's link can play it, and the per-part unlock can no longer protect the file itself (it still controls the app's UI). Thumbnails and profile photos are always public.
5. If you use a **custom ImageKit domain** (CNAME) instead of `ik.imagekit.io`, change `https://ik.imagekit.io` in the Content-Security-Policy in `vercel.json` to your domain.


### 3. Vercel

1. Push this folder to a Git repository and **Add New -> Project** in Vercel. Leave "Framework Preset" as *Other*. `vercel.json` sets the build command (`node scripts/generate-config.mjs`), the output directory (`public`) and the `/api/*` routing. No install step is needed (no npm dependencies).
2. Before the first deploy, add these under **Settings -> Environment Variables**:

| Variable | Required | Secret | Meaning |
| --- | --- | --- | --- |
| `FIREBASE_API_KEY` | yes | no | Firebase web API key (build time, written to `public/js/config.js`). |
| `FIREBASE_PROJECT_ID` | yes | no | Firebase project id. |
| `FIREBASE_SERVICE_ACCOUNT_JSON` | yes | **yes** | Whole service-account JSON (as is, or base64). |
| `IMAGEKIT_URL_ENDPOINT` | yes | no | `https://ik.imagekit.io/your_imagekit_id` |
| `IMAGEKIT_PUBLIC_KEY` | yes | no | ImageKit public key. |
| `IMAGEKIT_PRIVATE_KEY` | yes | **yes** | ImageKit private key. Never in the frontend. |
| `BOOTSTRAP_ADMIN_EMAILS` | yes | no | Comma-separated e-mails that become admin once verified. |
| `AD_SCRIPT_HOSTS` | for banners | no | Hosts allowed in banner `<script src>` (your Adsterra host). |
| `AD_POSTBACK_SECRET` | no | **yes** | Only if your provider sends server-to-server postbacks. |
| `TELEGRAM_BOT_TOKEN` | no | **yes** | Telegram bot token. Server only. |
| `TELEGRAM_CHAT_ID` | no | no | The one channel or group the bot posts to. |
| `PUBLIC_SITE_URL` | no | no | Used for links in Telegram posts (otherwise the request origin). |
| `MAX_VIDEO_BYTES` | no | no | Default 104857600 (100 MB). |
| `IMAGEKIT_FOLDER` | no | no | Default `provalut`. |
| `IMAGEKIT_PRIVATE_VIDEOS` | no | no | Default `true`. See step 2.4. |
| `ALLOWED_ORIGINS` | no | no | Only if another origin calls the API. |

   Mark the secret ones **Sensitive**. Only `FIREBASE_API_KEY`, `FIREBASE_PROJECT_ID` and `IMAGEKIT_URL_ENDPOINT` are copied into the frontend by the build.
3. **Deploy**, then check `https://YOUR-DOMAIN/api/health` returns `{"ok":true,"name":"provalut-api"}`, and add the domain to Firebase authorized domains (step 1.7).

### 4. First run

1. Create an account with the e-mail from `BOOTSTRAP_ADMIN_EMAILS` and verify it (Profile -> "Send verification email"). Admin rights need a verified address.
2. Open **Admin**. Go to **Settings** and add categories. Go to **Videos -> Add video**, fill in the details and cover, then create it. The page then shows the **Parts** editor.
3. **Add parts.** Each part: title (optional; the app shows "Video Part N"), quality, an uploaded file *or* an https link, optional download link, optional thumbnail, lock on/off, and **its own unlock link**. Reorder with the arrows; numbers update automatically. Publish at least one part, set the video to *Published* and save. An in-app notification is created (once) and Telegram is posted if configured.
4. **Admin -> Ads:** paste your real Adsterra banner code in any of the five placements (home below trending, home bottom, below video cards, below video details, bottom of the parts popup), switch each on or off independently, and tick the policy acknowledgement before locking parts.

### Banner hosts (Adsterra)

1. In Adsterra create a banner and copy its code (`<script>atOptions = {...};</script><script src="https://HOST/KEY/invoke.js"></script>`).
2. Put `HOST` in `AD_SCRIPT_HOSTS` in Vercel and redeploy.
3. Paste the code into a placement. The server checks it; the app shows it in a sandboxed iframe from `/api/ads/banner-frame?p=<placement>`. Disabled placements show nothing to visitors (admins see a dashed placeholder).
4. Each `listCard` banner is its own iframe; use "after every N cards" to keep the page light.

### Telegram (optional)

Create a bot with @BotFather, add it to **your own channel or group** as an administrator, and set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`. Provalut posts one message per newly published video to that single destination only. It never messages individual users, and the token never reaches the browser. If Telegram fails, publishing still succeeds.

## How media works

* **Upload (admin):** `POST /api/admin/uploads/auth` returns a signed token (HMAC-SHA1 of `token + expire`); the browser uploads straight to ImageKit, then sends only the file id. The server checks the file through the Media API (existence, folder, size, type, private flag, not already used) and builds URLs itself. Oversize files are deleted.
* **Watch / download:** `POST /api/parts/:pid/access` (signed-in user; a locked part needs its unlock record) returns a signed ImageKit URL (`ik-t`/`ik-s`, 6 hours; downloads add `ik-attachment=true`), or the part's external link. Views and downloads are counted on the server.
* **Profile photos** are cropped in the browser and checked and stored by the server.

## How it is secured

* **Browsers read some Firestore data but never write it.** Every `allow write` is `false`. Unlock links, media URLs and file ids live in `parts/` which no browser can read; the public video document carries only a summary (number, title, quality, locked flag).
* **The API re-checks everything.** It verifies the Firebase ID token, loads the profile and takes role and status from it, not from the request.
* **Unlocks are per user and per part** (`unlocks/<uid>_<partId>`), created with a precondition so concurrent requests produce one record.
* **Admin banner HTML:** tag allowlist; `<script src>` must be https and on `AD_SCRIPT_HOSTS`; inline scripts may only assign `atOptions`; shown in a sandboxed iframe with its own CSP.
* **Secrets** (`IMAGEKIT_PRIVATE_KEY`, service account, `AD_POSTBACK_SECRET`, `TELEGRAM_BOT_TOKEN`) exist only as Vercel variables. Tests assert nothing under `public/` contains them.

Remaining risks: no CAPTCHA on sign-up (consider App Check); a leaked signed URL works until it expires; external video links are not protected by this app; with `IMAGEKIT_PRIVATE_VIDEOS=false` file URLs are public.

## Database structure

| Collection | Contents | Browser access |
| --- | --- | --- |
| `users/{uid}` | profile, role, status, `notificationsSeenAt` | own document |
| `videos/{id}` | title, description, tags, category, status, cover, counters, `partsCount`, `partsTotal`, `partsSummary` | published: public |
| `parts/{id}` | video id, number, quality, status, lock, unlock link, media ids/URLs, download link | none |
| `unlocks/{uid_partId}` | unlock record (`timer` or `postback`, optional expiry) | none |
| `adSessions/{sid}` | one unlock attempt | none |
| `history/{uid_videoId}` | last part watched | own |
| `notifications/pub_{videoId}` | publish notification (one per video) | signed-in read |
| `likes`, `saves`, `comments`, `views` | engagement | as before (writes only via API) |
| `settings/public` | site texts, categories, banners, unlock settings and texts | public read |

## API reference

Public: `GET /api/health`, `GET /api/ads/banner-frame?p=<placement>`, `GET|POST /api/ads/postback`.
Signed-in: `POST /api/session`, `PATCH|DELETE /api/me`, `POST|DELETE /api/me/avatar`, `GET /api/videos/:id/state`, `POST /api/videos/:id/like|save|comments`, `GET /api/videos/:id/unlocks`, `POST /api/parts/:pid/unlock/start`, `POST /api/parts/unlock/complete`, `POST /api/parts/:pid/access`, `POST /api/me/notifications/seen`, `DELETE /api/me/history`, `DELETE /api/comments/:id`.
Admin: `/api/admin/dashboard|analytics|users|videos|settings|media`, `GET|POST /api/admin/videos/:id/parts`, `PUT /api/admin/videos/:id/parts/order`, `PATCH|DELETE /api/admin/parts/:pid`, `POST /api/admin/uploads/auth`.

## Changing the storage provider

Implement the methods listed at the top of `server/src/storage/index.js` in a new class, register it in `PROVIDERS` and set `STORAGE_PROVIDER`. The rest of the code only calls the adapter.

## Testing

```
node --test test/*.test.js     # API, rules lint, project checks; no dependencies
node test/e2e.mjs              # browser run; needs Playwright with Chromium installed
```

`test/mock-backend.js` and `test/mock-imagekit.js` are in-memory re-implementations of Firestore, Firebase Auth, Google OAuth and ImageKit, so they can differ from the real services.

### Testing the security rules

Before launch, run the rules against the emulator (for example with `@firebase/rules-unit-testing`, `firebase emulators:exec --only firestore "npm test"`). Cases worth asserting: a signed-in user cannot write to any collection; cannot read another user's `users/{uid}`, `likes` or `saves`; cannot read `views`, `unlocks`, `adSessions`; the public can read `published` videos but not drafts; an admin can read drafts, `stats` and `auditLogs`.

## Troubleshooting

| Symptom | Likely cause |
| --- | --- |
| "Setup needed" screen | `public/js/config.js` still has placeholders: set `FIREBASE_API_KEY`, `FIREBASE_PROJECT_ID`, `IMAGEKIT_URL_ENDPOINT` in Vercel and redeploy |
| Build fails with "Missing Environment Variable(s)" | `FIREBASE_API_KEY` is set but one of the other two public values is not |
| `/api/...` returns 500 about missing variables | a server variable (`FIREBASE_SERVICE_ACCOUNT_JSON`, `IMAGEKIT_*`) is missing; redeploy after adding |
| Upload fails in the browser | check the CSP in `vercel.json` allows `https://upload.imagekit.io`; check `MAX_VIDEO_BYTES` and your ImageKit plan's file-size limit; the browser console shows ImageKit's message |
| Video create fails with `not_private` | your ImageKit plan ignored the private flag; see "Private videos" |
| Thumbnails or video blocked | custom ImageKit domain not added to the CSP in `vercel.json` |
| "The database needs an index" | indexes not deployed or still building |
| No Admin tab | e-mail not verified, or not in `BOOTSTRAP_ADMIN_EMAILS`, or the account existed before it was set (an admin can promote you in Users) |
| Sign-in blocked | the Vercel domain is not in Firebase authorized domains |
| Banner save refused: "host not allowed" | add the host to `AD_SCRIPT_HOSTS` and redeploy |
